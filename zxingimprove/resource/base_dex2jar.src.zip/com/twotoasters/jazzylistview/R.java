package com.twotoasters.jazzylistview;

public final class R
{
  public static final class attr
  {
    public static final int effect = 2130771999;
    public static final int max_velocity = 2130772003;
    public static final int only_animate_fling = 2130772001;
    public static final int only_animate_new_items = 2130772000;
    public static final int simulate_grid_with_list = 2130772002;
  }

  public static final class id
  {
    public static final int cards = 2131623951;
    public static final int curl = 2131623952;
    public static final int fade = 2131623953;
    public static final int fan = 2131623954;
    public static final int flip = 2131623955;
    public static final int fly = 2131623956;
    public static final int grow = 2131623957;
    public static final int helix = 2131623958;
    public static final int reverse_fly = 2131623959;
    public static final int slide_in = 2131623960;
    public static final int standard = 2131623961;
    public static final int tilt = 2131623962;
    public static final int twirl = 2131623963;
    public static final int wave = 2131623964;
    public static final int zipper = 2131623965;
  }

  public static final class styleable
  {
    public static final int[] JazzyListView = { 2130771999, 2130772000, 2130772001, 2130772002, 2130772003 };
    public static final int JazzyListView_effect = 0;
    public static final int JazzyListView_max_velocity = 4;
    public static final int JazzyListView_only_animate_fling = 2;
    public static final int JazzyListView_only_animate_new_items = 1;
    public static final int JazzyListView_simulate_grid_with_list = 3;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.twotoasters.jazzylistview.R
 * JD-Core Version:    0.6.0
 */