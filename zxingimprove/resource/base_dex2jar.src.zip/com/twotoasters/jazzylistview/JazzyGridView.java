package com.twotoasters.jazzylistview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.AbsListView.OnScrollListener;
import android.widget.GridView;

public class JazzyGridView extends GridView
{
  private final JazzyHelper mHelper;

  public JazzyGridView(Context paramContext)
  {
    super(paramContext);
    this.mHelper = init(paramContext, null);
  }

  public JazzyGridView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mHelper = init(paramContext, paramAttributeSet);
  }

  public JazzyGridView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mHelper = init(paramContext, paramAttributeSet);
  }

  private JazzyHelper init(Context paramContext, AttributeSet paramAttributeSet)
  {
    JazzyHelper localJazzyHelper = new JazzyHelper(paramContext, paramAttributeSet);
    super.setOnScrollListener(localJazzyHelper);
    return localJazzyHelper;
  }

  public final void setOnScrollListener(AbsListView.OnScrollListener paramOnScrollListener)
  {
    this.mHelper.setOnScrollListener(paramOnScrollListener);
  }

  public void setShouldOnlyAnimateNewItems(boolean paramBoolean)
  {
    this.mHelper.setShouldOnlyAnimateNewItems(paramBoolean);
  }

  public void setTransitionEffect(int paramInt)
  {
    this.mHelper.setTransitionEffect(paramInt);
  }

  public void setTransitionEffect(JazzyEffect paramJazzyEffect)
  {
    this.mHelper.setTransitionEffect(paramJazzyEffect);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.twotoasters.jazzylistview.JazzyGridView
 * JD-Core Version:    0.6.0
 */