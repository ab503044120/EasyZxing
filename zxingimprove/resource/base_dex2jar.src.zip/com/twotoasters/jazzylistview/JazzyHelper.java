package com.twotoasters.jazzylistview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import com.nineoldandroids.view.ViewPropertyAnimator;
import com.twotoasters.jazzylistview.effects.CardsEffect;
import com.twotoasters.jazzylistview.effects.CurlEffect;
import com.twotoasters.jazzylistview.effects.FadeEffect;
import com.twotoasters.jazzylistview.effects.FanEffect;
import com.twotoasters.jazzylistview.effects.FlipEffect;
import com.twotoasters.jazzylistview.effects.FlyEffect;
import com.twotoasters.jazzylistview.effects.GrowEffect;
import com.twotoasters.jazzylistview.effects.HelixEffect;
import com.twotoasters.jazzylistview.effects.ReverseFlyEffect;
import com.twotoasters.jazzylistview.effects.SlideInEffect;
import com.twotoasters.jazzylistview.effects.StandardEffect;
import com.twotoasters.jazzylistview.effects.TiltEffect;
import com.twotoasters.jazzylistview.effects.TwirlEffect;
import com.twotoasters.jazzylistview.effects.WaveEffect;
import com.twotoasters.jazzylistview.effects.ZipperEffect;
import java.util.HashSet;

public class JazzyHelper
  implements AbsListView.OnScrollListener
{
  public static final int CARDS = 2;
  public static final int CURL = 3;
  public static final int DURATION = 600;
  public static final int FADE = 12;
  public static final int FAN = 9;
  public static final int FLIP = 5;
  public static final int FLY = 6;
  public static final int GROW = 1;
  public static final int HELIX = 8;
  public static final int MAX_VELOCITY_OFF = 0;
  public static final int OPAQUE = 255;
  public static final int REVERSE_FLY = 7;
  public static final int SLIDE_IN = 14;
  public static final int STANDARD = 0;
  public static final int TILT = 10;
  public static final int TRANSPARENT = 0;
  public static final int TWIRL = 13;
  public static final int WAVE = 4;
  public static final int ZIPPER = 11;
  private AbsListView.OnScrollListener mAdditionalOnScrollListener;
  private final HashSet<Integer> mAlreadyAnimatedItems = new HashSet();
  private int mFirstVisibleItem = -1;
  private boolean mIsFlingEvent;
  private boolean mIsScrolling = false;
  private int mLastVisibleItem = -1;
  private int mMaxVelocity = 0;
  private boolean mOnlyAnimateNewItems;
  private boolean mOnlyAnimateOnFling;
  private long mPreviousEventTime = 0L;
  private int mPreviousFirstVisibleItem = 0;
  private boolean mSimulateGridWithList;
  private double mSpeed = 0.0D;
  private JazzyEffect mTransitionEffect = null;

  public JazzyHelper(Context paramContext, AttributeSet paramAttributeSet)
  {
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.JazzyListView);
    int i = localTypedArray.getInteger(R.styleable.JazzyListView_effect, 0);
    int j = localTypedArray.getInteger(R.styleable.JazzyListView_max_velocity, 0);
    this.mOnlyAnimateNewItems = localTypedArray.getBoolean(R.styleable.JazzyListView_only_animate_new_items, false);
    this.mOnlyAnimateOnFling = localTypedArray.getBoolean(R.styleable.JazzyListView_max_velocity, false);
    this.mSimulateGridWithList = localTypedArray.getBoolean(R.styleable.JazzyListView_simulate_grid_with_list, false);
    localTypedArray.recycle();
    setTransitionEffect(i);
    setMaxAnimationVelocity(j);
  }

  private void doJazziness(View paramView, int paramInt1, int paramInt2)
  {
    if ((!this.mIsScrolling) || ((this.mOnlyAnimateNewItems) && (this.mAlreadyAnimatedItems.contains(Integer.valueOf(paramInt1)))));
    do
      return;
    while (((this.mOnlyAnimateOnFling) && (!this.mIsFlingEvent)) || ((this.mMaxVelocity > 0) && (this.mMaxVelocity < getVelocity())));
    ViewGroup localViewGroup;
    int i;
    if (this.mSimulateGridWithList)
    {
      localViewGroup = (ViewGroup)paramView;
      i = 0;
      if (i < localViewGroup.getChildCount());
    }
    while (true)
    {
      this.mAlreadyAnimatedItems.add(Integer.valueOf(paramInt1));
      return;
      doJazzinessImpl(localViewGroup.getChildAt(i), paramInt1, paramInt2);
      i++;
      break;
      doJazzinessImpl(paramView, paramInt1, paramInt2);
    }
  }

  private void doJazzinessImpl(View paramView, int paramInt1, int paramInt2)
  {
    ViewPropertyAnimator localViewPropertyAnimator = ViewPropertyAnimator.animate(paramView).setDuration(600L).setInterpolator(new AccelerateDecelerateInterpolator());
    if (paramInt2 > 0);
    for (int i = 1; ; i = -1)
    {
      this.mTransitionEffect.initView(paramView, paramInt1, i);
      this.mTransitionEffect.setupAnimation(paramView, paramInt1, i, localViewPropertyAnimator);
      localViewPropertyAnimator.start();
      return;
    }
  }

  private double getVelocity()
  {
    return this.mSpeed;
  }

  private void notifyAdditionalOnScrollListener(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.mAdditionalOnScrollListener != null)
      this.mAdditionalOnScrollListener.onScroll(paramAbsListView, paramInt1, paramInt2, paramInt3);
  }

  private void notifyAdditionalOnScrollStateChangedListener(AbsListView paramAbsListView, int paramInt)
  {
    if (this.mAdditionalOnScrollListener != null)
      this.mAdditionalOnScrollListener.onScrollStateChanged(paramAbsListView, paramInt);
  }

  private void setVelocity(int paramInt1, int paramInt2)
  {
    long l1;
    long l2;
    double d;
    if ((this.mMaxVelocity > 0) && (this.mPreviousFirstVisibleItem != paramInt1))
    {
      l1 = System.currentTimeMillis();
      l2 = l1 - this.mPreviousEventTime;
      if (l2 >= 1L)
        break label120;
      d = 1000.0D * (1.0D / l2);
      if (d >= 0.8999999761581421D * this.mSpeed)
        break label82;
      this.mSpeed = (0.8999999761581421D * this.mSpeed);
    }
    while (true)
    {
      this.mPreviousFirstVisibleItem = paramInt1;
      this.mPreviousEventTime = l1;
      return;
      label82: if (d > 1.100000023841858D * this.mSpeed)
      {
        this.mSpeed = (1.100000023841858D * this.mSpeed);
        continue;
      }
      this.mSpeed = d;
      continue;
      label120: this.mSpeed = (1000.0D * (1.0D / l2));
    }
  }

  public final void onScroll(AbsListView paramAbsListView, int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    int j;
    int m;
    label48: int n;
    if ((this.mFirstVisibleItem != -1) && (this.mLastVisibleItem != -1))
    {
      i = 1;
      j = -1 + (paramInt1 + paramInt2);
      if ((!this.mIsScrolling) || (i == 0))
        break label149;
      setVelocity(paramInt1, paramInt3);
      m = 0;
      if (paramInt1 + m < this.mFirstVisibleItem)
        break label101;
      n = 0;
      label62: if (j - n > this.mLastVisibleItem)
        break label122;
    }
    while (true)
    {
      this.mFirstVisibleItem = paramInt1;
      this.mLastVisibleItem = j;
      notifyAdditionalOnScrollListener(paramAbsListView, paramInt1, paramInt2, paramInt3);
      return;
      i = 0;
      break;
      label101: doJazziness(paramAbsListView.getChildAt(m), paramInt1 + m, -1);
      m++;
      break label48;
      label122: doJazziness(paramAbsListView.getChildAt(j - paramInt1 - n), j - n, 1);
      n++;
      break label62;
      label149: if (i != 0)
        continue;
      for (int k = paramInt1; k < paramInt2; k++)
        this.mAlreadyAnimatedItems.add(Integer.valueOf(k));
    }
  }

  public void onScrollStateChanged(AbsListView paramAbsListView, int paramInt)
  {
    switch (paramInt)
    {
    default:
    case 0:
    case 2:
    case 1:
    }
    while (true)
    {
      notifyAdditionalOnScrollStateChangedListener(paramAbsListView, paramInt);
      return;
      this.mIsScrolling = false;
      this.mIsFlingEvent = false;
      continue;
      this.mIsFlingEvent = true;
      continue;
      this.mIsScrolling = true;
      this.mIsFlingEvent = false;
    }
  }

  public void setMaxAnimationVelocity(int paramInt)
  {
    this.mMaxVelocity = paramInt;
  }

  public void setOnScrollListener(AbsListView.OnScrollListener paramOnScrollListener)
  {
    this.mAdditionalOnScrollListener = paramOnScrollListener;
  }

  public void setShouldOnlyAnimateFling(boolean paramBoolean)
  {
    this.mOnlyAnimateOnFling = paramBoolean;
  }

  public void setShouldOnlyAnimateNewItems(boolean paramBoolean)
  {
    this.mOnlyAnimateNewItems = paramBoolean;
  }

  public void setSimulateGridWithList(boolean paramBoolean)
  {
    this.mSimulateGridWithList = paramBoolean;
  }

  public void setTransitionEffect(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return;
    case 0:
      setTransitionEffect(new StandardEffect());
      return;
    case 1:
      setTransitionEffect(new GrowEffect());
      return;
    case 2:
      setTransitionEffect(new CardsEffect());
      return;
    case 3:
      setTransitionEffect(new CurlEffect());
      return;
    case 4:
      setTransitionEffect(new WaveEffect());
      return;
    case 5:
      setTransitionEffect(new FlipEffect());
      return;
    case 6:
      setTransitionEffect(new FlyEffect());
      return;
    case 7:
      setTransitionEffect(new ReverseFlyEffect());
      return;
    case 8:
      setTransitionEffect(new HelixEffect());
      return;
    case 9:
      setTransitionEffect(new FanEffect());
      return;
    case 10:
      setTransitionEffect(new TiltEffect());
      return;
    case 11:
      setTransitionEffect(new ZipperEffect());
      return;
    case 12:
      setTransitionEffect(new FadeEffect());
      return;
    case 13:
      setTransitionEffect(new TwirlEffect());
      return;
    case 14:
    }
    setTransitionEffect(new SlideInEffect());
  }

  public void setTransitionEffect(JazzyEffect paramJazzyEffect)
  {
    this.mTransitionEffect = paramJazzyEffect;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.twotoasters.jazzylistview.JazzyHelper
 * JD-Core Version:    0.6.0
 */