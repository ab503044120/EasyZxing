package com.andexert.library;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.ScaleAnimation;
import android.widget.RelativeLayout;

public class RippleView extends RelativeLayout
{
  private int DURATION = 400;
  private int FRAME_RATE = 10;
  private int HEIGHT;
  private int PAINT_ALPHA = 90;
  private int WIDTH;
  private boolean animationRunning = false;
  private Handler canvasHandler;
  private View childView;
  private int durationEmpty = -1;
  private GestureDetector gestureDetector;
  private Boolean hasToZoom;
  private Boolean isCentered;
  private Bitmap originBitmap;
  private Paint paint;
  private float radiusMax = 0.0F;
  private int rippleColor;
  private int ripplePadding;
  private Integer rippleType;
  private Runnable runnable = new Runnable()
  {
    public void run()
    {
      RippleView.this.invalidate();
    }
  };
  private ScaleAnimation scaleAnimation;
  private int timer = 0;
  private int timerEmpty = 0;
  private float x = -1.0F;
  private float y = -1.0F;
  private int zoomDuration;
  private float zoomScale;

  public RippleView(Context paramContext)
  {
    super(paramContext);
  }

  public RippleView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    init(paramContext, paramAttributeSet);
  }

  public RippleView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramContext, paramAttributeSet);
  }

  private Bitmap getCircleBitmap(int paramInt)
  {
    Bitmap localBitmap = Bitmap.createBitmap(this.originBitmap.getWidth(), this.originBitmap.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas localCanvas = new Canvas(localBitmap);
    Paint localPaint = new Paint();
    Rect localRect = new Rect((int)(this.x - paramInt), (int)(this.y - paramInt), (int)(this.x + paramInt), (int)(this.y + paramInt));
    localPaint.setAntiAlias(true);
    localCanvas.drawARGB(0, 0, 0, 0);
    localCanvas.drawCircle(this.x, this.y, paramInt, localPaint);
    localPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
    localCanvas.drawBitmap(this.originBitmap, localRect, localRect, localPaint);
    return localBitmap;
  }

  private void init(Context paramContext, AttributeSet paramAttributeSet)
  {
    if (isInEditMode())
      return;
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.RippleView);
    this.rippleColor = localTypedArray.getColor(R.styleable.RippleView_rv_color, getResources().getColor(R.color.rippelColor));
    this.rippleType = Integer.valueOf(localTypedArray.getInt(R.styleable.RippleView_rv_type, 0));
    this.hasToZoom = Boolean.valueOf(localTypedArray.getBoolean(R.styleable.RippleView_rv_zoom, false));
    this.isCentered = Boolean.valueOf(localTypedArray.getBoolean(R.styleable.RippleView_rv_centered, false));
    this.DURATION = localTypedArray.getInteger(R.styleable.RippleView_rv_rippleDuration, this.DURATION);
    this.FRAME_RATE = localTypedArray.getInteger(R.styleable.RippleView_rv_framerate, this.FRAME_RATE);
    this.PAINT_ALPHA = localTypedArray.getInteger(R.styleable.RippleView_rv_alpha, this.PAINT_ALPHA);
    this.ripplePadding = localTypedArray.getDimensionPixelSize(R.styleable.RippleView_rv_ripplePadding, 0);
    this.canvasHandler = new Handler();
    this.zoomScale = localTypedArray.getFloat(R.styleable.RippleView_rv_zoomScale, 1.03F);
    this.zoomDuration = localTypedArray.getInt(R.styleable.RippleView_rv_zoomDuration, 200);
    this.paint = new Paint();
    this.paint.setAntiAlias(true);
    this.paint.setStyle(Paint.Style.FILL);
    this.paint.setColor(this.rippleColor);
    this.paint.setAlpha(this.PAINT_ALPHA);
    setWillNotDraw(false);
    this.gestureDetector = new GestureDetector(paramContext, new GestureDetector.SimpleOnGestureListener()
    {
      public boolean onSingleTapConfirmed(MotionEvent paramMotionEvent)
      {
        return true;
      }

      public boolean onSingleTapUp(MotionEvent paramMotionEvent)
      {
        return true;
      }
    });
    setDrawingCacheEnabled(true);
  }

  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    this.childView = paramView;
    super.addView(paramView, paramInt, paramLayoutParams);
  }

  public void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    if (this.animationRunning)
    {
      if (this.DURATION <= this.timer * this.FRAME_RATE)
      {
        this.animationRunning = false;
        this.timer = 0;
        this.durationEmpty = -1;
        this.timerEmpty = 0;
        paramCanvas.restore();
        invalidate();
      }
    }
    else
      return;
    this.canvasHandler.postDelayed(this.runnable, this.FRAME_RATE);
    if (this.timer == 0)
      paramCanvas.save();
    paramCanvas.drawCircle(this.x, this.y, this.radiusMax * (this.timer * this.FRAME_RATE / this.DURATION), this.paint);
    this.paint.setColor(getResources().getColor(17170454));
    if ((this.rippleType.intValue() == 1) && (this.originBitmap != null) && (this.timer * this.FRAME_RATE / this.DURATION > 0.4F))
    {
      if (this.durationEmpty == -1)
        this.durationEmpty = (this.DURATION - this.timer * this.FRAME_RATE);
      this.timerEmpty = (1 + this.timerEmpty);
      Bitmap localBitmap = getCircleBitmap((int)(this.radiusMax * (this.timerEmpty * this.FRAME_RATE / this.durationEmpty)));
      paramCanvas.drawBitmap(localBitmap, 0.0F, 0.0F, this.paint);
      localBitmap.recycle();
    }
    this.paint.setColor(this.rippleColor);
    if (this.rippleType.intValue() == 1)
      if (this.timer * this.FRAME_RATE / this.DURATION > 0.6F)
        this.paint.setAlpha((int)(this.PAINT_ALPHA - this.PAINT_ALPHA * (this.timerEmpty * this.FRAME_RATE / this.durationEmpty)));
    while (true)
    {
      this.timer = (1 + this.timer);
      return;
      this.paint.setAlpha(this.PAINT_ALPHA);
      continue;
      this.paint.setAlpha((int)(this.PAINT_ALPHA - this.PAINT_ALPHA * (this.timer * this.FRAME_RATE / this.DURATION)));
    }
  }

  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    return true;
  }

  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    this.WIDTH = paramInt1;
    this.HEIGHT = paramInt2;
    this.scaleAnimation = new ScaleAnimation(1.0F, this.zoomScale, 1.0F, this.zoomScale, paramInt1 / 2, paramInt2 / 2);
    this.scaleAnimation.setDuration(this.zoomDuration);
    this.scaleAnimation.setRepeatMode(2);
    this.scaleAnimation.setRepeatCount(1);
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    if ((this.gestureDetector.onTouchEvent(paramMotionEvent)) && (!this.animationRunning))
    {
      if (this.hasToZoom.booleanValue())
        startAnimation(this.scaleAnimation);
      this.radiusMax = Math.max(this.WIDTH, this.HEIGHT);
      if (this.rippleType.intValue() != 2)
        this.radiusMax /= 2.0F;
      this.radiusMax -= this.ripplePadding;
      if ((!this.isCentered.booleanValue()) && (this.rippleType.intValue() != 1))
        break label182;
      this.x = (getMeasuredWidth() / 2);
    }
    for (this.y = (getMeasuredHeight() / 2); ; this.y = paramMotionEvent.getY())
    {
      this.animationRunning = true;
      if ((this.rippleType.intValue() == 1) && (this.originBitmap == null))
        this.originBitmap = getDrawingCache(true);
      invalidate();
      performClick();
      this.childView.onTouchEvent(paramMotionEvent);
      return true;
      label182: this.x = paramMotionEvent.getX();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.andexert.library.RippleView
 * JD-Core Version:    0.6.0
 */