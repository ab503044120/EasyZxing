package com.andexert.library;

public final class R
{
  public static final class attr
  {
    public static final int rv_alpha = 2130772009;
    public static final int rv_centered = 2130772014;
    public static final int rv_color = 2130772013;
    public static final int rv_framerate = 2130772010;
    public static final int rv_rippleDuration = 2130772011;
    public static final int rv_ripplePadding = 2130772016;
    public static final int rv_type = 2130772015;
    public static final int rv_zoom = 2130772017;
    public static final int rv_zoomDuration = 2130772012;
    public static final int rv_zoomScale = 2130772018;
  }

  public static final class color
  {
    public static final int rippelColor = 2131165215;
  }

  public static final class drawable
  {
    public static final int background_button = 2130837505;
    public static final int shape_rounded = 2130837737;
  }

  public static final class id
  {
    public static final int doubleRipple = 2131623969;
    public static final int rectangle = 2131623970;
    public static final int simpleRipple = 2131623971;
  }

  public static final class string
  {
    public static final int app_name = 2131492864;
  }

  public static final class style
  {
    public static final int AppTheme = 2131427339;
  }

  public static final class styleable
  {
    public static final int[] RippleView = { 2130772009, 2130772010, 2130772011, 2130772012, 2130772013, 2130772014, 2130772015, 2130772016, 2130772017, 2130772018 };
    public static final int RippleView_rv_alpha = 0;
    public static final int RippleView_rv_centered = 5;
    public static final int RippleView_rv_color = 4;
    public static final int RippleView_rv_framerate = 1;
    public static final int RippleView_rv_rippleDuration = 2;
    public static final int RippleView_rv_ripplePadding = 7;
    public static final int RippleView_rv_type = 6;
    public static final int RippleView_rv_zoom = 8;
    public static final int RippleView_rv_zoomDuration = 3;
    public static final int RippleView_rv_zoomScale = 9;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.andexert.library.R
 * JD-Core Version:    0.6.0
 */