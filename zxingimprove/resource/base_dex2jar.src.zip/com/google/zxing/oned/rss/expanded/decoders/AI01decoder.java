package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.common.BitArray;

abstract class AI01decoder extends AbstractExpandedDecoder
{
  protected static final int GTIN_SIZE = 40;

  AI01decoder(BitArray paramBitArray)
  {
    super(paramBitArray);
  }

  private static void appendCheckDigit(StringBuilder paramStringBuilder, int paramInt)
  {
    int i = 0;
    for (int j = 0; ; j++)
    {
      if (j >= 13)
      {
        int m = 10 - i % 10;
        if (m == 10)
          m = 0;
        paramStringBuilder.append(m);
        return;
      }
      int k = '￐' + paramStringBuilder.charAt(j + paramInt);
      if ((j & 0x1) == 0)
        k *= 3;
      i += k;
    }
  }

  protected final void encodeCompressedGtin(StringBuilder paramStringBuilder, int paramInt)
  {
    paramStringBuilder.append("(01)");
    int i = paramStringBuilder.length();
    paramStringBuilder.append('9');
    encodeCompressedGtinWithoutAI(paramStringBuilder, paramInt, i);
  }

  protected final void encodeCompressedGtinWithoutAI(StringBuilder paramStringBuilder, int paramInt1, int paramInt2)
  {
    for (int i = 0; ; i++)
    {
      if (i >= 4)
      {
        appendCheckDigit(paramStringBuilder, paramInt2);
        return;
      }
      int j = getGeneralDecoder().extractNumericValueFromBitArray(paramInt1 + i * 10, 10);
      if (j / 100 == 0)
        paramStringBuilder.append('0');
      if (j / 10 == 0)
        paramStringBuilder.append('0');
      paramStringBuilder.append(j);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.oned.rss.expanded.decoders.AI01decoder
 * JD-Core Version:    0.6.0
 */