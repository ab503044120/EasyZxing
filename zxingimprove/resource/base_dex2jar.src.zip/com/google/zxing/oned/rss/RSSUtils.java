package com.google.zxing.oned.rss;

public final class RSSUtils
{
  private static int combins(int paramInt1, int paramInt2)
  {
    int i;
    int j;
    int k;
    int m;
    int n;
    if (paramInt1 - paramInt2 > paramInt2)
    {
      i = paramInt2;
      j = paramInt1 - paramInt2;
      k = 1;
      m = 1;
      n = paramInt1;
      label22: if (n > j)
        break label46;
    }
    while (true)
    {
      if (m > i)
      {
        return k;
        i = paramInt1 - paramInt2;
        j = paramInt2;
        break;
        label46: k *= n;
        if (m <= i)
        {
          k /= m;
          m++;
        }
        n--;
        break label22;
      }
      k /= m;
      m++;
    }
  }

  public static int getRSSvalue(int[] paramArrayOfInt, int paramInt, boolean paramBoolean)
  {
    int i = paramArrayOfInt.length;
    int j = 0;
    int k = paramArrayOfInt.length;
    int m = 0;
    int n;
    int i1;
    if (m >= k)
    {
      n = 0;
      i1 = 0;
    }
    int i3;
    for (int i2 = 0; ; i2++)
    {
      if (i2 >= i - 1)
      {
        return n;
        j += paramArrayOfInt[m];
        m++;
        break;
      }
      i3 = 1;
      i1 |= 1 << i2;
      if (i3 < paramArrayOfInt[i2])
        break label89;
      j -= i3;
    }
    label89: int i4 = combins(-1 + (j - i3), -2 + (i - i2));
    if ((paramBoolean) && (i1 == 0) && (j - i3 - (-1 + (i - i2)) >= -1 + (i - i2)))
      i4 -= combins(j - i3 - (i - i2), -2 + (i - i2));
    int i5;
    int i6;
    if (-1 + (i - i2) > 1)
    {
      i5 = 0;
      i6 = j - i3 - (-2 + (i - i2));
      label191: if (i6 <= paramInt)
        i4 -= i5 * (i - 1 - i2);
    }
    while (true)
    {
      n += i4;
      i3++;
      i1 &= (0xFFFFFFFF ^ 1 << i2);
      break;
      i5 += combins(-1 + (j - i3 - i6), -3 + (i - i2));
      i6--;
      break label191;
      if (j - i3 <= paramInt)
        continue;
      i4--;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.oned.rss.RSSUtils
 * JD-Core Version:    0.6.0
 */