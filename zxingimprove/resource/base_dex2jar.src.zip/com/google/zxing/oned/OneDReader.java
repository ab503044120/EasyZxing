package com.google.zxing.oned;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitArray;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;

public abstract class OneDReader
  implements Reader
{
  private Result doDecode(BinaryBitmap paramBinaryBitmap, Map<DecodeHintType, ?> paramMap)
    throws NotFoundException
  {
    int i = paramBinaryBitmap.getWidth();
    int j = paramBinaryBitmap.getHeight();
    Object localObject = new BitArray(i);
    int k = j >> 1;
    int m;
    int n;
    label59: int i1;
    int i2;
    label79: int i3;
    if (paramMap != null)
    {
      DecodeHintType localDecodeHintType2 = DecodeHintType.TRY_HARDER;
      if (paramMap.containsKey(localDecodeHintType2))
      {
        m = 1;
        if (m == 0)
          break label99;
        n = 8;
        i1 = Math.max(1, j >> n);
        if (m == 0)
          break label105;
        i2 = j;
        i3 = 0;
      }
    }
    while (true)
    {
      if (i3 >= i2);
      label99: label105: int i4;
      int i5;
      label130: int i6;
      do
      {
        throw NotFoundException.getNotFoundInstance();
        m = 0;
        break;
        n = 5;
        break label59;
        i2 = 15;
        break label79;
        i4 = (i3 + 1) / 2;
        if ((i3 & 0x1) != 0)
          break label186;
        i5 = 1;
        if (i5 == 0)
          break label192;
        i6 = k + i1 * i4;
      }
      while ((i6 < 0) || (i6 >= j));
      try
      {
        BitArray localBitArray = paramBinaryBitmap.getBlackRow(i6, (BitArray)localObject);
        localObject = localBitArray;
        i7 = 0;
        if (i7 >= 2)
        {
          i3++;
          continue;
          label186: i5 = 0;
          break label130;
          label192: i4 = -i4;
        }
      }
      catch (NotFoundException localNotFoundException)
      {
        while (true)
        {
          int i7;
          continue;
          if (i7 == 1)
          {
            ((BitArray)localObject).reverse();
            if (paramMap != null)
            {
              DecodeHintType localDecodeHintType1 = DecodeHintType.NEED_RESULT_POINT_CALLBACK;
              if (paramMap.containsKey(localDecodeHintType1))
              {
                EnumMap localEnumMap = new EnumMap(DecodeHintType.class);
                localEnumMap.putAll(paramMap);
                localEnumMap.remove(DecodeHintType.NEED_RESULT_POINT_CALLBACK);
                paramMap = localEnumMap;
              }
            }
          }
          try
          {
            Result localResult = decodeRow(i6, (BitArray)localObject, paramMap);
            if (i7 == 1)
            {
              localResult.putMetadata(ResultMetadataType.ORIENTATION, Integer.valueOf(180));
              ResultPoint[] arrayOfResultPoint = localResult.getResultPoints();
              if (arrayOfResultPoint != null)
              {
                arrayOfResultPoint[0] = new ResultPoint(i - arrayOfResultPoint[0].getX() - 1.0F, arrayOfResultPoint[0].getY());
                arrayOfResultPoint[1] = new ResultPoint(i - arrayOfResultPoint[1].getX() - 1.0F, arrayOfResultPoint[1].getY());
              }
            }
            return localResult;
          }
          catch (ReaderException localReaderException)
          {
            i7++;
          }
        }
      }
    }
  }

  protected static float patternMatchVariance(int[] paramArrayOfInt1, int[] paramArrayOfInt2, float paramFloat)
  {
    int i = paramArrayOfInt1.length;
    int j = 0;
    int k = 0;
    int m = 0;
    if (m >= i)
      if (j >= k)
        break label52;
    label149: 
    while (true)
    {
      return (1.0F / 1.0F);
      j += paramArrayOfInt1[m];
      k += paramArrayOfInt2[m];
      m++;
      break;
      label52: float f1 = j / k;
      float f2 = paramFloat * f1;
      float f3 = 0.0F;
      int n = 0;
      if (n >= i)
        return f3 / j;
      int i1 = paramArrayOfInt1[n];
      float f4 = f1 * paramArrayOfInt2[n];
      float f5;
      if (i1 > f4)
        f5 = i1 - f4;
      while (true)
      {
        if (f5 > f2)
          break label149;
        f3 += f5;
        n++;
        break;
        f5 = f4 - i1;
      }
    }
  }

  protected static void recordPattern(BitArray paramBitArray, int paramInt, int[] paramArrayOfInt)
    throws NotFoundException
  {
    int i = paramArrayOfInt.length;
    Arrays.fill(paramArrayOfInt, 0, i, 0);
    int j = paramBitArray.getSize();
    if (paramInt >= j)
      throw NotFoundException.getNotFoundInstance();
    int m;
    int n;
    if (paramBitArray.get(paramInt))
    {
      k = 0;
      m = 0;
      n = paramInt;
      label43: if (n < j)
        break label81;
    }
    label81: 
    do
    {
      if ((m == i) || ((m == i - 1) && (n == j)))
        return;
      throw NotFoundException.getNotFoundInstance();
      k = 1;
      break;
      if ((k ^ paramBitArray.get(n)) != 0)
      {
        paramArrayOfInt[m] = (1 + paramArrayOfInt[m]);
        n++;
        break label43;
      }
      m++;
    }
    while (m == i);
    paramArrayOfInt[m] = 1;
    if (k != 0);
    for (int k = 0; ; k = 1)
      break;
  }

  protected static void recordPatternInReverse(BitArray paramBitArray, int paramInt, int[] paramArrayOfInt)
    throws NotFoundException
  {
    int i = paramArrayOfInt.length;
    boolean bool = paramBitArray.get(paramInt);
    while (true)
      if ((paramInt <= 0) || (i < 0))
      {
        if (i < 0)
          break;
        throw NotFoundException.getNotFoundInstance();
      }
      else
      {
        paramInt--;
        if (paramBitArray.get(paramInt) == bool)
          continue;
        i--;
        if (bool);
        for (bool = false; ; bool = true)
          break;
      }
    recordPattern(paramBitArray, paramInt + 1, paramArrayOfInt);
  }

  public Result decode(BinaryBitmap paramBinaryBitmap)
    throws NotFoundException, FormatException
  {
    return decode(paramBinaryBitmap, null);
  }

  public Result decode(BinaryBitmap paramBinaryBitmap, Map<DecodeHintType, ?> paramMap)
    throws NotFoundException, FormatException
  {
    try
    {
      Result localResult2 = doDecode(paramBinaryBitmap, paramMap);
      localResult1 = localResult2;
      return localResult1;
    }
    catch (NotFoundException localNotFoundException)
    {
      Result localResult1;
      if ((paramMap != null) && (paramMap.containsKey(DecodeHintType.TRY_HARDER)));
      for (int i = 1; ; i = 0)
      {
        if ((i == 0) || (!paramBinaryBitmap.isRotateSupported()))
          break label206;
        BinaryBitmap localBinaryBitmap = paramBinaryBitmap.rotateCounterClockwise();
        localResult1 = doDecode(localBinaryBitmap, paramMap);
        Map localMap = localResult1.getResultMetadata();
        int j = 270;
        if ((localMap != null) && (localMap.containsKey(ResultMetadataType.ORIENTATION)))
          j = (j + ((Integer)localMap.get(ResultMetadataType.ORIENTATION)).intValue()) % 360;
        localResult1.putMetadata(ResultMetadataType.ORIENTATION, Integer.valueOf(j));
        ResultPoint[] arrayOfResultPoint = localResult1.getResultPoints();
        if (arrayOfResultPoint == null)
          break;
        int k = localBinaryBitmap.getHeight();
        for (int m = 0; m < arrayOfResultPoint.length; m++)
          arrayOfResultPoint[m] = new ResultPoint(k - arrayOfResultPoint[m].getY() - 1.0F, arrayOfResultPoint[m].getX());
      }
    }
    label206: throw localNotFoundException;
  }

  public abstract Result decodeRow(int paramInt, BitArray paramBitArray, Map<DecodeHintType, ?> paramMap)
    throws NotFoundException, ChecksumException, FormatException;

  public void reset()
  {
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.oned.OneDReader
 * JD-Core Version:    0.6.0
 */