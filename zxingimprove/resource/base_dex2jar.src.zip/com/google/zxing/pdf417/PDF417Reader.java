package com.google.zxing.pdf417;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.multi.MultipleBarcodeReader;
import com.google.zxing.pdf417.decoder.PDF417ScanningDecoder;
import com.google.zxing.pdf417.detector.Detector;
import com.google.zxing.pdf417.detector.PDF417DetectorResult;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class PDF417Reader
  implements Reader, MultipleBarcodeReader
{
  private static Result[] decode(BinaryBitmap paramBinaryBitmap, Map<DecodeHintType, ?> paramMap, boolean paramBoolean)
    throws NotFoundException, FormatException, ChecksumException
  {
    ArrayList localArrayList = new ArrayList();
    PDF417DetectorResult localPDF417DetectorResult = Detector.detect(paramBinaryBitmap, paramMap, paramBoolean);
    Iterator localIterator = localPDF417DetectorResult.getPoints().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return (Result[])localArrayList.toArray(new Result[localArrayList.size()]);
      ResultPoint[] arrayOfResultPoint = (ResultPoint[])localIterator.next();
      DecoderResult localDecoderResult = PDF417ScanningDecoder.decode(localPDF417DetectorResult.getBits(), arrayOfResultPoint[4], arrayOfResultPoint[5], arrayOfResultPoint[6], arrayOfResultPoint[7], getMinCodewordWidth(arrayOfResultPoint), getMaxCodewordWidth(arrayOfResultPoint));
      Result localResult = new Result(localDecoderResult.getText(), localDecoderResult.getRawBytes(), arrayOfResultPoint, BarcodeFormat.PDF_417);
      localResult.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, localDecoderResult.getECLevel());
      PDF417ResultMetadata localPDF417ResultMetadata = (PDF417ResultMetadata)localDecoderResult.getOther();
      if (localPDF417ResultMetadata != null)
        localResult.putMetadata(ResultMetadataType.PDF417_EXTRA_METADATA, localPDF417ResultMetadata);
      localArrayList.add(localResult);
    }
  }

  private static int getMaxCodewordWidth(ResultPoint[] paramArrayOfResultPoint)
  {
    return Math.max(Math.max(getMaxWidth(paramArrayOfResultPoint[0], paramArrayOfResultPoint[4]), 17 * getMaxWidth(paramArrayOfResultPoint[6], paramArrayOfResultPoint[2]) / 18), Math.max(getMaxWidth(paramArrayOfResultPoint[1], paramArrayOfResultPoint[5]), 17 * getMaxWidth(paramArrayOfResultPoint[7], paramArrayOfResultPoint[3]) / 18));
  }

  private static int getMaxWidth(ResultPoint paramResultPoint1, ResultPoint paramResultPoint2)
  {
    if ((paramResultPoint1 == null) || (paramResultPoint2 == null))
      return 0;
    return (int)Math.abs(paramResultPoint1.getX() - paramResultPoint2.getX());
  }

  private static int getMinCodewordWidth(ResultPoint[] paramArrayOfResultPoint)
  {
    return Math.min(Math.min(getMinWidth(paramArrayOfResultPoint[0], paramArrayOfResultPoint[4]), 17 * getMinWidth(paramArrayOfResultPoint[6], paramArrayOfResultPoint[2]) / 18), Math.min(getMinWidth(paramArrayOfResultPoint[1], paramArrayOfResultPoint[5]), 17 * getMinWidth(paramArrayOfResultPoint[7], paramArrayOfResultPoint[3]) / 18));
  }

  private static int getMinWidth(ResultPoint paramResultPoint1, ResultPoint paramResultPoint2)
  {
    if ((paramResultPoint1 == null) || (paramResultPoint2 == null))
      return 2147483647;
    return (int)Math.abs(paramResultPoint1.getX() - paramResultPoint2.getX());
  }

  public Result decode(BinaryBitmap paramBinaryBitmap)
    throws NotFoundException, FormatException, ChecksumException
  {
    return decode(paramBinaryBitmap, null);
  }

  public Result decode(BinaryBitmap paramBinaryBitmap, Map<DecodeHintType, ?> paramMap)
    throws NotFoundException, FormatException, ChecksumException
  {
    Result[] arrayOfResult = decode(paramBinaryBitmap, paramMap, false);
    if ((arrayOfResult == null) || (arrayOfResult.length == 0) || (arrayOfResult[0] == null))
      throw NotFoundException.getNotFoundInstance();
    return arrayOfResult[0];
  }

  public Result[] decodeMultiple(BinaryBitmap paramBinaryBitmap)
    throws NotFoundException
  {
    return decodeMultiple(paramBinaryBitmap, null);
  }

  public Result[] decodeMultiple(BinaryBitmap paramBinaryBitmap, Map<DecodeHintType, ?> paramMap)
    throws NotFoundException
  {
    try
    {
      Result[] arrayOfResult = decode(paramBinaryBitmap, paramMap, true);
      return arrayOfResult;
    }
    catch (ChecksumException localChecksumException)
    {
      throw NotFoundException.getNotFoundInstance();
    }
    catch (FormatException localFormatException)
    {
      localFormatException.printStackTrace();
    }
    return null;
  }

  public void reset()
  {
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.PDF417Reader
 * JD-Core Version:    0.6.0
 */