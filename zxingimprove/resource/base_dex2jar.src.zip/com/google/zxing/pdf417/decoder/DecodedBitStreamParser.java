package com.google.zxing.pdf417.decoder;

import com.google.zxing.FormatException;
import com.google.zxing.common.CharacterSetECI;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.pdf417.PDF417ResultMetadata;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.Arrays;

final class DecodedBitStreamParser
{
  private static final int AL = 28;
  private static final int AS = 27;
  private static final int BEGIN_MACRO_PDF417_CONTROL_BLOCK = 928;
  private static final int BEGIN_MACRO_PDF417_OPTIONAL_FIELD = 923;
  private static final int BYTE_COMPACTION_MODE_LATCH = 901;
  private static final int BYTE_COMPACTION_MODE_LATCH_6 = 924;
  private static final Charset DEFAULT_ENCODING;
  private static final int ECI_CHARSET = 927;
  private static final int ECI_GENERAL_PURPOSE = 926;
  private static final int ECI_USER_DEFINED = 925;
  private static final BigInteger[] EXP900;
  private static final int LL = 27;
  private static final int MACRO_PDF417_TERMINATOR = 922;
  private static final int MAX_NUMERIC_CODEWORDS = 15;
  private static final char[] MIXED_CHARS;
  private static final int ML = 28;
  private static final int MODE_SHIFT_TO_BYTE_COMPACTION_MODE = 913;
  private static final int NUMBER_OF_SEQUENCE_CODEWORDS = 2;
  private static final int NUMERIC_COMPACTION_MODE_LATCH = 902;
  private static final int PAL = 29;
  private static final int PL = 25;
  private static final int PS = 29;
  private static final char[] PUNCT_CHARS = { 59, 60, 62, 64, 91, 92, 93, 95, 96, 126, 33, 13, 9, 44, 58, 10, 45, 46, 36, 47, 34, 124, 42, 40, 41, 63, 123, 125, 39 };
  private static final int TEXT_COMPACTION_MODE_LATCH = 900;

  static
  {
    MIXED_CHARS = new char[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 38, 13, 9, 44, 58, 35, 45, 46, 36, 47, 43, 37, 42, 61, 94 };
    DEFAULT_ENCODING = Charset.forName("ISO-8859-1");
    EXP900 = new BigInteger[16];
    EXP900[0] = BigInteger.ONE;
    BigInteger localBigInteger = BigInteger.valueOf(900L);
    EXP900[1] = localBigInteger;
    for (int i = 2; ; i++)
    {
      if (i >= EXP900.length)
        return;
      EXP900[i] = EXP900[(i - 1)].multiply(localBigInteger);
    }
  }

  private static int byteCompaction(int paramInt1, int[] paramArrayOfInt, Charset paramCharset, int paramInt2, StringBuilder paramStringBuilder)
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    int i2;
    long l2;
    int[] arrayOfInt;
    int i3;
    int i5;
    if (paramInt1 == 901)
    {
      i2 = 0;
      l2 = 0L;
      arrayOfInt = new int[6];
      i3 = 0;
      int i4 = paramInt2 + 1;
      i5 = paramArrayOfInt[paramInt2];
      paramInt2 = i4;
    }
    while (true)
    {
      int i6 = paramArrayOfInt[0];
      int i8;
      if ((paramInt2 >= i6) || (i3 != 0))
      {
        int i7 = paramArrayOfInt[0];
        if ((paramInt2 == i7) && (i5 < 900))
        {
          int i9 = i2 + 1;
          arrayOfInt[i2] = i5;
          i2 = i9;
        }
        i8 = 0;
        label99: if (i8 < i2)
          break label290;
      }
      int i10;
      int i11;
      label290: 
      do
      {
        paramStringBuilder.append(new String(localByteArrayOutputStream.toByteArray(), paramCharset));
        return paramInt2;
        i10 = i2 + 1;
        arrayOfInt[i2] = i5;
        l2 = 900L * l2 + i5;
        i11 = paramInt2 + 1;
        i5 = paramArrayOfInt[paramInt2];
        if ((i5 == 900) || (i5 == 901) || (i5 == 902) || (i5 == 924) || (i5 == 928) || (i5 == 923) || (i5 == 922))
        {
          paramInt2 = i11 - 1;
          i3 = 1;
          i2 = i10;
          break;
        }
        if ((i10 % 5 != 0) || (i10 <= 0))
          break label502;
        for (int i12 = 0; ; i12++)
        {
          if (i12 >= 6)
          {
            l2 = 0L;
            paramInt2 = i11;
            i2 = 0;
            break;
          }
          localByteArrayOutputStream.write((byte)(int)(l2 >> 8 * (5 - i12)));
        }
        localByteArrayOutputStream.write((byte)arrayOfInt[i8]);
        i8++;
        break label99;
      }
      while (paramInt1 != 924);
      int i = 0;
      long l1 = 0L;
      int j = 0;
      label496: label500: 
      while (true)
      {
        int k = paramArrayOfInt[0];
        if ((paramInt2 >= k) || (j != 0))
          break;
        int m = paramInt2 + 1;
        int n = paramArrayOfInt[paramInt2];
        if (n < 900)
        {
          i++;
          l1 = 900L * l1 + n;
          paramInt2 = m;
        }
        while (true)
        {
          label375: if ((i % 5 != 0) || (i <= 0))
            break label500;
          for (int i1 = 0; ; i1++)
          {
            if (i1 >= 6)
            {
              l1 = 0L;
              i = 0;
              break;
              if ((n != 900) && (n != 901) && (n != 902) && (n != 924) && (n != 928) && (n != 923) && (n != 922))
                break label496;
              paramInt2 = m - 1;
              j = 1;
              break label375;
            }
            localByteArrayOutputStream.write((byte)(int)(l1 >> 8 * (5 - i1)));
          }
          paramInt2 = m;
        }
      }
      label502: i2 = i10;
      paramInt2 = i11;
    }
  }

  static DecoderResult decode(int[] paramArrayOfInt, String paramString)
    throws FormatException
  {
    StringBuilder localStringBuilder = new StringBuilder(2 * paramArrayOfInt.length);
    Charset localCharset = DEFAULT_ENCODING;
    int i = 1 + 1;
    int j = paramArrayOfInt[1];
    PDF417ResultMetadata localPDF417ResultMetadata = new PDF417ResultMetadata();
    int k = i;
    if (k >= paramArrayOfInt[0])
    {
      if (localStringBuilder.length() == 0)
        throw FormatException.getFormatInstance();
    }
    else
    {
      int m;
      switch (j)
      {
      default:
        m = textCompaction(paramArrayOfInt, k - 1, localStringBuilder);
      case 900:
      case 901:
      case 924:
      case 913:
      case 902:
      case 927:
      case 926:
      case 925:
      case 928:
        while (true)
        {
          if (m >= paramArrayOfInt.length)
            break label321;
          int n = m + 1;
          j = paramArrayOfInt[m];
          k = n;
          break;
          m = textCompaction(paramArrayOfInt, k, localStringBuilder);
          continue;
          m = byteCompaction(j, paramArrayOfInt, localCharset, k, localStringBuilder);
          continue;
          int i2 = k + 1;
          localStringBuilder.append((char)paramArrayOfInt[k]);
          m = i2;
          continue;
          m = numericCompaction(paramArrayOfInt, k, localStringBuilder);
          continue;
          int i1 = k + 1;
          localCharset = Charset.forName(CharacterSetECI.getCharacterSetECIByValue(paramArrayOfInt[k]).name());
          m = i1;
          continue;
          m = k + 2;
          continue;
          m = k + 1;
          continue;
          m = decodeMacroBlock(paramArrayOfInt, k, localPDF417ResultMetadata);
        }
      case 922:
      case 923:
      }
      throw FormatException.getFormatInstance();
      label321: throw FormatException.getFormatInstance();
    }
    DecoderResult localDecoderResult = new DecoderResult(null, localStringBuilder.toString(), null, paramString);
    localDecoderResult.setOther(localPDF417ResultMetadata);
    return localDecoderResult;
  }

  private static String decodeBase900toBase10(int[] paramArrayOfInt, int paramInt)
    throws FormatException
  {
    BigInteger localBigInteger = BigInteger.ZERO;
    String str;
    for (int i = 0; ; i++)
    {
      if (i >= paramInt)
      {
        str = localBigInteger.toString();
        if (str.charAt(0) == '1')
          break;
        throw FormatException.getFormatInstance();
      }
      localBigInteger = localBigInteger.add(EXP900[(-1 + (paramInt - i))].multiply(BigInteger.valueOf(paramArrayOfInt[i])));
    }
    return str.substring(1);
  }

  private static int decodeMacroBlock(int[] paramArrayOfInt, int paramInt, PDF417ResultMetadata paramPDF417ResultMetadata)
    throws FormatException
  {
    if (paramInt + 2 > paramArrayOfInt[0])
      throw FormatException.getFormatInstance();
    int[] arrayOfInt1 = new int[2];
    int i = 0;
    int j;
    int[] arrayOfInt2;
    int k;
    int m;
    if (i >= 2)
    {
      paramPDF417ResultMetadata.setSegmentIndex(Integer.parseInt(decodeBase900toBase10(arrayOfInt1, 2)));
      StringBuilder localStringBuilder = new StringBuilder();
      j = textCompaction(paramArrayOfInt, paramInt, localStringBuilder);
      paramPDF417ResultMetadata.setFileId(localStringBuilder.toString());
      if (paramArrayOfInt[j] != 923)
        break label221;
      j++;
      arrayOfInt2 = new int[paramArrayOfInt[0] - j];
      k = 0;
      m = 0;
      label94: if ((j < paramArrayOfInt[0]) && (m == 0))
        break label137;
      paramPDF417ResultMetadata.setOptionalData(Arrays.copyOf(arrayOfInt2, k));
    }
    label137: label221: 
    do
    {
      return j;
      arrayOfInt1[i] = paramArrayOfInt[paramInt];
      i++;
      paramInt++;
      break;
      int n = j + 1;
      int i1 = paramArrayOfInt[j];
      if (i1 < 900)
      {
        int i2 = k + 1;
        arrayOfInt2[k] = i1;
        k = i2;
        j = n;
        break label94;
      }
      switch (i1)
      {
      default:
        throw FormatException.getFormatInstance();
      case 922:
      }
      paramPDF417ResultMetadata.setLastSegment(true);
      j = n + 1;
      m = 1;
      break label94;
    }
    while (paramArrayOfInt[j] != 922);
    paramPDF417ResultMetadata.setLastSegment(true);
    return j + 1;
  }

  private static void decodeTextCompaction(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt, StringBuilder paramStringBuilder)
  {
    Object localObject1 = Mode.ALPHA;
    Object localObject2 = Mode.ALPHA;
    int i = 0;
    if (i >= paramInt)
      return;
    int j = paramArrayOfInt1[i];
    int k = $SWITCH_TABLE$com$google$zxing$pdf417$decoder$DecodedBitStreamParser$Mode()[localObject1.ordinal()];
    char c = '\000';
    switch (k)
    {
    default:
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    }
    while (true)
    {
      if (c != 0)
        paramStringBuilder.append(c);
      i++;
      break;
      if (j < 26)
      {
        c = (char)(j + 65);
        continue;
      }
      if (j == 26)
      {
        c = ' ';
        continue;
      }
      if (j == 27)
      {
        localObject1 = Mode.LOWER;
        c = '\000';
        continue;
      }
      if (j == 28)
      {
        localObject1 = Mode.MIXED;
        c = '\000';
        continue;
      }
      if (j == 29)
      {
        localObject2 = localObject1;
        localObject1 = Mode.PUNCT_SHIFT;
        c = '\000';
        continue;
      }
      if (j == 913)
      {
        paramStringBuilder.append((char)paramArrayOfInt2[i]);
        c = '\000';
        continue;
      }
      c = '\000';
      if (j != 900)
        continue;
      localObject1 = Mode.ALPHA;
      c = '\000';
      continue;
      if (j < 26)
      {
        c = (char)(j + 97);
        continue;
      }
      if (j == 26)
      {
        c = ' ';
        continue;
      }
      if (j == 27)
      {
        localObject2 = localObject1;
        localObject1 = Mode.ALPHA_SHIFT;
        c = '\000';
        continue;
      }
      if (j == 28)
      {
        localObject1 = Mode.MIXED;
        c = '\000';
        continue;
      }
      if (j == 29)
      {
        localObject2 = localObject1;
        localObject1 = Mode.PUNCT_SHIFT;
        c = '\000';
        continue;
      }
      if (j == 913)
      {
        paramStringBuilder.append((char)paramArrayOfInt2[i]);
        c = '\000';
        continue;
      }
      c = '\000';
      if (j != 900)
        continue;
      localObject1 = Mode.ALPHA;
      c = '\000';
      continue;
      if (j < 25)
      {
        c = MIXED_CHARS[j];
        continue;
      }
      if (j == 25)
      {
        localObject1 = Mode.PUNCT;
        c = '\000';
        continue;
      }
      if (j == 26)
      {
        c = ' ';
        continue;
      }
      if (j == 27)
      {
        localObject1 = Mode.LOWER;
        c = '\000';
        continue;
      }
      if (j == 28)
      {
        localObject1 = Mode.ALPHA;
        c = '\000';
        continue;
      }
      if (j == 29)
      {
        localObject2 = localObject1;
        localObject1 = Mode.PUNCT_SHIFT;
        c = '\000';
        continue;
      }
      if (j == 913)
      {
        paramStringBuilder.append((char)paramArrayOfInt2[i]);
        c = '\000';
        continue;
      }
      c = '\000';
      if (j != 900)
        continue;
      localObject1 = Mode.ALPHA;
      c = '\000';
      continue;
      if (j < 29)
      {
        c = PUNCT_CHARS[j];
        continue;
      }
      if (j == 29)
      {
        localObject1 = Mode.ALPHA;
        c = '\000';
        continue;
      }
      if (j == 913)
      {
        paramStringBuilder.append((char)paramArrayOfInt2[i]);
        c = '\000';
        continue;
      }
      c = '\000';
      if (j != 900)
        continue;
      localObject1 = Mode.ALPHA;
      c = '\000';
      continue;
      localObject1 = localObject2;
      if (j < 26)
      {
        c = (char)(j + 65);
        continue;
      }
      if (j == 26)
      {
        c = ' ';
        continue;
      }
      c = '\000';
      if (j != 900)
        continue;
      localObject1 = Mode.ALPHA;
      c = '\000';
      continue;
      localObject1 = localObject2;
      if (j < 29)
      {
        c = PUNCT_CHARS[j];
        continue;
      }
      if (j == 29)
      {
        localObject1 = Mode.ALPHA;
        c = '\000';
        continue;
      }
      if (j == 913)
      {
        paramStringBuilder.append((char)paramArrayOfInt2[i]);
        c = '\000';
        continue;
      }
      c = '\000';
      if (j != 900)
        continue;
      localObject1 = Mode.ALPHA;
      c = '\000';
    }
  }

  private static int numericCompaction(int[] paramArrayOfInt, int paramInt, StringBuilder paramStringBuilder)
    throws FormatException
  {
    int i = 0;
    int j = 0;
    int[] arrayOfInt = new int[15];
    label169: 
    while (true)
    {
      if ((paramInt >= paramArrayOfInt[0]) || (j != 0))
        return paramInt;
      int k = paramInt + 1;
      int m = paramArrayOfInt[paramInt];
      if (k == paramArrayOfInt[0])
        j = 1;
      if (m < 900)
      {
        arrayOfInt[i] = m;
        i++;
        paramInt = k;
      }
      while (true)
      {
        if (((i % 15 != 0) && (m != 902) && (j == 0)) || (i <= 0))
          break label169;
        paramStringBuilder.append(decodeBase900toBase10(arrayOfInt, i));
        i = 0;
        break;
        if ((m == 900) || (m == 901) || (m == 924) || (m == 928) || (m == 923) || (m == 922))
        {
          paramInt = k - 1;
          j = 1;
          continue;
        }
        paramInt = k;
      }
    }
  }

  private static int textCompaction(int[] paramArrayOfInt, int paramInt, StringBuilder paramStringBuilder)
  {
    int[] arrayOfInt1 = new int[2 * (paramArrayOfInt[0] - paramInt)];
    int[] arrayOfInt2 = new int[2 * (paramArrayOfInt[0] - paramInt)];
    int i = 0;
    int j = 0;
    while (true)
    {
      if ((paramInt >= paramArrayOfInt[0]) || (j != 0))
      {
        decodeTextCompaction(arrayOfInt1, arrayOfInt2, i, paramStringBuilder);
        return paramInt;
      }
      int k = paramInt + 1;
      int m = paramArrayOfInt[paramInt];
      if (m < 900)
      {
        arrayOfInt1[i] = (m / 30);
        arrayOfInt1[(i + 1)] = (m % 30);
        i += 2;
        paramInt = k;
        continue;
      }
      switch (m)
      {
      default:
        paramInt = k;
        break;
      case 900:
        int n = i + 1;
        arrayOfInt1[i] = 900;
        i = n;
        paramInt = k;
        break;
      case 901:
      case 902:
      case 922:
      case 923:
      case 924:
      case 928:
        paramInt = k - 1;
        j = 1;
        break;
      case 913:
        arrayOfInt1[i] = 913;
        paramInt = k + 1;
        arrayOfInt2[i] = paramArrayOfInt[k];
        i++;
      }
    }
  }

  private static enum Mode
  {
    static
    {
      ALPHA_SHIFT = new Mode("ALPHA_SHIFT", 4);
      PUNCT_SHIFT = new Mode("PUNCT_SHIFT", 5);
      Mode[] arrayOfMode = new Mode[6];
      arrayOfMode[0] = ALPHA;
      arrayOfMode[1] = LOWER;
      arrayOfMode[2] = MIXED;
      arrayOfMode[3] = PUNCT;
      arrayOfMode[4] = ALPHA_SHIFT;
      arrayOfMode[5] = PUNCT_SHIFT;
      ENUM$VALUES = arrayOfMode;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.decoder.DecodedBitStreamParser
 * JD-Core Version:    0.6.0
 */