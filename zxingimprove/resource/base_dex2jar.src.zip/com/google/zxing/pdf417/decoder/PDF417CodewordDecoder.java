package com.google.zxing.pdf417.decoder;

import com.google.zxing.pdf417.PDF417Common;
import java.lang.reflect.Array;

final class PDF417CodewordDecoder
{
  private static final float[][] RATIOS_TABLE;

  static
  {
    int[] arrayOfInt = { PDF417Common.SYMBOL_TABLE.length, 8 };
    RATIOS_TABLE = (float[][])Array.newInstance(Float.TYPE, arrayOfInt);
    int j;
    int k;
    int m;
    for (int i = 0; ; i++)
    {
      if (i >= PDF417Common.SYMBOL_TABLE.length)
        return;
      j = PDF417Common.SYMBOL_TABLE[i];
      k = j & 0x1;
      m = 0;
      if (m < 8)
        break;
    }
    float f = 0.0F;
    while (true)
    {
      if ((j & 0x1) != k)
      {
        k = j & 0x1;
        RATIOS_TABLE[i][(-1 + (8 - m))] = (f / 17.0F);
        m++;
        break;
      }
      f += 1.0F;
      j >>= 1;
    }
  }

  private static int getBitValue(int[] paramArrayOfInt)
  {
    long l1 = 0L;
    int j;
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfInt.length)
        return (int)l1;
      j = 0;
      if (j < paramArrayOfInt[i])
        break;
    }
    long l2 = l1 << 1;
    if (i % 2 == 0);
    for (int k = 1; ; k = 0)
    {
      l1 = l2 | k;
      j++;
      break;
    }
  }

  private static int getClosestDecodedValue(int[] paramArrayOfInt)
  {
    int i = PDF417Common.getBitCountSum(paramArrayOfInt);
    float[] arrayOfFloat1 = new float[8];
    float f1;
    int k;
    int m;
    for (int j = 0; ; j++)
    {
      if (j >= arrayOfFloat1.length)
      {
        f1 = 3.4028235E+38F;
        k = -1;
        m = 0;
        if (m < RATIOS_TABLE.length)
          break;
        return k;
      }
      paramArrayOfInt[j] /= i;
    }
    float f2 = 0.0F;
    float[] arrayOfFloat2 = RATIOS_TABLE[m];
    for (int n = 0; ; n++)
    {
      if (n >= 8);
      do
      {
        if (f2 < f1)
        {
          f1 = f2;
          k = PDF417Common.SYMBOL_TABLE[m];
        }
        m++;
        break;
        float f3 = arrayOfFloat2[n] - arrayOfFloat1[n];
        f2 += f3 * f3;
      }
      while (f2 >= f1);
    }
  }

  private static int getDecodedCodewordValue(int[] paramArrayOfInt)
  {
    int i = getBitValue(paramArrayOfInt);
    if (PDF417Common.getCodeword(i) == -1)
      i = -1;
    return i;
  }

  static int getDecodedValue(int[] paramArrayOfInt)
  {
    int i = getDecodedCodewordValue(sampleBitCounts(paramArrayOfInt));
    if (i != -1)
      return i;
    return getClosestDecodedValue(paramArrayOfInt);
  }

  private static int[] sampleBitCounts(int[] paramArrayOfInt)
  {
    float f1 = PDF417Common.getBitCountSum(paramArrayOfInt);
    int[] arrayOfInt = new int[8];
    int i = 0;
    int j = 0;
    for (int k = 0; ; k++)
    {
      if (k >= 17)
        return arrayOfInt;
      float f2 = f1 / 34.0F + f1 * k / 17.0F;
      if (j + paramArrayOfInt[i] <= f2)
      {
        j += paramArrayOfInt[i];
        i++;
      }
      arrayOfInt[i] = (1 + arrayOfInt[i]);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.decoder.PDF417CodewordDecoder
 * JD-Core Version:    0.6.0
 */