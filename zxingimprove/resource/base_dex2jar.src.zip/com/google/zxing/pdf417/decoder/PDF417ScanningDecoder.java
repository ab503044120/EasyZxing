package com.google.zxing.pdf417.decoder;

import com.google.zxing.ChecksumException;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.pdf417.PDF417Common;
import com.google.zxing.pdf417.decoder.ec.ErrorCorrection;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Formatter;
import java.util.List;

public final class PDF417ScanningDecoder
{
  private static final int CODEWORD_SKEW_SIZE = 2;
  private static final int MAX_EC_CODEWORDS = 512;
  private static final int MAX_ERRORS = 3;
  private static final ErrorCorrection errorCorrection = new ErrorCorrection();

  private static BoundingBox adjustBoundingBox(DetectionResultRowIndicatorColumn paramDetectionResultRowIndicatorColumn)
    throws NotFoundException, FormatException
  {
    if (paramDetectionResultRowIndicatorColumn == null);
    int[] arrayOfInt;
    do
    {
      return null;
      arrayOfInt = paramDetectionResultRowIndicatorColumn.getRowHeights();
    }
    while (arrayOfInt == null);
    int i = getMax(arrayOfInt);
    int j = 0;
    int k = arrayOfInt.length;
    int m = 0;
    label36: Codeword[] arrayOfCodeword;
    int i1;
    label45: int i2;
    int i3;
    if (m >= k)
    {
      arrayOfCodeword = paramDetectionResultRowIndicatorColumn.getCodewords();
      i1 = 0;
      if ((j > 0) && (arrayOfCodeword[i1] == null))
        break label130;
      i2 = 0;
      i3 = -1 + arrayOfInt.length;
      label66: if (i3 >= 0)
        break label139;
    }
    label71: for (int i4 = -1 + arrayOfCodeword.length; ; i4--)
    {
      if ((i2 <= 0) || (arrayOfCodeword[i4] != null))
      {
        return paramDetectionResultRowIndicatorColumn.getBoundingBox().addMissingRows(j, i2, paramDetectionResultRowIndicatorColumn.isLeft());
        int n = arrayOfInt[m];
        j += i - n;
        if (n > 0)
          break label36;
        m++;
        break;
        j--;
        i1++;
        break label45;
        i2 += i - arrayOfInt[i3];
        if (arrayOfInt[i3] > 0)
          break label71;
        i3--;
        break label66;
      }
      i2--;
    }
  }

  private static void adjustCodewordCount(DetectionResult paramDetectionResult, BarcodeValue[][] paramArrayOfBarcodeValue)
    throws NotFoundException
  {
    int[] arrayOfInt = paramArrayOfBarcodeValue[0][1].getValue();
    int i = paramDetectionResult.getBarcodeColumnCount() * paramDetectionResult.getBarcodeRowCount() - getNumberOfECCodeWords(paramDetectionResult.getBarcodeECLevel());
    if (arrayOfInt.length == 0)
    {
      if ((i < 1) || (i > 928))
        throw NotFoundException.getNotFoundInstance();
      paramArrayOfBarcodeValue[0][1].setValue(i);
    }
    do
      return;
    while (arrayOfInt[0] == i);
    paramArrayOfBarcodeValue[0][1].setValue(i);
  }

  private static int adjustCodewordStartColumn(BitMatrix paramBitMatrix, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4)
  {
    int i = paramInt3;
    int k;
    if (paramBoolean)
    {
      j = -1;
      k = 0;
      if (k < 2)
        break label52;
      paramInt3 = i;
    }
    label52: 
    do
    {
      while (Math.abs(paramInt3 - i) > 2)
      {
        return paramInt3;
        j = 1;
        break;
      }
      i += j;
    }
    while (((!paramBoolean) || (i < paramInt1)) && ((!paramBoolean) && (i < paramInt2) && (paramBoolean == paramBitMatrix.get(i, paramInt4))));
    int j = -j;
    if (paramBoolean);
    for (paramBoolean = false; ; paramBoolean = true)
    {
      k++;
      break;
    }
  }

  private static boolean checkCodewordSkew(int paramInt1, int paramInt2, int paramInt3)
  {
    return (paramInt2 - 2 <= paramInt1) && (paramInt1 <= paramInt3 + 2);
  }

  private static int correctErrors(int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt)
    throws ChecksumException
  {
    if (((paramArrayOfInt2 != null) && (paramArrayOfInt2.length > 3 + paramInt / 2)) || (paramInt < 0) || (paramInt > 512))
      throw ChecksumException.getChecksumInstance();
    return errorCorrection.decode(paramArrayOfInt1, paramInt, paramArrayOfInt2);
  }

  private static BarcodeValue[][] createBarcodeMatrix(DetectionResult paramDetectionResult)
    throws FormatException
  {
    BarcodeValue[][] arrayOfBarcodeValue = (BarcodeValue[][])Array.newInstance(BarcodeValue.class, new int[] { paramDetectionResult.getBarcodeRowCount(), 2 + paramDetectionResult.getBarcodeColumnCount() });
    int i = 0;
    int k;
    DetectionResultColumn[] arrayOfDetectionResultColumn;
    int n;
    if (i >= arrayOfBarcodeValue.length)
    {
      k = 0;
      arrayOfDetectionResultColumn = paramDetectionResult.getDetectionResultColumns();
      int m = arrayOfDetectionResultColumn.length;
      n = 0;
      if (n >= m)
        return arrayOfBarcodeValue;
    }
    else
    {
      for (int j = 0; ; j++)
      {
        if (j >= arrayOfBarcodeValue[i].length)
        {
          i++;
          break;
        }
        arrayOfBarcodeValue[i][j] = new BarcodeValue();
      }
    }
    DetectionResultColumn localDetectionResultColumn = arrayOfDetectionResultColumn[n];
    Codeword[] arrayOfCodeword;
    int i1;
    if (localDetectionResultColumn != null)
    {
      arrayOfCodeword = localDetectionResultColumn.getCodewords();
      i1 = arrayOfCodeword.length;
    }
    for (int i2 = 0; ; i2++)
    {
      if (i2 >= i1)
      {
        k++;
        n++;
        break;
      }
      Codeword localCodeword = arrayOfCodeword[i2];
      if (localCodeword == null)
        continue;
      int i3 = localCodeword.getRowNumber();
      if (i3 < 0)
        continue;
      if (i3 >= arrayOfBarcodeValue.length)
        throw FormatException.getFormatInstance();
      arrayOfBarcodeValue[i3][k].setValue(localCodeword.getValue());
    }
  }

  private static DecoderResult createDecoderResult(DetectionResult paramDetectionResult)
    throws FormatException, ChecksumException, NotFoundException
  {
    BarcodeValue[][] arrayOfBarcodeValue = createBarcodeMatrix(paramDetectionResult);
    adjustCodewordCount(paramDetectionResult, arrayOfBarcodeValue);
    ArrayList localArrayList1 = new ArrayList();
    int[] arrayOfInt1 = new int[paramDetectionResult.getBarcodeRowCount() * paramDetectionResult.getBarcodeColumnCount()];
    ArrayList localArrayList2 = new ArrayList();
    ArrayList localArrayList3 = new ArrayList();
    int i = 0;
    int[][] arrayOfInt;
    if (i >= paramDetectionResult.getBarcodeRowCount())
      arrayOfInt = new int[localArrayList2.size()][];
    for (int m = 0; ; m++)
    {
      if (m >= arrayOfInt.length)
      {
        return createDecoderResultFromAmbiguousValues(paramDetectionResult.getBarcodeECLevel(), arrayOfInt1, PDF417Common.toIntArray(localArrayList1), PDF417Common.toIntArray(localArrayList3), arrayOfInt);
        int j = 0;
        if (j >= paramDetectionResult.getBarcodeColumnCount())
        {
          i++;
          break;
        }
        int[] arrayOfInt2 = arrayOfBarcodeValue[i][(j + 1)].getValue();
        int k = j + i * paramDetectionResult.getBarcodeColumnCount();
        if (arrayOfInt2.length == 0)
          localArrayList1.add(Integer.valueOf(k));
        while (true)
        {
          j++;
          break;
          if (arrayOfInt2.length == 1)
          {
            arrayOfInt1[k] = arrayOfInt2[0];
            continue;
          }
          localArrayList3.add(Integer.valueOf(k));
          localArrayList2.add(arrayOfInt2);
        }
      }
      arrayOfInt[m] = ((int[])localArrayList2.get(m));
    }
  }

  private static DecoderResult createDecoderResultFromAmbiguousValues(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[][] paramArrayOfInt)
    throws FormatException, ChecksumException
  {
    int[] arrayOfInt = new int[paramArrayOfInt3.length];
    int i = 100;
    int j = i - 1;
    if (i <= 0)
      throw ChecksumException.getChecksumInstance();
    int k = 0;
    int m;
    while (true)
    {
      if (k >= arrayOfInt.length);
      try
      {
        DecoderResult localDecoderResult = decodeCodewords(paramArrayOfInt1, paramInt, paramArrayOfInt2);
        return localDecoderResult;
        paramArrayOfInt1[paramArrayOfInt3[k]] = paramArrayOfInt[k][arrayOfInt[k]];
        k++;
      }
      catch (ChecksumException localChecksumException)
      {
        if (arrayOfInt.length == 0)
          throw ChecksumException.getChecksumInstance();
        m = 0;
      }
    }
    while (true)
    {
      if (m >= arrayOfInt.length)
      {
        i = j;
        break;
      }
      if (arrayOfInt[m] < -1 + paramArrayOfInt[m].length)
      {
        arrayOfInt[m] = (1 + arrayOfInt[m]);
        i = j;
        break;
      }
      arrayOfInt[m] = 0;
      if (m == -1 + arrayOfInt.length)
        throw ChecksumException.getChecksumInstance();
      m++;
    }
  }

  public static DecoderResult decode(BitMatrix paramBitMatrix, ResultPoint paramResultPoint1, ResultPoint paramResultPoint2, ResultPoint paramResultPoint3, ResultPoint paramResultPoint4, int paramInt1, int paramInt2)
    throws NotFoundException, FormatException, ChecksumException
  {
    BoundingBox localBoundingBox = new BoundingBox(paramBitMatrix, paramResultPoint1, paramResultPoint2, paramResultPoint3, paramResultPoint4);
    Object localObject1 = null;
    Object localObject2 = null;
    DetectionResult localDetectionResult = null;
    int i = 0;
    label33: int j;
    if (i >= 2)
    {
      j = 1 + localDetectionResult.getBarcodeColumnCount();
      localDetectionResult.setDetectionResultColumn(0, (DetectionResultColumn)localObject1);
      localDetectionResult.setDetectionResultColumn(j, (DetectionResultColumn)localObject2);
      if (localObject1 == null)
        break label205;
    }
    int k;
    label205: for (boolean bool1 = true; ; bool1 = false)
    {
      k = 1;
      if (k <= j)
        break label211;
      return createDecoderResult(localDetectionResult);
      if (paramResultPoint1 != null)
        localObject1 = getRowIndicatorColumn(paramBitMatrix, localBoundingBox, paramResultPoint1, true, paramInt1, paramInt2);
      if (paramResultPoint3 != null)
        localObject2 = getRowIndicatorColumn(paramBitMatrix, localBoundingBox, paramResultPoint3, false, paramInt1, paramInt2);
      localDetectionResult = merge((DetectionResultRowIndicatorColumn)localObject1, (DetectionResultRowIndicatorColumn)localObject2);
      if (localDetectionResult == null)
        throw NotFoundException.getNotFoundInstance();
      if ((i == 0) && (localDetectionResult.getBoundingBox() != null) && ((localDetectionResult.getBoundingBox().getMinY() < localBoundingBox.getMinY()) || (localDetectionResult.getBoundingBox().getMaxY() > localBoundingBox.getMaxY())))
      {
        localBoundingBox = localDetectionResult.getBoundingBox();
        i++;
        break;
      }
      localDetectionResult.setBoundingBox(localBoundingBox);
      break label33;
    }
    label211: if (bool1);
    for (int m = k; ; m = j - k)
    {
      if (localDetectionResult.getDetectionResultColumn(m) == null)
        break label246;
      k++;
      break;
    }
    label246: boolean bool2;
    label266: Object localObject3;
    label279: int n;
    int i1;
    label298: int i2;
    if ((m == 0) || (m == j))
      if (m == 0)
      {
        bool2 = true;
        localObject3 = new DetectionResultRowIndicatorColumn(localBoundingBox, bool2);
        localDetectionResult.setDetectionResultColumn(m, (DetectionResultColumn)localObject3);
        n = -1;
        i1 = localBoundingBox.getMinY();
        if (i1 <= localBoundingBox.getMaxY())
        {
          i2 = getStartColumn(localDetectionResult, m, i1, bool1);
          if ((i2 >= 0) && (i2 <= localBoundingBox.getMaxX()))
            break label372;
          if (n != -1)
            break label368;
        }
      }
    while (true)
    {
      i1++;
      break label298;
      break;
      bool2 = false;
      break label266;
      localObject3 = new DetectionResultColumn(localBoundingBox);
      break label279;
      label368: i2 = n;
      label372: Codeword localCodeword = detectCodeword(paramBitMatrix, localBoundingBox.getMinX(), localBoundingBox.getMaxX(), bool1, i2, i1, paramInt1, paramInt2);
      if (localCodeword == null)
        continue;
      ((DetectionResultColumn)localObject3).setCodeword(i1, localCodeword);
      n = i2;
      int i3 = localCodeword.getWidth();
      paramInt1 = Math.min(paramInt1, i3);
      int i4 = localCodeword.getWidth();
      paramInt2 = Math.max(paramInt2, i4);
    }
  }

  private static DecoderResult decodeCodewords(int[] paramArrayOfInt1, int paramInt, int[] paramArrayOfInt2)
    throws FormatException, ChecksumException
  {
    if (paramArrayOfInt1.length == 0)
      throw FormatException.getFormatInstance();
    int i = 1 << paramInt + 1;
    int j = correctErrors(paramArrayOfInt1, paramArrayOfInt2, i);
    verifyCodewordCount(paramArrayOfInt1, i);
    DecoderResult localDecoderResult = DecodedBitStreamParser.decode(paramArrayOfInt1, String.valueOf(paramInt));
    localDecoderResult.setErrorsCorrected(Integer.valueOf(j));
    localDecoderResult.setErasures(Integer.valueOf(paramArrayOfInt2.length));
    return localDecoderResult;
  }

  private static Codeword detectCodeword(BitMatrix paramBitMatrix, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    int i = adjustCodewordStartColumn(paramBitMatrix, paramInt1, paramInt2, paramBoolean, paramInt3, paramInt4);
    int[] arrayOfInt = getModuleBitCount(paramBitMatrix, paramInt1, paramInt2, paramBoolean, i, paramInt4);
    if (arrayOfInt == null)
      return null;
    int j = PDF417Common.getBitCountSum(arrayOfInt);
    int n;
    if (paramBoolean)
    {
      n = i + j;
      if (!checkCodewordSkew(j, paramInt5, paramInt6))
        return null;
    }
    else
    {
      for (int k = 0; ; k++)
      {
        if (k >= arrayOfInt.length / 2)
        {
          n = i;
          i = n - j;
          break;
        }
        int m = arrayOfInt[k];
        arrayOfInt[k] = arrayOfInt[(-1 + arrayOfInt.length - k)];
        arrayOfInt[(-1 + arrayOfInt.length - k)] = m;
      }
    }
    int i1 = PDF417CodewordDecoder.getDecodedValue(arrayOfInt);
    int i2 = PDF417Common.getCodeword(i1);
    if (i2 == -1)
      return null;
    return new Codeword(i, n, getCodewordBucketNumber(i1), i2);
  }

  private static BarcodeMetadata getBarcodeMetadata(DetectionResultRowIndicatorColumn paramDetectionResultRowIndicatorColumn1, DetectionResultRowIndicatorColumn paramDetectionResultRowIndicatorColumn2)
  {
    BarcodeMetadata localBarcodeMetadata1;
    if (paramDetectionResultRowIndicatorColumn1 != null)
    {
      localBarcodeMetadata1 = paramDetectionResultRowIndicatorColumn1.getBarcodeMetadata();
      if (localBarcodeMetadata1 != null);
    }
    else if (paramDetectionResultRowIndicatorColumn2 != null);
    BarcodeMetadata localBarcodeMetadata2;
    do
    {
      return null;
      return paramDetectionResultRowIndicatorColumn2.getBarcodeMetadata();
      if (paramDetectionResultRowIndicatorColumn2 != null)
      {
        localBarcodeMetadata2 = paramDetectionResultRowIndicatorColumn2.getBarcodeMetadata();
        if (localBarcodeMetadata2 != null)
          continue;
      }
      else
      {
        return localBarcodeMetadata1;
      }
    }
    while ((localBarcodeMetadata1.getColumnCount() != localBarcodeMetadata2.getColumnCount()) && (localBarcodeMetadata1.getErrorCorrectionLevel() != localBarcodeMetadata2.getErrorCorrectionLevel()) && (localBarcodeMetadata1.getRowCount() != localBarcodeMetadata2.getRowCount()));
    return localBarcodeMetadata1;
  }

  private static int[] getBitCountForCodeword(int paramInt)
  {
    int[] arrayOfInt = new int[8];
    int i = 0;
    int j = -1 + arrayOfInt.length;
    while (true)
    {
      if ((paramInt & 0x1) != i)
      {
        i = paramInt & 0x1;
        j--;
        if (j < 0)
          return arrayOfInt;
      }
      arrayOfInt[j] = (1 + arrayOfInt[j]);
      paramInt >>= 1;
    }
  }

  private static int getCodewordBucketNumber(int paramInt)
  {
    return getCodewordBucketNumber(getBitCountForCodeword(paramInt));
  }

  private static int getCodewordBucketNumber(int[] paramArrayOfInt)
  {
    return (9 + (paramArrayOfInt[0] - paramArrayOfInt[2] + paramArrayOfInt[4] - paramArrayOfInt[6])) % 9;
  }

  private static int getMax(int[] paramArrayOfInt)
  {
    int i = -1;
    int j = paramArrayOfInt.length;
    for (int k = 0; ; k++)
    {
      if (k >= j)
        return i;
      i = Math.max(i, paramArrayOfInt[k]);
    }
  }

  private static int[] getModuleBitCount(BitMatrix paramBitMatrix, int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3, int paramInt4)
  {
    int i = paramInt3;
    int[] arrayOfInt = new int[8];
    int j = 0;
    int k;
    if (paramBoolean)
    {
      k = 1;
      bool = paramBoolean;
    }
    while (true)
    {
      if (((paramBoolean) && (i < paramInt2)) || ((paramBoolean) || (i < paramInt1) || (j >= arrayOfInt.length)))
      {
        if ((j != arrayOfInt.length) && (((!paramBoolean) || (i != paramInt2)) && ((paramBoolean) || (i != paramInt1) || (j != -1 + arrayOfInt.length))))
          break label153;
        return arrayOfInt;
        k = -1;
        break;
      }
      if (paramBitMatrix.get(i, paramInt4) != bool)
        break label133;
      arrayOfInt[j] = (1 + arrayOfInt[j]);
      i += k;
    }
    label133: j++;
    if (bool);
    for (boolean bool = false; ; bool = true)
      break;
    label153: return null;
  }

  private static int getNumberOfECCodeWords(int paramInt)
  {
    return 2 << paramInt;
  }

  private static DetectionResultRowIndicatorColumn getRowIndicatorColumn(BitMatrix paramBitMatrix, BoundingBox paramBoundingBox, ResultPoint paramResultPoint, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    DetectionResultRowIndicatorColumn localDetectionResultRowIndicatorColumn = new DetectionResultRowIndicatorColumn(paramBoundingBox, paramBoolean);
    int i = 0;
    if (i >= 2)
      return localDetectionResultRowIndicatorColumn;
    if (i == 0);
    int m;
    for (int j = 1; ; j = -1)
    {
      k = (int)paramResultPoint.getX();
      m = (int)paramResultPoint.getY();
      if ((m <= paramBoundingBox.getMaxY()) && (m >= paramBoundingBox.getMinY()))
        break label75;
      i++;
      break;
    }
    label75: Codeword localCodeword = detectCodeword(paramBitMatrix, 0, paramBitMatrix.getWidth(), paramBoolean, k, m, paramInt1, paramInt2);
    if (localCodeword != null)
    {
      localDetectionResultRowIndicatorColumn.setCodeword(m, localCodeword);
      if (!paramBoolean)
        break label130;
    }
    label130: for (int k = localCodeword.getStartX(); ; k = localCodeword.getEndX())
    {
      m += j;
      break;
    }
  }

  private static int getStartColumn(DetectionResult paramDetectionResult, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int i;
    if (paramBoolean)
      i = 1;
    while (true)
    {
      boolean bool = isValidBarcodeColumn(paramDetectionResult, paramInt1 - i);
      Codeword localCodeword1 = null;
      if (bool)
        localCodeword1 = paramDetectionResult.getDetectionResultColumn(paramInt1 - i).getCodeword(paramInt2);
      if (localCodeword1 == null)
        break;
      if (paramBoolean)
      {
        return localCodeword1.getEndX();
        i = -1;
        continue;
      }
      return localCodeword1.getStartX();
    }
    Codeword localCodeword2 = paramDetectionResult.getDetectionResultColumn(paramInt1).getCodewordNearby(paramInt2);
    if (localCodeword2 != null)
    {
      if (paramBoolean)
        return localCodeword2.getStartX();
      return localCodeword2.getEndX();
    }
    if (isValidBarcodeColumn(paramDetectionResult, paramInt1 - i))
      localCodeword2 = paramDetectionResult.getDetectionResultColumn(paramInt1 - i).getCodewordNearby(paramInt2);
    if (localCodeword2 != null)
    {
      if (paramBoolean)
        return localCodeword2.getEndX();
      return localCodeword2.getStartX();
    }
    int j = 0;
    if (!isValidBarcodeColumn(paramDetectionResult, paramInt1 - i))
    {
      if (paramBoolean)
        return paramDetectionResult.getBoundingBox().getMinX();
    }
    else
    {
      paramInt1 -= i;
      Codeword[] arrayOfCodeword = paramDetectionResult.getDetectionResultColumn(paramInt1).getCodewords();
      int k = arrayOfCodeword.length;
      for (int m = 0; ; m++)
      {
        if (m >= k)
        {
          j++;
          break;
        }
        Codeword localCodeword3 = arrayOfCodeword[m];
        if (localCodeword3 == null)
          continue;
        if (paramBoolean);
        for (int n = localCodeword3.getEndX(); ; n = localCodeword3.getStartX())
          return n + i * j * (localCodeword3.getEndX() - localCodeword3.getStartX());
      }
    }
    return paramDetectionResult.getBoundingBox().getMaxX();
  }

  private static boolean isValidBarcodeColumn(DetectionResult paramDetectionResult, int paramInt)
  {
    return (paramInt >= 0) && (paramInt <= 1 + paramDetectionResult.getBarcodeColumnCount());
  }

  private static DetectionResult merge(DetectionResultRowIndicatorColumn paramDetectionResultRowIndicatorColumn1, DetectionResultRowIndicatorColumn paramDetectionResultRowIndicatorColumn2)
    throws NotFoundException, FormatException
  {
    if ((paramDetectionResultRowIndicatorColumn1 == null) && (paramDetectionResultRowIndicatorColumn2 == null));
    BarcodeMetadata localBarcodeMetadata;
    do
    {
      return null;
      localBarcodeMetadata = getBarcodeMetadata(paramDetectionResultRowIndicatorColumn1, paramDetectionResultRowIndicatorColumn2);
    }
    while (localBarcodeMetadata == null);
    return new DetectionResult(localBarcodeMetadata, BoundingBox.merge(adjustBoundingBox(paramDetectionResultRowIndicatorColumn1), adjustBoundingBox(paramDetectionResultRowIndicatorColumn2)));
  }

  public static String toString(BarcodeValue[][] paramArrayOfBarcodeValue)
  {
    Formatter localFormatter = new Formatter();
    int j;
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfBarcodeValue.length)
      {
        String str = localFormatter.toString();
        localFormatter.close();
        return str;
      }
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Integer.valueOf(i);
      localFormatter.format("Row %2d: ", arrayOfObject1);
      j = 0;
      if (j < paramArrayOfBarcodeValue[i].length)
        break;
      localFormatter.format("%n", new Object[0]);
    }
    BarcodeValue localBarcodeValue = paramArrayOfBarcodeValue[i][j];
    if (localBarcodeValue.getValue().length == 0)
      localFormatter.format("        ", null);
    while (true)
    {
      j++;
      break;
      Object[] arrayOfObject2 = new Object[2];
      arrayOfObject2[0] = Integer.valueOf(localBarcodeValue.getValue()[0]);
      arrayOfObject2[1] = localBarcodeValue.getConfidence(localBarcodeValue.getValue()[0]);
      localFormatter.format("%4d(%2d)", arrayOfObject2);
    }
  }

  private static void verifyCodewordCount(int[] paramArrayOfInt, int paramInt)
    throws FormatException
  {
    if (paramArrayOfInt.length < 4)
      throw FormatException.getFormatInstance();
    int i = paramArrayOfInt[0];
    if (i > paramArrayOfInt.length)
      throw FormatException.getFormatInstance();
    if (i == 0)
    {
      if (paramInt < paramArrayOfInt.length)
        paramArrayOfInt[0] = (paramArrayOfInt.length - paramInt);
    }
    else
      return;
    throw FormatException.getFormatInstance();
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.decoder.PDF417ScanningDecoder
 * JD-Core Version:    0.6.0
 */