package com.google.zxing.pdf417.decoder;

import java.util.Formatter;

final class DetectionResult
{
  private static final int ADJUST_ROW_NUMBER_SKIP = 2;
  private final int barcodeColumnCount;
  private final BarcodeMetadata barcodeMetadata;
  private BoundingBox boundingBox;
  private final DetectionResultColumn[] detectionResultColumns;

  DetectionResult(BarcodeMetadata paramBarcodeMetadata, BoundingBox paramBoundingBox)
  {
    this.barcodeMetadata = paramBarcodeMetadata;
    this.barcodeColumnCount = paramBarcodeMetadata.getColumnCount();
    this.boundingBox = paramBoundingBox;
    this.detectionResultColumns = new DetectionResultColumn[2 + this.barcodeColumnCount];
  }

  private void adjustIndicatorColumnRowNumbers(DetectionResultColumn paramDetectionResultColumn)
  {
    if (paramDetectionResultColumn != null)
      ((DetectionResultRowIndicatorColumn)paramDetectionResultColumn).adjustCompleteIndicatorColumnRowNumbers(this.barcodeMetadata);
  }

  private static boolean adjustRowNumber(Codeword paramCodeword1, Codeword paramCodeword2)
  {
    if (paramCodeword2 == null);
    do
      return false;
    while ((!paramCodeword2.hasValidRowNumber()) || (paramCodeword2.getBucket() != paramCodeword1.getBucket()));
    paramCodeword1.setRowNumber(paramCodeword2.getRowNumber());
    return true;
  }

  private static int adjustRowNumberIfValid(int paramInt1, int paramInt2, Codeword paramCodeword)
  {
    if (paramCodeword == null)
      return paramInt2;
    if (!paramCodeword.hasValidRowNumber())
    {
      if (!paramCodeword.isValidRowNumber(paramInt1))
        break label30;
      paramCodeword.setRowNumber(paramInt1);
    }
    label30: for (paramInt2 = 0; ; paramInt2++)
      return paramInt2;
  }

  private int adjustRowNumbers()
  {
    int i = adjustRowNumbersByRow();
    if (i == 0)
      i = 0;
    int j;
    Codeword[] arrayOfCodeword;
    int k;
    while (true)
    {
      return i;
      for (j = 1; j < 1 + this.barcodeColumnCount; j++)
      {
        arrayOfCodeword = this.detectionResultColumns[j].getCodewords();
        k = 0;
        if (k < arrayOfCodeword.length)
          break label51;
      }
    }
    label51: if (arrayOfCodeword[k] == null);
    while (true)
    {
      k++;
      break;
      if (arrayOfCodeword[k].hasValidRowNumber())
        continue;
      adjustRowNumbers(j, k, arrayOfCodeword);
    }
  }

  private void adjustRowNumbers(int paramInt1, int paramInt2, Codeword[] paramArrayOfCodeword)
  {
    int i = 0;
    Codeword localCodeword = paramArrayOfCodeword[paramInt2];
    Codeword[] arrayOfCodeword1 = this.detectionResultColumns[(paramInt1 - 1)].getCodewords();
    Codeword[] arrayOfCodeword2 = arrayOfCodeword1;
    if (this.detectionResultColumns[(paramInt1 + 1)] != null)
      arrayOfCodeword2 = this.detectionResultColumns[(paramInt1 + 1)].getCodewords();
    Codeword[] arrayOfCodeword3 = new Codeword[14];
    arrayOfCodeword3[2] = arrayOfCodeword1[paramInt2];
    arrayOfCodeword3[3] = arrayOfCodeword2[paramInt2];
    if (paramInt2 > 0)
    {
      arrayOfCodeword3[0] = paramArrayOfCodeword[(paramInt2 - 1)];
      arrayOfCodeword3[4] = arrayOfCodeword1[(paramInt2 - 1)];
      arrayOfCodeword3[5] = arrayOfCodeword2[(paramInt2 - 1)];
    }
    if (paramInt2 > 1)
    {
      arrayOfCodeword3[8] = paramArrayOfCodeword[(paramInt2 - 2)];
      arrayOfCodeword3[10] = arrayOfCodeword1[(paramInt2 - 2)];
      arrayOfCodeword3[11] = arrayOfCodeword2[(paramInt2 - 2)];
    }
    if (paramInt2 < -1 + paramArrayOfCodeword.length)
    {
      arrayOfCodeword3[1] = paramArrayOfCodeword[(paramInt2 + 1)];
      arrayOfCodeword3[6] = arrayOfCodeword1[(paramInt2 + 1)];
      arrayOfCodeword3[7] = arrayOfCodeword2[(paramInt2 + 1)];
    }
    if (paramInt2 < -2 + paramArrayOfCodeword.length)
    {
      arrayOfCodeword3[9] = paramArrayOfCodeword[(paramInt2 + 2)];
      arrayOfCodeword3[12] = arrayOfCodeword1[(paramInt2 + 2)];
      arrayOfCodeword3[13] = arrayOfCodeword2[(paramInt2 + 2)];
    }
    int j = arrayOfCodeword3.length;
    while (true)
    {
      if (i >= j);
      do
        return;
      while (adjustRowNumber(localCodeword, arrayOfCodeword3[i]));
      i++;
    }
  }

  private int adjustRowNumbersByRow()
  {
    adjustRowNumbersFromBothRI();
    return adjustRowNumbersFromLRI() + adjustRowNumbersFromRRI();
  }

  private void adjustRowNumbersFromBothRI()
  {
    if ((this.detectionResultColumns[0] == null) || (this.detectionResultColumns[(1 + this.barcodeColumnCount)] == null));
    Codeword[] arrayOfCodeword1;
    int i;
    int j;
    while (true)
    {
      return;
      arrayOfCodeword1 = this.detectionResultColumns[0].getCodewords();
      Codeword[] arrayOfCodeword2 = this.detectionResultColumns[(1 + this.barcodeColumnCount)].getCodewords();
      for (i = 0; i < arrayOfCodeword1.length; i++)
      {
        if ((arrayOfCodeword1[i] == null) || (arrayOfCodeword2[i] == null) || (arrayOfCodeword1[i].getRowNumber() != arrayOfCodeword2[i].getRowNumber()))
          continue;
        j = 1;
        if (j <= this.barcodeColumnCount)
          break label102;
      }
    }
    label102: Codeword localCodeword = this.detectionResultColumns[j].getCodewords()[i];
    if (localCodeword == null);
    while (true)
    {
      j++;
      break;
      localCodeword.setRowNumber(arrayOfCodeword1[i].getRowNumber());
      if (localCodeword.hasValidRowNumber())
        continue;
      this.detectionResultColumns[j].getCodewords()[i] = null;
    }
  }

  private int adjustRowNumbersFromLRI()
  {
    if (this.detectionResultColumns[0] == null)
    {
      i = 0;
      return i;
    }
    int i = 0;
    Codeword[] arrayOfCodeword = this.detectionResultColumns[0].getCodewords();
    int j = 0;
    label27: if (j < arrayOfCodeword.length)
      if (arrayOfCodeword[j] != null)
        break label45;
    while (true)
    {
      j++;
      break label27;
      break;
      label45: int k = arrayOfCodeword[j].getRowNumber();
      int m = 0;
      for (int n = 1; (n < 1 + this.barcodeColumnCount) && (m < 2); n++)
      {
        Codeword localCodeword = this.detectionResultColumns[n].getCodewords()[j];
        if (localCodeword == null)
          continue;
        m = adjustRowNumberIfValid(k, m, localCodeword);
        if (localCodeword.hasValidRowNumber())
          continue;
        i++;
      }
    }
  }

  private int adjustRowNumbersFromRRI()
  {
    if (this.detectionResultColumns[(1 + this.barcodeColumnCount)] == null)
    {
      i = 0;
      return i;
    }
    int i = 0;
    Codeword[] arrayOfCodeword = this.detectionResultColumns[(1 + this.barcodeColumnCount)].getCodewords();
    int j = 0;
    label37: if (j < arrayOfCodeword.length)
      if (arrayOfCodeword[j] != null)
        break label55;
    while (true)
    {
      j++;
      break label37;
      break;
      label55: int k = arrayOfCodeword[j].getRowNumber();
      int m = 0;
      for (int n = 1 + this.barcodeColumnCount; (n > 0) && (m < 2); n--)
      {
        Codeword localCodeword = this.detectionResultColumns[n].getCodewords()[j];
        if (localCodeword == null)
          continue;
        m = adjustRowNumberIfValid(k, m, localCodeword);
        if (localCodeword.hasValidRowNumber())
          continue;
        i++;
      }
    }
  }

  int getBarcodeColumnCount()
  {
    return this.barcodeColumnCount;
  }

  int getBarcodeECLevel()
  {
    return this.barcodeMetadata.getErrorCorrectionLevel();
  }

  int getBarcodeRowCount()
  {
    return this.barcodeMetadata.getRowCount();
  }

  BoundingBox getBoundingBox()
  {
    return this.boundingBox;
  }

  DetectionResultColumn getDetectionResultColumn(int paramInt)
  {
    return this.detectionResultColumns[paramInt];
  }

  DetectionResultColumn[] getDetectionResultColumns()
  {
    adjustIndicatorColumnRowNumbers(this.detectionResultColumns[0]);
    adjustIndicatorColumnRowNumbers(this.detectionResultColumns[(1 + this.barcodeColumnCount)]);
    int i = 928;
    int j;
    do
    {
      j = i;
      i = adjustRowNumbers();
    }
    while ((i > 0) && (i < j));
    return this.detectionResultColumns;
  }

  public void setBoundingBox(BoundingBox paramBoundingBox)
  {
    this.boundingBox = paramBoundingBox;
  }

  void setDetectionResultColumn(int paramInt, DetectionResultColumn paramDetectionResultColumn)
  {
    this.detectionResultColumns[paramInt] = paramDetectionResultColumn;
  }

  public String toString()
  {
    DetectionResultColumn localDetectionResultColumn = this.detectionResultColumns[0];
    if (localDetectionResultColumn == null)
      localDetectionResultColumn = this.detectionResultColumns[(1 + this.barcodeColumnCount)];
    Formatter localFormatter = new Formatter();
    int j;
    for (int i = 0; ; i++)
    {
      if (i >= localDetectionResultColumn.getCodewords().length)
      {
        String str = localFormatter.toString();
        localFormatter.close();
        return str;
      }
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Integer.valueOf(i);
      localFormatter.format("CW %3d:", arrayOfObject1);
      j = 0;
      if (j < 2 + this.barcodeColumnCount)
        break;
      localFormatter.format("%n", new Object[0]);
    }
    if (this.detectionResultColumns[j] == null)
      localFormatter.format("    |   ", new Object[0]);
    while (true)
    {
      j++;
      break;
      Codeword localCodeword = this.detectionResultColumns[j].getCodewords()[i];
      if (localCodeword == null)
      {
        localFormatter.format("    |   ", new Object[0]);
        continue;
      }
      Object[] arrayOfObject2 = new Object[2];
      arrayOfObject2[0] = Integer.valueOf(localCodeword.getRowNumber());
      arrayOfObject2[1] = Integer.valueOf(localCodeword.getValue());
      localFormatter.format(" %3d|%3d", arrayOfObject2);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.decoder.DetectionResult
 * JD-Core Version:    0.6.0
 */