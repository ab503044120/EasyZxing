package com.google.zxing.pdf417.decoder;

import com.google.zxing.pdf417.PDF417Common;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

final class BarcodeValue
{
  private final Map<Integer, Integer> values = new HashMap();

  public Integer getConfidence(int paramInt)
  {
    return (Integer)this.values.get(Integer.valueOf(paramInt));
  }

  int[] getValue()
  {
    int i = -1;
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.values.entrySet().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return PDF417Common.toIntArray(localArrayList);
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (((Integer)localEntry.getValue()).intValue() > i)
      {
        i = ((Integer)localEntry.getValue()).intValue();
        localArrayList.clear();
        localArrayList.add((Integer)localEntry.getKey());
        continue;
      }
      if (((Integer)localEntry.getValue()).intValue() != i)
        continue;
      localArrayList.add((Integer)localEntry.getKey());
    }
  }

  void setValue(int paramInt)
  {
    Integer localInteger1 = (Integer)this.values.get(Integer.valueOf(paramInt));
    if (localInteger1 == null)
      localInteger1 = Integer.valueOf(0);
    Integer localInteger2 = Integer.valueOf(1 + localInteger1.intValue());
    this.values.put(Integer.valueOf(paramInt), localInteger2);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.decoder.BarcodeValue
 * JD-Core Version:    0.6.0
 */