package com.google.zxing.pdf417.decoder;

import com.google.zxing.FormatException;
import com.google.zxing.ResultPoint;

final class DetectionResultRowIndicatorColumn extends DetectionResultColumn
{
  private final boolean isLeft;

  DetectionResultRowIndicatorColumn(BoundingBox paramBoundingBox, boolean paramBoolean)
  {
    super(paramBoundingBox);
    this.isLeft = paramBoolean;
  }

  private void removeIncorrectCodewords(Codeword[] paramArrayOfCodeword, BarcodeMetadata paramBarcodeMetadata)
  {
    int i = 0;
    if (i >= paramArrayOfCodeword.length)
      return;
    Codeword localCodeword = paramArrayOfCodeword[i];
    if (paramArrayOfCodeword[i] == null);
    while (true)
    {
      i++;
      break;
      int j = localCodeword.getValue() % 30;
      int k = localCodeword.getRowNumber();
      if (k > paramBarcodeMetadata.getRowCount())
      {
        paramArrayOfCodeword[i] = null;
        continue;
      }
      if (!this.isLeft)
        k += 2;
      switch (k % 3)
      {
      default:
        break;
      case 0:
        if (1 + j * 3 == paramBarcodeMetadata.getRowCountUpperPart())
          continue;
        paramArrayOfCodeword[i] = null;
        break;
      case 1:
        if ((j / 3 == paramBarcodeMetadata.getErrorCorrectionLevel()) && (j % 3 == paramBarcodeMetadata.getRowCountLowerPart()))
          continue;
        paramArrayOfCodeword[i] = null;
        break;
      case 2:
        if (j + 1 == paramBarcodeMetadata.getColumnCount())
          continue;
        paramArrayOfCodeword[i] = null;
      }
    }
  }

  int adjustCompleteIndicatorColumnRowNumbers(BarcodeMetadata paramBarcodeMetadata)
  {
    Codeword[] arrayOfCodeword = getCodewords();
    setRowNumbers();
    removeIncorrectCodewords(arrayOfCodeword, paramBarcodeMetadata);
    BoundingBox localBoundingBox = getBoundingBox();
    ResultPoint localResultPoint1;
    if (this.isLeft)
    {
      localResultPoint1 = localBoundingBox.getTopLeft();
      if (!this.isLeft)
        break label122;
    }
    int k;
    int m;
    int n;
    int i1;
    label122: for (ResultPoint localResultPoint2 = localBoundingBox.getBottomLeft(); ; localResultPoint2 = localBoundingBox.getBottomRight())
    {
      int i = imageRowToCodewordIndex((int)localResultPoint1.getY());
      int j = imageRowToCodewordIndex((int)localResultPoint2.getY());
      float f = (j - i) / paramBarcodeMetadata.getRowCount();
      k = -1;
      m = 1;
      n = 0;
      i1 = i;
      if (i1 < j)
        break label131;
      return (int)(0.5D + f);
      localResultPoint1 = localBoundingBox.getTopRight();
      break;
    }
    label131: if (arrayOfCodeword[i1] == null);
    while (true)
    {
      i1++;
      break;
      Codeword localCodeword = arrayOfCodeword[i1];
      int i2 = localCodeword.getRowNumber() - k;
      if (i2 == 0)
      {
        n++;
        continue;
      }
      if (i2 == 1)
      {
        m = Math.max(m, n);
        n = 1;
        k = localCodeword.getRowNumber();
        continue;
      }
      if ((i2 < 0) || (localCodeword.getRowNumber() >= paramBarcodeMetadata.getRowCount()) || (i2 > i1))
      {
        arrayOfCodeword[i1] = null;
        continue;
      }
      int i3;
      if (m > 2)
      {
        i3 = i2 * (m - 2);
        label246: if (i3 < i1)
          break label291;
      }
      int i5;
      label291: for (int i4 = 1; ; i4 = 0)
      {
        i5 = 1;
        if ((i5 <= i3) && (i4 == 0))
          break label297;
        if (i4 == 0)
          break label322;
        arrayOfCodeword[i1] = null;
        break;
        i3 = i2;
        break label246;
      }
      label297: if (arrayOfCodeword[(i1 - i5)] != null);
      for (i4 = 1; ; i4 = 0)
      {
        i5++;
        break;
      }
      label322: k = localCodeword.getRowNumber();
      n = 1;
    }
  }

  int adjustIncompleteIndicatorColumnRowNumbers(BarcodeMetadata paramBarcodeMetadata)
  {
    BoundingBox localBoundingBox = getBoundingBox();
    ResultPoint localResultPoint1;
    if (this.isLeft)
    {
      localResultPoint1 = localBoundingBox.getTopLeft();
      if (!this.isLeft)
        break label110;
    }
    Codeword[] arrayOfCodeword;
    int k;
    int m;
    int n;
    int i1;
    label110: for (ResultPoint localResultPoint2 = localBoundingBox.getBottomLeft(); ; localResultPoint2 = localBoundingBox.getBottomRight())
    {
      int i = imageRowToCodewordIndex((int)localResultPoint1.getY());
      int j = imageRowToCodewordIndex((int)localResultPoint2.getY());
      float f = (j - i) / paramBarcodeMetadata.getRowCount();
      arrayOfCodeword = getCodewords();
      k = -1;
      m = 1;
      n = 0;
      i1 = i;
      if (i1 < j)
        break label119;
      return (int)(0.5D + f);
      localResultPoint1 = localBoundingBox.getTopRight();
      break;
    }
    label119: if (arrayOfCodeword[i1] == null);
    while (true)
    {
      i1++;
      break;
      Codeword localCodeword = arrayOfCodeword[i1];
      localCodeword.setRowNumberAsRowIndicatorColumn();
      int i2 = localCodeword.getRowNumber() - k;
      if (i2 == 0)
      {
        n++;
        continue;
      }
      if (i2 == 1)
      {
        m = Math.max(m, n);
        n = 1;
        k = localCodeword.getRowNumber();
        continue;
      }
      if (localCodeword.getRowNumber() >= paramBarcodeMetadata.getRowCount())
      {
        arrayOfCodeword[i1] = null;
        continue;
      }
      k = localCodeword.getRowNumber();
      n = 1;
    }
  }

  BarcodeMetadata getBarcodeMetadata()
  {
    Codeword[] arrayOfCodeword = getCodewords();
    BarcodeValue localBarcodeValue1 = new BarcodeValue();
    BarcodeValue localBarcodeValue2 = new BarcodeValue();
    BarcodeValue localBarcodeValue3 = new BarcodeValue();
    BarcodeValue localBarcodeValue4 = new BarcodeValue();
    int i = arrayOfCodeword.length;
    int j = 0;
    if (j >= i)
    {
      if ((localBarcodeValue1.getValue().length == 0) || (localBarcodeValue2.getValue().length == 0) || (localBarcodeValue3.getValue().length == 0) || (localBarcodeValue4.getValue().length == 0) || (localBarcodeValue1.getValue()[0] < 1) || (localBarcodeValue2.getValue()[0] + localBarcodeValue3.getValue()[0] < 3) || (localBarcodeValue2.getValue()[0] + localBarcodeValue3.getValue()[0] > 90))
        return null;
    }
    else
    {
      Codeword localCodeword = arrayOfCodeword[j];
      if (localCodeword == null);
      while (true)
      {
        j++;
        break;
        localCodeword.setRowNumberAsRowIndicatorColumn();
        int k = localCodeword.getValue() % 30;
        int m = localCodeword.getRowNumber();
        if (!this.isLeft)
          m += 2;
        switch (m % 3)
        {
        default:
          break;
        case 0:
          localBarcodeValue2.setValue(1 + k * 3);
          break;
        case 1:
          localBarcodeValue4.setValue(k / 3);
          localBarcodeValue3.setValue(k % 3);
          break;
        case 2:
          localBarcodeValue1.setValue(k + 1);
        }
      }
    }
    BarcodeMetadata localBarcodeMetadata = new BarcodeMetadata(localBarcodeValue1.getValue()[0], localBarcodeValue2.getValue()[0], localBarcodeValue3.getValue()[0], localBarcodeValue4.getValue()[0]);
    removeIncorrectCodewords(arrayOfCodeword, localBarcodeMetadata);
    return localBarcodeMetadata;
  }

  int[] getRowHeights()
    throws FormatException
  {
    BarcodeMetadata localBarcodeMetadata = getBarcodeMetadata();
    int[] arrayOfInt;
    if (localBarcodeMetadata == null)
      arrayOfInt = null;
    while (true)
    {
      return arrayOfInt;
      adjustIncompleteIndicatorColumnRowNumbers(localBarcodeMetadata);
      arrayOfInt = new int[localBarcodeMetadata.getRowCount()];
      for (Codeword localCodeword : getCodewords())
      {
        if (localCodeword == null)
          continue;
        int k = localCodeword.getRowNumber();
        if (k >= arrayOfInt.length)
          throw FormatException.getFormatInstance();
        arrayOfInt[k] = (1 + arrayOfInt[k]);
      }
    }
  }

  boolean isLeft()
  {
    return this.isLeft;
  }

  void setRowNumbers()
  {
    Codeword[] arrayOfCodeword = getCodewords();
    int i = arrayOfCodeword.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return;
      Codeword localCodeword = arrayOfCodeword[j];
      if (localCodeword == null)
        continue;
      localCodeword.setRowNumberAsRowIndicatorColumn();
    }
  }

  public String toString()
  {
    return "IsLeft: " + this.isLeft + '\n' + super.toString();
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.decoder.DetectionResultRowIndicatorColumn
 * JD-Core Version:    0.6.0
 */