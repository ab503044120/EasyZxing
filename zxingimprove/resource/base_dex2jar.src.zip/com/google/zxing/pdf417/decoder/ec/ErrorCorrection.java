package com.google.zxing.pdf417.decoder.ec;

import com.google.zxing.ChecksumException;

public final class ErrorCorrection
{
  private final ModulusGF field = ModulusGF.PDF417_GF;

  private int[] findErrorLocations(ModulusPoly paramModulusPoly)
    throws ChecksumException
  {
    int i = paramModulusPoly.getDegree();
    int[] arrayOfInt = new int[i];
    int j = 0;
    for (int k = 1; ; k++)
    {
      if ((k >= this.field.getSize()) || (j >= i))
      {
        if (j == i)
          break;
        throw ChecksumException.getChecksumInstance();
      }
      if (paramModulusPoly.evaluateAt(k) != 0)
        continue;
      arrayOfInt[j] = this.field.inverse(k);
      j++;
    }
    return arrayOfInt;
  }

  private int[] findErrorMagnitudes(ModulusPoly paramModulusPoly1, ModulusPoly paramModulusPoly2, int[] paramArrayOfInt)
  {
    int i = paramModulusPoly2.getDegree();
    int[] arrayOfInt1 = new int[i];
    int j = 1;
    ModulusPoly localModulusPoly;
    int k;
    int[] arrayOfInt2;
    if (j > i)
    {
      localModulusPoly = new ModulusPoly(this.field, arrayOfInt1);
      k = paramArrayOfInt.length;
      arrayOfInt2 = new int[k];
    }
    for (int m = 0; ; m++)
    {
      if (m >= k)
      {
        return arrayOfInt2;
        arrayOfInt1[(i - j)] = this.field.multiply(j, paramModulusPoly2.getCoefficient(j));
        j++;
        break;
      }
      int n = this.field.inverse(paramArrayOfInt[m]);
      int i1 = this.field.subtract(0, paramModulusPoly1.evaluateAt(n));
      int i2 = this.field.inverse(localModulusPoly.evaluateAt(n));
      arrayOfInt2[m] = this.field.multiply(i1, i2);
    }
  }

  private ModulusPoly[] runEuclideanAlgorithm(ModulusPoly paramModulusPoly1, ModulusPoly paramModulusPoly2, int paramInt)
    throws ChecksumException
  {
    if (paramModulusPoly1.getDegree() < paramModulusPoly2.getDegree())
    {
      ModulusPoly localModulusPoly3 = paramModulusPoly1;
      paramModulusPoly1 = paramModulusPoly2;
      paramModulusPoly2 = localModulusPoly3;
    }
    Object localObject1 = paramModulusPoly1;
    Object localObject2 = paramModulusPoly2;
    Object localObject3 = this.field.getZero();
    ModulusPoly localModulusPoly1 = this.field.getOne();
    int n;
    if (((ModulusPoly)localObject2).getDegree() < paramInt / 2)
    {
      n = localModulusPoly1.getCoefficient(0);
      if (n == 0)
        throw ChecksumException.getChecksumInstance();
    }
    else
    {
      Object localObject4 = localObject1;
      Object localObject5 = localObject3;
      localObject1 = localObject2;
      localObject3 = localModulusPoly1;
      if (((ModulusPoly)localObject1).isZero())
        throw ChecksumException.getChecksumInstance();
      localObject2 = localObject4;
      ModulusPoly localModulusPoly2 = this.field.getZero();
      int i = ((ModulusPoly)localObject1).getCoefficient(((ModulusPoly)localObject1).getDegree());
      int j = this.field.inverse(i);
      while (true)
      {
        if ((((ModulusPoly)localObject2).getDegree() < ((ModulusPoly)localObject1).getDegree()) || (((ModulusPoly)localObject2).isZero()))
        {
          localModulusPoly1 = localModulusPoly2.multiply((ModulusPoly)localObject3).subtract(localObject5).negative();
          break;
        }
        int k = ((ModulusPoly)localObject2).getDegree() - ((ModulusPoly)localObject1).getDegree();
        int m = this.field.multiply(((ModulusPoly)localObject2).getCoefficient(((ModulusPoly)localObject2).getDegree()), j);
        localModulusPoly2 = localModulusPoly2.add(this.field.buildMonomial(k, m));
        localObject2 = ((ModulusPoly)localObject2).subtract(((ModulusPoly)localObject1).multiplyByMonomial(k, m));
      }
    }
    int i1 = this.field.inverse(n);
    return (ModulusPoly)(ModulusPoly)(ModulusPoly)new ModulusPoly[] { localModulusPoly1.multiply(i1), ((ModulusPoly)localObject2).multiply(i1) };
  }

  public int decode(int[] paramArrayOfInt1, int paramInt, int[] paramArrayOfInt2)
    throws ChecksumException
  {
    ModulusPoly localModulusPoly1 = new ModulusPoly(this.field, paramArrayOfInt1);
    int[] arrayOfInt1 = new int[paramInt];
    int i = 0;
    for (int j = paramInt; ; j--)
    {
      if (j <= 0)
      {
        if (i != 0)
          break;
        return 0;
      }
      int k = localModulusPoly1.evaluateAt(this.field.exp(j));
      arrayOfInt1[(paramInt - j)] = k;
      if (k == 0)
        continue;
      i = 1;
    }
    ModulusPoly localModulusPoly2 = this.field.getOne();
    int i2;
    int[] arrayOfInt2;
    int[] arrayOfInt3;
    if (paramArrayOfInt2 != null)
    {
      int i1 = paramArrayOfInt2.length;
      i2 = 0;
      if (i2 < i1);
    }
    else
    {
      ModulusPoly localModulusPoly3 = new ModulusPoly(this.field, arrayOfInt1);
      ModulusPoly[] arrayOfModulusPoly = runEuclideanAlgorithm(this.field.buildMonomial(paramInt, 1), localModulusPoly3, paramInt);
      ModulusPoly localModulusPoly4 = arrayOfModulusPoly[0];
      ModulusPoly localModulusPoly5 = arrayOfModulusPoly[1];
      arrayOfInt2 = findErrorLocations(localModulusPoly4);
      arrayOfInt3 = findErrorMagnitudes(localModulusPoly5, localModulusPoly4, arrayOfInt2);
    }
    for (int m = 0; ; m++)
    {
      if (m >= arrayOfInt2.length)
      {
        return arrayOfInt2.length;
        int i3 = paramArrayOfInt2[i2];
        int i4 = this.field.exp(-1 + paramArrayOfInt1.length - i3);
        ModulusGF localModulusGF = this.field;
        int[] arrayOfInt4 = new int[2];
        arrayOfInt4[0] = this.field.subtract(0, i4);
        arrayOfInt4[1] = 1;
        ModulusPoly localModulusPoly6 = new ModulusPoly(localModulusGF, arrayOfInt4);
        localModulusPoly2 = localModulusPoly2.multiply(localModulusPoly6);
        i2++;
        break;
      }
      int n = -1 + paramArrayOfInt1.length - this.field.log(arrayOfInt2[m]);
      if (n < 0)
        throw ChecksumException.getChecksumInstance();
      paramArrayOfInt1[n] = this.field.subtract(paramArrayOfInt1[n], arrayOfInt3[m]);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.decoder.ec.ErrorCorrection
 * JD-Core Version:    0.6.0
 */