package com.google.zxing.pdf417.encoder;

import com.google.zxing.WriterException;
import com.google.zxing.common.CharacterSetECI;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.util.Arrays;

final class PDF417HighLevelEncoder
{
  private static final int BYTE_COMPACTION = 1;
  private static final Charset DEFAULT_ENCODING;
  private static final int ECI_CHARSET = 927;
  private static final int ECI_GENERAL_PURPOSE = 926;
  private static final int ECI_USER_DEFINED = 925;
  private static final int LATCH_TO_BYTE = 924;
  private static final int LATCH_TO_BYTE_PADDED = 901;
  private static final int LATCH_TO_NUMERIC = 902;
  private static final int LATCH_TO_TEXT = 900;
  private static final byte[] MIXED;
  private static final int NUMERIC_COMPACTION = 2;
  private static final byte[] PUNCTUATION;
  private static final int SHIFT_TO_BYTE = 913;
  private static final int SUBMODE_ALPHA = 0;
  private static final int SUBMODE_LOWER = 1;
  private static final int SUBMODE_MIXED = 2;
  private static final int SUBMODE_PUNCTUATION = 3;
  private static final int TEXT_COMPACTION;
  private static final byte[] TEXT_MIXED_RAW;
  private static final byte[] TEXT_PUNCTUATION_RAW;

  static
  {
    byte[] arrayOfByte1 = new byte[30];
    arrayOfByte1[0] = 48;
    arrayOfByte1[1] = 49;
    arrayOfByte1[2] = 50;
    arrayOfByte1[3] = 51;
    arrayOfByte1[4] = 52;
    arrayOfByte1[5] = 53;
    arrayOfByte1[6] = 54;
    arrayOfByte1[7] = 55;
    arrayOfByte1[8] = 56;
    arrayOfByte1[9] = 57;
    arrayOfByte1[10] = 38;
    arrayOfByte1[11] = 13;
    arrayOfByte1[12] = 9;
    arrayOfByte1[13] = 44;
    arrayOfByte1[14] = 58;
    arrayOfByte1[15] = 35;
    arrayOfByte1[16] = 45;
    arrayOfByte1[17] = 46;
    arrayOfByte1[18] = 36;
    arrayOfByte1[19] = 47;
    arrayOfByte1[20] = 43;
    arrayOfByte1[21] = 37;
    arrayOfByte1[22] = 42;
    arrayOfByte1[23] = 61;
    arrayOfByte1[24] = 94;
    arrayOfByte1[26] = 32;
    TEXT_MIXED_RAW = arrayOfByte1;
    byte[] arrayOfByte2 = new byte[30];
    arrayOfByte2[0] = 59;
    arrayOfByte2[1] = 60;
    arrayOfByte2[2] = 62;
    arrayOfByte2[3] = 64;
    arrayOfByte2[4] = 91;
    arrayOfByte2[5] = 92;
    arrayOfByte2[6] = 93;
    arrayOfByte2[7] = 95;
    arrayOfByte2[8] = 96;
    arrayOfByte2[9] = 126;
    arrayOfByte2[10] = 33;
    arrayOfByte2[11] = 13;
    arrayOfByte2[12] = 9;
    arrayOfByte2[13] = 44;
    arrayOfByte2[14] = 58;
    arrayOfByte2[15] = 10;
    arrayOfByte2[16] = 45;
    arrayOfByte2[17] = 46;
    arrayOfByte2[18] = 36;
    arrayOfByte2[19] = 47;
    arrayOfByte2[20] = 34;
    arrayOfByte2[21] = 124;
    arrayOfByte2[22] = 42;
    arrayOfByte2[23] = 40;
    arrayOfByte2[24] = 41;
    arrayOfByte2[25] = 63;
    arrayOfByte2[26] = 123;
    arrayOfByte2[27] = 125;
    arrayOfByte2[28] = 39;
    TEXT_PUNCTUATION_RAW = arrayOfByte2;
    MIXED = new byte[''];
    PUNCTUATION = new byte[''];
    DEFAULT_ENCODING = Charset.forName("ISO-8859-1");
    Arrays.fill(MIXED, -1);
    int i = 0;
    if (i >= TEXT_MIXED_RAW.length)
      Arrays.fill(PUNCTUATION, -1);
    for (int k = 0; ; k = (byte)(k + 1))
    {
      if (k >= TEXT_PUNCTUATION_RAW.length)
      {
        return;
        int j = TEXT_MIXED_RAW[i];
        if (j > 0)
          MIXED[j] = i;
        i = (byte)(i + 1);
        break;
      }
      int m = TEXT_PUNCTUATION_RAW[k];
      if (m <= 0)
        continue;
      PUNCTUATION[m] = k;
    }
  }

  private static int determineConsecutiveBinaryCount(CharSequence paramCharSequence, byte[] paramArrayOfByte, int paramInt)
    throws WriterException
  {
    int i = paramCharSequence.length();
    for (int j = paramInt; ; j++)
    {
      if (j >= i)
        return j - paramInt;
      char c1 = paramCharSequence.charAt(j);
      int k = 0;
      while (true)
      {
        if ((k >= 13) || (!isDigit(c1)));
        int m;
        do
        {
          if (k < 13)
            break;
          return j - paramInt;
          k++;
          m = j + k;
        }
        while (m >= i);
        c1 = paramCharSequence.charAt(m);
      }
      char c2 = paramCharSequence.charAt(j);
      if ((paramArrayOfByte[j] != 63) || (c2 == '?'))
        continue;
      throw new WriterException("Non-encodable character detected: " + c2 + " (Unicode: " + c2 + ')');
    }
  }

  private static int determineConsecutiveDigitCount(CharSequence paramCharSequence, int paramInt)
  {
    int i = paramCharSequence.length();
    int j = paramInt;
    int k = 0;
    char c;
    if (j < i)
      c = paramCharSequence.charAt(j);
    while (true)
    {
      if ((!isDigit(c)) || (j >= i))
        return k;
      k++;
      j++;
      if (j >= i)
        continue;
      c = paramCharSequence.charAt(j);
    }
  }

  private static int determineConsecutiveTextCount(CharSequence paramCharSequence, int paramInt)
  {
    int i = paramCharSequence.length();
    int j = paramInt;
    while (true)
    {
      if (j >= i);
      do
      {
        return j - paramInt;
        char c = paramCharSequence.charAt(j);
        int k = 0;
        while (true)
        {
          if ((k >= 13) || (!isDigit(c)) || (j >= i))
          {
            if (k < 13)
              break;
            return j - paramInt - k;
          }
          k++;
          j++;
          if (j >= i)
            continue;
          c = paramCharSequence.charAt(j);
        }
        if (k > 0)
          break;
      }
      while (!isText(paramCharSequence.charAt(j)));
      j++;
    }
  }

  private static void encodeBinary(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, StringBuilder paramStringBuilder)
  {
    int j;
    char[] arrayOfChar;
    if ((paramInt2 == 1) && (paramInt3 == 0))
    {
      paramStringBuilder.append('Α');
      j = paramInt1;
      if (paramInt2 >= 6)
      {
        arrayOfChar = new char[5];
        if (paramInt1 + paramInt2 - j >= 6)
          break label101;
      }
    }
    for (int k = j; ; k++)
    {
      if (k >= paramInt1 + paramInt2)
      {
        return;
        if (paramInt2 % 6 == 0);
        for (int i = 1; ; i = 0)
        {
          if (i == 0)
            break label89;
          paramStringBuilder.append('Μ');
          break;
        }
        label89: paramStringBuilder.append('΅');
        break;
        label101: long l = 0L;
        int m = 0;
        label107: int n;
        if (m >= 6)
        {
          n = 0;
          label117: if (n < 5)
            break label167;
        }
        for (int i1 = -1 + arrayOfChar.length; ; i1--)
        {
          if (i1 < 0)
          {
            j += 6;
            break;
            l = (l << 8) + (0xFF & paramArrayOfByte[(j + m)]);
            m++;
            break label107;
            label167: arrayOfChar[n] = (char)(int)(l % 900L);
            l /= 900L;
            n++;
            break label117;
          }
          paramStringBuilder.append(arrayOfChar[i1]);
        }
      }
      paramStringBuilder.append((char)(0xFF & paramArrayOfByte[k]));
    }
  }

  static String encodeHighLevel(String paramString, Compaction paramCompaction, Charset paramCharset)
    throws WriterException
  {
    StringBuilder localStringBuilder = new StringBuilder(paramString.length());
    int i;
    int j;
    int k;
    byte[] arrayOfByte1;
    if (paramCharset == null)
    {
      paramCharset = DEFAULT_ENCODING;
      i = paramString.length();
      j = 0;
      k = 0;
      arrayOfByte1 = null;
      if (paramCompaction != Compaction.TEXT)
        break label93;
      encodeText(paramString, 0, i, localStringBuilder, 0);
    }
    while (true)
    {
      return localStringBuilder.toString();
      if (DEFAULT_ENCODING.equals(paramCharset))
        break;
      CharacterSetECI localCharacterSetECI = CharacterSetECI.getCharacterSetECIByName(paramCharset.name());
      if (localCharacterSetECI == null)
        break;
      encodingECI(localCharacterSetECI.getValue(), localStringBuilder);
      break;
      label93: if (paramCompaction == Compaction.BYTE)
      {
        byte[] arrayOfByte2 = paramString.getBytes(paramCharset);
        encodeBinary(arrayOfByte2, 0, arrayOfByte2.length, 1, localStringBuilder);
        continue;
      }
      if (paramCompaction != Compaction.NUMERIC)
        break label147;
      localStringBuilder.append('Ά');
      encodeNumeric(paramString, 0, i, localStringBuilder);
    }
    label147: int m = 0;
    label150: int i2;
    while (j < i)
    {
      int n = determineConsecutiveDigitCount(paramString, j);
      if (n >= 13)
      {
        localStringBuilder.append('Ά');
        m = 2;
        encodeNumeric(paramString, j, n, localStringBuilder);
        j += n;
        k = 0;
        continue;
      }
      int i1 = determineConsecutiveTextCount(paramString, j);
      if ((i1 >= 5) || (n == i))
      {
        if (m != 0)
        {
          localStringBuilder.append('΄');
          m = 0;
          k = 0;
        }
        k = encodeText(paramString, j, i1, localStringBuilder, k);
        j += i1;
        continue;
      }
      if (arrayOfByte1 == null)
        arrayOfByte1 = paramString.getBytes(paramCharset);
      i2 = determineConsecutiveBinaryCount(paramString, arrayOfByte1, j);
      if (i2 == 0)
        i2 = 1;
      if ((i2 != 1) || (m != 0))
        break label329;
      encodeBinary(arrayOfByte1, j, 1, 0, localStringBuilder);
    }
    while (true)
    {
      j += i2;
      break label150;
      break;
      label329: encodeBinary(arrayOfByte1, j, i2, m, localStringBuilder);
      m = 1;
      k = 0;
    }
  }

  private static void encodeNumeric(String paramString, int paramInt1, int paramInt2, StringBuilder paramStringBuilder)
  {
    int i = 0;
    StringBuilder localStringBuilder = new StringBuilder(1 + paramInt2 / 3);
    BigInteger localBigInteger1 = BigInteger.valueOf(900L);
    BigInteger localBigInteger2 = BigInteger.valueOf(0L);
    if (i >= paramInt2 - 1)
      return;
    localStringBuilder.setLength(0);
    int j = Math.min(44, paramInt2 - i);
    BigInteger localBigInteger3 = new BigInteger('1' + paramString.substring(paramInt1 + i, j + (paramInt1 + i)));
    do
    {
      localStringBuilder.append((char)localBigInteger3.mod(localBigInteger1).intValue());
      localBigInteger3 = localBigInteger3.divide(localBigInteger1);
    }
    while (!localBigInteger3.equals(localBigInteger2));
    for (int k = -1 + localStringBuilder.length(); ; k--)
    {
      if (k < 0)
      {
        i += j;
        break;
      }
      paramStringBuilder.append(localStringBuilder.charAt(k));
    }
  }

  private static int encodeText(CharSequence paramCharSequence, int paramInt1, int paramInt2, StringBuilder paramStringBuilder, int paramInt3)
  {
    StringBuilder localStringBuilder = new StringBuilder(paramInt2);
    int i = paramInt3;
    int j = 0;
    char c2;
    int m;
    while (true)
    {
      char c1 = paramCharSequence.charAt(paramInt1 + j);
      switch (i)
      {
      default:
        if (!isPunctuation(c1))
          break;
        localStringBuilder.append((char)PUNCTUATION[c1]);
      case 0:
      case 1:
      case 2:
        while (true)
        {
          j++;
          if (j < paramInt2)
            break;
          c2 = '\000';
          int k = localStringBuilder.length();
          m = 0;
          if (m < k)
            break label505;
          if (k % 2 != 0)
            paramStringBuilder.append((char)(29 + c2 * '\036'));
          return i;
          if (isAlphaUpper(c1))
          {
            if (c1 == ' ')
            {
              localStringBuilder.append('\032');
              continue;
            }
            localStringBuilder.append((char)(c1 - 'A'));
            continue;
          }
          if (isAlphaLower(c1))
          {
            i = 1;
            localStringBuilder.append('\033');
            break;
          }
          if (isMixed(c1))
          {
            i = 2;
            localStringBuilder.append('\034');
            break;
          }
          localStringBuilder.append('\035');
          localStringBuilder.append((char)PUNCTUATION[c1]);
          continue;
          if (isAlphaLower(c1))
          {
            if (c1 == ' ')
            {
              localStringBuilder.append('\032');
              continue;
            }
            localStringBuilder.append((char)(c1 - 'a'));
            continue;
          }
          if (isAlphaUpper(c1))
          {
            localStringBuilder.append('\033');
            localStringBuilder.append((char)(c1 - 'A'));
            continue;
          }
          if (isMixed(c1))
          {
            i = 2;
            localStringBuilder.append('\034');
            break;
          }
          localStringBuilder.append('\035');
          localStringBuilder.append((char)PUNCTUATION[c1]);
          continue;
          if (isMixed(c1))
          {
            localStringBuilder.append((char)MIXED[c1]);
            continue;
          }
          if (isAlphaUpper(c1))
          {
            localStringBuilder.append('\034');
            i = 0;
            break;
          }
          if (isAlphaLower(c1))
          {
            i = 1;
            localStringBuilder.append('\033');
            break;
          }
          if ((1 + (paramInt1 + j) < paramInt2) && (isPunctuation(paramCharSequence.charAt(1 + (paramInt1 + j)))))
          {
            i = 3;
            localStringBuilder.append('\031');
            break;
          }
          localStringBuilder.append('\035');
          localStringBuilder.append((char)PUNCTUATION[c1]);
        }
      }
      localStringBuilder.append('\035');
      i = 0;
    }
    label505: int n;
    if (m % 2 != 0)
    {
      n = 1;
      label515: if (n == 0)
        break label555;
      c2 = (char)(c2 * '\036' + localStringBuilder.charAt(m));
      paramStringBuilder.append(c2);
    }
    while (true)
    {
      m++;
      break;
      n = 0;
      break label515;
      label555: c2 = localStringBuilder.charAt(m);
    }
  }

  private static void encodingECI(int paramInt, StringBuilder paramStringBuilder)
    throws WriterException
  {
    if ((paramInt >= 0) && (paramInt < 900))
    {
      paramStringBuilder.append('Ο');
      paramStringBuilder.append((char)paramInt);
      return;
    }
    if (paramInt < 810900)
    {
      paramStringBuilder.append('Ξ');
      paramStringBuilder.append((char)(-1 + paramInt / 900));
      paramStringBuilder.append((char)(paramInt % 900));
      return;
    }
    if (paramInt < 811800)
    {
      paramStringBuilder.append('Ν');
      paramStringBuilder.append((char)(810900 - paramInt));
      return;
    }
    throw new WriterException("ECI number not in valid range from 0..811799, but was " + paramInt);
  }

  private static boolean isAlphaLower(char paramChar)
  {
    return (paramChar == ' ') || ((paramChar >= 'a') && (paramChar <= 'z'));
  }

  private static boolean isAlphaUpper(char paramChar)
  {
    return (paramChar == ' ') || ((paramChar >= 'A') && (paramChar <= 'Z'));
  }

  private static boolean isDigit(char paramChar)
  {
    return (paramChar >= '0') && (paramChar <= '9');
  }

  private static boolean isMixed(char paramChar)
  {
    return MIXED[paramChar] != -1;
  }

  private static boolean isPunctuation(char paramChar)
  {
    return PUNCTUATION[paramChar] != -1;
  }

  private static boolean isText(char paramChar)
  {
    return (paramChar == '\t') || (paramChar == '\n') || (paramChar == '\r') || ((paramChar >= ' ') && (paramChar <= '~'));
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.encoder.PDF417HighLevelEncoder
 * JD-Core Version:    0.6.0
 */