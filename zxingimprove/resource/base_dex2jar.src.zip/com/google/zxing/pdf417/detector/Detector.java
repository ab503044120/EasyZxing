package com.google.zxing.pdf417.detector;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class Detector
{
  private static final int BARCODE_MIN_HEIGHT = 10;
  private static final int[] INDEXES_START_PATTERN;
  private static final int[] INDEXES_STOP_PATTERN;
  private static final float MAX_AVG_VARIANCE = 0.42F;
  private static final float MAX_INDIVIDUAL_VARIANCE = 0.8F;
  private static final int MAX_PATTERN_DRIFT = 5;
  private static final int MAX_PIXEL_DRIFT = 3;
  private static final int ROW_STEP = 5;
  private static final int SKIPPED_ROW_COUNT_MAX = 25;
  private static final int[] START_PATTERN;
  private static final int[] STOP_PATTERN;

  static
  {
    int[] arrayOfInt = new int[4];
    arrayOfInt[1] = 4;
    arrayOfInt[2] = 1;
    arrayOfInt[3] = 5;
    INDEXES_START_PATTERN = arrayOfInt;
    INDEXES_STOP_PATTERN = new int[] { 6, 2, 7, 3 };
    START_PATTERN = new int[] { 8, 1, 1, 1, 1, 1, 1, 3 };
    STOP_PATTERN = new int[] { 7, 1, 1, 3, 1, 1, 1, 2, 1 };
  }

  private static void copyToResult(ResultPoint[] paramArrayOfResultPoint1, ResultPoint[] paramArrayOfResultPoint2, int[] paramArrayOfInt)
  {
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfInt.length)
        return;
      paramArrayOfResultPoint1[paramArrayOfInt[i]] = paramArrayOfResultPoint2[i];
    }
  }

  public static PDF417DetectorResult detect(BinaryBitmap paramBinaryBitmap, Map<DecodeHintType, ?> paramMap, boolean paramBoolean)
    throws NotFoundException
  {
    BitMatrix localBitMatrix = paramBinaryBitmap.getBlackMatrix();
    List localList = detect(paramBoolean, localBitMatrix);
    if (localList.isEmpty())
    {
      localBitMatrix = localBitMatrix.clone();
      localBitMatrix.rotate180();
      localList = detect(paramBoolean, localBitMatrix);
    }
    return new PDF417DetectorResult(localBitMatrix, localList);
  }

  private static List<ResultPoint[]> detect(boolean paramBoolean, BitMatrix paramBitMatrix)
  {
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    int k = 0;
    int m = 0;
    while (true)
    {
      if (i >= paramBitMatrix.getHeight());
      ResultPoint[] arrayOfResultPoint1;
      do
      {
        while (true)
        {
          return localArrayList;
          arrayOfResultPoint1 = findVertices(paramBitMatrix, i, k);
          if ((arrayOfResultPoint1[0] != null) || (arrayOfResultPoint1[3] != null))
            break;
          if (m == 0)
            continue;
          Iterator localIterator = localArrayList.iterator();
          while (true)
          {
            if (!localIterator.hasNext())
            {
              i += 5;
              k = 0;
              m = 0;
              break;
            }
            ResultPoint[] arrayOfResultPoint2 = (ResultPoint[])localIterator.next();
            if (arrayOfResultPoint2[1] != null)
              j = (int)Math.max(i, arrayOfResultPoint2[1].getY());
            if (arrayOfResultPoint2[3] == null)
              continue;
            j = Math.max(j, (int)arrayOfResultPoint2[3].getY());
          }
        }
        m = 1;
        localArrayList.add(arrayOfResultPoint1);
      }
      while (!paramBoolean);
      if (arrayOfResultPoint1[2] != null)
      {
        k = (int)arrayOfResultPoint1[2].getX();
        j = (int)arrayOfResultPoint1[2].getY();
        continue;
      }
      k = (int)arrayOfResultPoint1[4].getX();
      int j = (int)arrayOfResultPoint1[4].getY();
    }
  }

  private static int[] findGuardPattern(BitMatrix paramBitMatrix, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    Arrays.fill(paramArrayOfInt2, 0, paramArrayOfInt2.length, 0);
    int i = paramArrayOfInt1.length;
    boolean bool = paramBoolean;
    int j = paramInt1;
    int k = 0;
    int i1;
    int m;
    int n;
    if ((paramBitMatrix.get(j, paramInt2)) && (j > 0))
    {
      i1 = k + 1;
      if (k < 3);
    }
    else
    {
      m = j;
      n = 0;
    }
    while (true)
    {
      if (m >= paramInt3)
      {
        if ((n != i - 1) || (patternMatchVariance(paramArrayOfInt2, paramArrayOfInt1, 0.8F) >= 0.42F))
          break label265;
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = j;
        arrayOfInt[1] = (m - 1);
        return arrayOfInt;
        j--;
        k = i1;
        break;
      }
      if (!(bool ^ paramBitMatrix.get(m, paramInt2)))
        break label152;
      paramArrayOfInt2[n] = (1 + paramArrayOfInt2[n]);
      m++;
    }
    label152: if (n == i - 1)
    {
      if (patternMatchVariance(paramArrayOfInt2, paramArrayOfInt1, 0.8F) < 0.42F)
        return new int[] { j, m };
      j += paramArrayOfInt2[0] + paramArrayOfInt2[1];
      System.arraycopy(paramArrayOfInt2, 2, paramArrayOfInt2, 0, i - 2);
      paramArrayOfInt2[(i - 2)] = 0;
      paramArrayOfInt2[(i - 1)] = 0;
      n--;
      label236: paramArrayOfInt2[n] = 1;
      if (!bool)
        break label259;
    }
    label259: for (bool = false; ; bool = true)
    {
      break;
      n++;
      break label236;
    }
    label265: return null;
  }

  private static ResultPoint[] findRowsWithPattern(BitMatrix paramBitMatrix, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    ResultPoint[] arrayOfResultPoint = new ResultPoint[4];
    int[] arrayOfInt1 = new int[paramArrayOfInt.length];
    int i = paramInt3;
    int j = 0;
    int k;
    int n;
    Object localObject2;
    if (i >= paramInt1)
    {
      k = paramInt3 + 1;
      if (j != 0)
      {
        n = 0;
        localObject2 = new int[2];
        localObject2[0] = (int)arrayOfResultPoint[0].getX();
        localObject2[1] = (int)arrayOfResultPoint[1].getX();
        if (k < paramInt1)
          break label251;
        label73: k -= n + 1;
        arrayOfResultPoint[2] = new ResultPoint(localObject2[0], k);
        arrayOfResultPoint[3] = new ResultPoint(localObject2[1], k);
      }
      if (k - paramInt3 >= 10);
    }
    for (int m = 0; ; m++)
    {
      if (m >= arrayOfResultPoint.length)
      {
        return arrayOfResultPoint;
        Object localObject1 = findGuardPattern(paramBitMatrix, paramInt4, paramInt3, paramInt2, false, paramArrayOfInt, arrayOfInt1);
        if (localObject1 != null)
        {
          label163: if (paramInt3 <= 0);
          while (true)
          {
            arrayOfResultPoint[0] = new ResultPoint(localObject1[0], paramInt3);
            arrayOfResultPoint[1] = new ResultPoint(localObject1[1], paramInt3);
            j = 1;
            break;
            paramInt3--;
            int[] arrayOfInt2 = findGuardPattern(paramBitMatrix, paramInt4, paramInt3, paramInt2, false, paramArrayOfInt, arrayOfInt1);
            if (arrayOfInt2 != null)
            {
              localObject1 = arrayOfInt2;
              break label163;
            }
            paramInt3++;
          }
        }
        paramInt3 += 5;
        break;
        label251: int[] arrayOfInt3 = findGuardPattern(paramBitMatrix, localObject2[0], k, paramInt2, false, paramArrayOfInt, arrayOfInt1);
        if ((arrayOfInt3 != null) && (Math.abs(localObject2[0] - arrayOfInt3[0]) < 5) && (Math.abs(localObject2[1] - arrayOfInt3[1]) < 5))
          localObject2 = arrayOfInt3;
        for (n = 0; ; n++)
        {
          k++;
          break;
          if (n > 25)
            break label73;
        }
      }
      arrayOfResultPoint[m] = null;
    }
  }

  private static ResultPoint[] findVertices(BitMatrix paramBitMatrix, int paramInt1, int paramInt2)
  {
    int i = paramBitMatrix.getHeight();
    int j = paramBitMatrix.getWidth();
    ResultPoint[] arrayOfResultPoint = new ResultPoint[8];
    int[] arrayOfInt1 = START_PATTERN;
    copyToResult(arrayOfResultPoint, findRowsWithPattern(paramBitMatrix, i, j, paramInt1, paramInt2, arrayOfInt1), INDEXES_START_PATTERN);
    if (arrayOfResultPoint[4] != null)
    {
      paramInt2 = (int)arrayOfResultPoint[4].getX();
      paramInt1 = (int)arrayOfResultPoint[4].getY();
    }
    int[] arrayOfInt2 = STOP_PATTERN;
    copyToResult(arrayOfResultPoint, findRowsWithPattern(paramBitMatrix, i, j, paramInt1, paramInt2, arrayOfInt2), INDEXES_STOP_PATTERN);
    return arrayOfResultPoint;
  }

  private static float patternMatchVariance(int[] paramArrayOfInt1, int[] paramArrayOfInt2, float paramFloat)
  {
    int i = paramArrayOfInt1.length;
    int j = 0;
    int k = 0;
    int m = 0;
    if (m >= i)
      if (j >= k)
        break label52;
    label149: 
    while (true)
    {
      return (1.0F / 1.0F);
      j += paramArrayOfInt1[m];
      k += paramArrayOfInt2[m];
      m++;
      break;
      label52: float f1 = j / k;
      float f2 = paramFloat * f1;
      float f3 = 0.0F;
      int n = 0;
      if (n >= i)
        return f3 / j;
      int i1 = paramArrayOfInt1[n];
      float f4 = f1 * paramArrayOfInt2[n];
      float f5;
      if (i1 > f4)
        f5 = i1 - f4;
      while (true)
      {
        if (f5 > f2)
          break label149;
        f3 += f5;
        n++;
        break;
        f5 = f4 - i1;
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.detector.Detector
 * JD-Core Version:    0.6.0
 */