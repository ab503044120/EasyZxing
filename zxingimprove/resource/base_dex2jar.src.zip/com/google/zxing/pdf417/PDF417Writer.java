package com.google.zxing.pdf417;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.Writer;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.pdf417.encoder.BarcodeMatrix;
import com.google.zxing.pdf417.encoder.Compaction;
import com.google.zxing.pdf417.encoder.Dimensions;
import com.google.zxing.pdf417.encoder.PDF417;
import java.lang.reflect.Array;
import java.nio.charset.Charset;
import java.util.Map;

public final class PDF417Writer
  implements Writer
{
  static final int WHITE_SPACE = 30;

  private static BitMatrix bitMatrixFromEncoder(PDF417 paramPDF417, String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws WriterException
  {
    paramPDF417.generateBarcodeLogic(paramString, 2);
    byte[][] arrayOfByte1 = paramPDF417.getBarcodeMatrix().getScaledMatrix(2, 8);
    int i;
    int j;
    label40: int m;
    int n;
    int i1;
    if (paramInt2 > paramInt1)
    {
      i = 1;
      if (arrayOfByte1[0].length >= arrayOfByte1.length)
        break label143;
      j = 1;
      int k = i ^ j;
      m = 0;
      if (k != 0)
      {
        arrayOfByte1 = rotateArray(arrayOfByte1);
        m = 1;
      }
      n = paramInt1 / arrayOfByte1[0].length;
      i1 = paramInt2 / arrayOfByte1.length;
      if (n >= i1)
        break label149;
    }
    label143: label149: for (int i2 = n; ; i2 = i1)
    {
      if (i2 <= 1)
        break label156;
      byte[][] arrayOfByte2 = paramPDF417.getBarcodeMatrix().getScaledMatrix(i2 * 2, 2 * (i2 * 4));
      if (m != 0)
        arrayOfByte2 = rotateArray(arrayOfByte2);
      return bitMatrixFrombitArray(arrayOfByte2, paramInt3);
      i = 0;
      break;
      j = 0;
      break label40;
    }
    label156: return bitMatrixFrombitArray(arrayOfByte1, paramInt3);
  }

  private static BitMatrix bitMatrixFrombitArray(byte[][] paramArrayOfByte, int paramInt)
  {
    BitMatrix localBitMatrix = new BitMatrix(paramArrayOfByte[0].length + paramInt * 2, paramArrayOfByte.length + paramInt * 2);
    localBitMatrix.clear();
    int i = 0;
    int j = -1 + (localBitMatrix.getHeight() - paramInt);
    if (i >= paramArrayOfByte.length)
      return localBitMatrix;
    for (int k = 0; ; k++)
    {
      if (k >= paramArrayOfByte[0].length)
      {
        i++;
        j--;
        break;
      }
      if (paramArrayOfByte[i][k] != 1)
        continue;
      localBitMatrix.set(k + paramInt, j);
    }
  }

  private static byte[][] rotateArray(byte[][] paramArrayOfByte)
  {
    int[] arrayOfInt = { paramArrayOfByte[0].length, paramArrayOfByte.length };
    byte[][] arrayOfByte = (byte[][])Array.newInstance(Byte.TYPE, arrayOfInt);
    int i = 0;
    if (i >= paramArrayOfByte.length)
      return arrayOfByte;
    int j = -1 + (paramArrayOfByte.length - i);
    for (int k = 0; ; k++)
    {
      if (k >= paramArrayOfByte[0].length)
      {
        i++;
        break;
      }
      arrayOfByte[k][j] = paramArrayOfByte[i][k];
    }
  }

  public BitMatrix encode(String paramString, BarcodeFormat paramBarcodeFormat, int paramInt1, int paramInt2)
    throws WriterException
  {
    return encode(paramString, paramBarcodeFormat, paramInt1, paramInt2, null);
  }

  public BitMatrix encode(String paramString, BarcodeFormat paramBarcodeFormat, int paramInt1, int paramInt2, Map<EncodeHintType, ?> paramMap)
    throws WriterException
  {
    if (paramBarcodeFormat != BarcodeFormat.PDF_417)
      throw new IllegalArgumentException("Can only encode PDF_417, but got " + paramBarcodeFormat);
    PDF417 localPDF417 = new PDF417();
    int i = 30;
    if (paramMap != null)
    {
      if (paramMap.containsKey(EncodeHintType.PDF417_COMPACT))
        localPDF417.setCompact(((Boolean)paramMap.get(EncodeHintType.PDF417_COMPACT)).booleanValue());
      if (paramMap.containsKey(EncodeHintType.PDF417_COMPACTION))
        localPDF417.setCompaction((Compaction)paramMap.get(EncodeHintType.PDF417_COMPACTION));
      if (paramMap.containsKey(EncodeHintType.PDF417_DIMENSIONS))
      {
        Dimensions localDimensions = (Dimensions)paramMap.get(EncodeHintType.PDF417_DIMENSIONS);
        localPDF417.setDimensions(localDimensions.getMaxCols(), localDimensions.getMinCols(), localDimensions.getMaxRows(), localDimensions.getMinRows());
      }
      if (paramMap.containsKey(EncodeHintType.MARGIN))
        i = ((Number)paramMap.get(EncodeHintType.MARGIN)).intValue();
      if (paramMap.containsKey(EncodeHintType.CHARACTER_SET))
        localPDF417.setEncoding(Charset.forName((String)paramMap.get(EncodeHintType.CHARACTER_SET)));
    }
    return bitMatrixFromEncoder(localPDF417, paramString, paramInt1, paramInt2, i);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.pdf417.PDF417Writer
 * JD-Core Version:    0.6.0
 */