package com.google.zxing.aztec.encoder;

import com.google.zxing.common.BitArray;

final class SimpleToken extends Token
{
  private final short bitCount;
  private final short value;

  SimpleToken(Token paramToken, int paramInt1, int paramInt2)
  {
    super(paramToken);
    this.value = (short)paramInt1;
    this.bitCount = (short)paramInt2;
  }

  void appendTo(BitArray paramBitArray, byte[] paramArrayOfByte)
  {
    paramBitArray.appendBits(this.value, this.bitCount);
  }

  public String toString()
  {
    int i = this.value & -1 + (1 << this.bitCount) | 1 << this.bitCount;
    return '<' + Integer.toBinaryString(i | 1 << this.bitCount).substring(1) + '>';
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.aztec.encoder.SimpleToken
 * JD-Core Version:    0.6.0
 */