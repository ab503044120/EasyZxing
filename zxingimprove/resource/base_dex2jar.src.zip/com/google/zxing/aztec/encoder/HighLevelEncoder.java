package com.google.zxing.aztec.encoder;

import com.google.zxing.common.BitArray;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public final class HighLevelEncoder
{
  private static final int[][] CHAR_MAP;
  static final int[][] LATCH_TABLE;
  static final int MODE_DIGIT = 2;
  static final int MODE_LOWER = 1;
  static final int MODE_MIXED = 3;
  static final String[] MODE_NAMES = { "UPPER", "LOWER", "DIGIT", "MIXED", "PUNCT" };
  static final int MODE_PUNCT = 4;
  static final int MODE_UPPER;
  static final int[][] SHIFT_TABLE;
  private final byte[] text;

  static
  {
    int[][] arrayOfInt = new int[5][];
    int[] arrayOfInt1 = new int[5];
    arrayOfInt1[1] = 327708;
    arrayOfInt1[2] = 327710;
    arrayOfInt1[3] = 327709;
    arrayOfInt1[4] = 656318;
    arrayOfInt[0] = arrayOfInt1;
    int[] arrayOfInt2 = new int[5];
    arrayOfInt2[0] = 590318;
    arrayOfInt2[2] = 327710;
    arrayOfInt2[3] = 327709;
    arrayOfInt2[4] = 656318;
    arrayOfInt[1] = arrayOfInt2;
    int[] arrayOfInt3 = new int[5];
    arrayOfInt3[0] = 262158;
    arrayOfInt3[1] = 590300;
    arrayOfInt3[3] = 590301;
    arrayOfInt3[4] = 932798;
    arrayOfInt[2] = arrayOfInt3;
    int[] arrayOfInt4 = new int[5];
    arrayOfInt4[0] = 327709;
    arrayOfInt4[1] = 327708;
    arrayOfInt4[2] = 656318;
    arrayOfInt4[4] = 327710;
    arrayOfInt[3] = arrayOfInt4;
    int[] arrayOfInt5 = new int[5];
    arrayOfInt5[0] = 327711;
    arrayOfInt5[1] = 656380;
    arrayOfInt5[2] = 656382;
    arrayOfInt5[3] = 656381;
    arrayOfInt[4] = arrayOfInt5;
    LATCH_TABLE = arrayOfInt;
    int[] arrayOfInt6 = { 5, 256 };
    CHAR_MAP = (int[][])Array.newInstance(Integer.TYPE, arrayOfInt6);
    CHAR_MAP[0][32] = 1;
    int i = 65;
    int j;
    label255: int k;
    label275: int[] arrayOfInt7;
    int m;
    label490: int[] arrayOfInt8;
    int n;
    label688: int[][] arrayOfInt10;
    int i1;
    if (i > 90)
    {
      CHAR_MAP[1][32] = 1;
      j = 97;
      if (j <= 122)
        break label817;
      CHAR_MAP[2][32] = 1;
      k = 48;
      if (k <= 57)
        break label838;
      CHAR_MAP[2][44] = 12;
      CHAR_MAP[2][46] = 13;
      arrayOfInt7 = new int[28];
      arrayOfInt7[1] = 32;
      arrayOfInt7[2] = 1;
      arrayOfInt7[3] = 2;
      arrayOfInt7[4] = 3;
      arrayOfInt7[5] = 4;
      arrayOfInt7[6] = 5;
      arrayOfInt7[7] = 6;
      arrayOfInt7[8] = 7;
      arrayOfInt7[9] = 8;
      arrayOfInt7[10] = 9;
      arrayOfInt7[11] = 10;
      arrayOfInt7[12] = 11;
      arrayOfInt7[13] = 12;
      arrayOfInt7[14] = 13;
      arrayOfInt7[15] = 27;
      arrayOfInt7[16] = 28;
      arrayOfInt7[17] = 29;
      arrayOfInt7[18] = 30;
      arrayOfInt7[19] = 31;
      arrayOfInt7[20] = 64;
      arrayOfInt7[21] = 92;
      arrayOfInt7[22] = 94;
      arrayOfInt7[23] = 95;
      arrayOfInt7[24] = 96;
      arrayOfInt7[25] = 124;
      arrayOfInt7[26] = 126;
      arrayOfInt7[27] = 127;
      m = 0;
      if (m < arrayOfInt7.length)
        break label859;
      arrayOfInt8 = new int[31];
      arrayOfInt8[1] = 13;
      arrayOfInt8[6] = 33;
      arrayOfInt8[7] = 39;
      arrayOfInt8[8] = 35;
      arrayOfInt8[9] = 36;
      arrayOfInt8[10] = 37;
      arrayOfInt8[11] = 38;
      arrayOfInt8[12] = 39;
      arrayOfInt8[13] = 40;
      arrayOfInt8[14] = 41;
      arrayOfInt8[15] = 42;
      arrayOfInt8[16] = 43;
      arrayOfInt8[17] = 44;
      arrayOfInt8[18] = 45;
      arrayOfInt8[19] = 46;
      arrayOfInt8[20] = 47;
      arrayOfInt8[21] = 58;
      arrayOfInt8[22] = 59;
      arrayOfInt8[23] = 60;
      arrayOfInt8[24] = 61;
      arrayOfInt8[25] = 62;
      arrayOfInt8[26] = 63;
      arrayOfInt8[27] = 91;
      arrayOfInt8[28] = 93;
      arrayOfInt8[29] = 123;
      arrayOfInt8[30] = 125;
      n = 0;
      if (n < arrayOfInt8.length)
        break label878;
      int[] arrayOfInt9 = { 6, 6 };
      SHIFT_TABLE = (int[][])Array.newInstance(Integer.TYPE, arrayOfInt9);
      arrayOfInt10 = SHIFT_TABLE;
      i1 = arrayOfInt10.length;
    }
    for (int i2 = 0; ; i2++)
    {
      if (i2 >= i1)
      {
        SHIFT_TABLE[0][4] = 0;
        SHIFT_TABLE[1][4] = 0;
        SHIFT_TABLE[1][0] = 28;
        SHIFT_TABLE[3][4] = 0;
        SHIFT_TABLE[2][4] = 0;
        SHIFT_TABLE[2][0] = 15;
        return;
        CHAR_MAP[0][i] = (2 + (i - 65));
        i++;
        break;
        label817: CHAR_MAP[1][j] = (2 + (j - 97));
        j++;
        break label255;
        label838: CHAR_MAP[2][k] = (2 + (k - 48));
        k++;
        break label275;
        label859: CHAR_MAP[3][arrayOfInt7[m]] = m;
        m++;
        break label490;
        label878: if (arrayOfInt8[n] > 0)
          CHAR_MAP[4][arrayOfInt8[n]] = n;
        n++;
        break label688;
      }
      Arrays.fill(arrayOfInt10[i2], -1);
    }
  }

  public HighLevelEncoder(byte[] paramArrayOfByte)
  {
    this.text = paramArrayOfByte;
  }

  private static Collection<State> simplifyStates(Iterable<State> paramIterable)
  {
    LinkedList localLinkedList = new LinkedList();
    Iterator localIterator1 = paramIterable.iterator();
    if (!localIterator1.hasNext())
      return localLinkedList;
    State localState1 = (State)localIterator1.next();
    int i = 1;
    Iterator localIterator2 = localLinkedList.iterator();
    while (true)
    {
      if (!localIterator2.hasNext());
      State localState2;
      while (true)
      {
        if (i == 0)
          break label98;
        localLinkedList.add(localState1);
        break;
        localState2 = (State)localIterator2.next();
        if (!localState2.isBetterThanOrEqualTo(localState1))
          break label100;
        i = 0;
      }
      label98: break;
      label100: if (!localState1.isBetterThanOrEqualTo(localState2))
        continue;
      localIterator2.remove();
    }
  }

  private void updateStateForChar(State paramState, int paramInt, Collection<State> paramCollection)
  {
    int i = (char)(0xFF & this.text[paramInt]);
    int j;
    State localState;
    if (CHAR_MAP[paramState.getMode()][i] > 0)
    {
      j = 1;
      localState = null;
    }
    for (int k = 0; ; k++)
    {
      if (k > 4)
      {
        if ((paramState.getBinaryShiftByteCount() > 0) || (CHAR_MAP[paramState.getMode()][i] == 0))
          paramCollection.add(paramState.addBinaryShiftChar(paramInt));
        return;
        j = 0;
        break;
      }
      int m = CHAR_MAP[k][i];
      if (m <= 0)
        continue;
      if (localState == null)
        localState = paramState.endBinaryShift(paramInt);
      if ((j == 0) || (k == paramState.getMode()) || (k == 2))
        paramCollection.add(localState.latchAndAppend(k, m));
      if ((j != 0) || (SHIFT_TABLE[paramState.getMode()][k] < 0))
        continue;
      paramCollection.add(localState.shiftAndAppend(k, m));
    }
  }

  private static void updateStateForPair(State paramState, int paramInt1, int paramInt2, Collection<State> paramCollection)
  {
    State localState = paramState.endBinaryShift(paramInt1);
    paramCollection.add(localState.latchAndAppend(4, paramInt2));
    if (paramState.getMode() != 4)
      paramCollection.add(localState.shiftAndAppend(4, paramInt2));
    if ((paramInt2 == 3) || (paramInt2 == 4))
      paramCollection.add(localState.latchAndAppend(2, 16 - paramInt2).latchAndAppend(2, 1));
    if (paramState.getBinaryShiftByteCount() > 0)
      paramCollection.add(paramState.addBinaryShiftChar(paramInt1).addBinaryShiftChar(paramInt1 + 1));
  }

  private Collection<State> updateStateListForChar(Iterable<State> paramIterable, int paramInt)
  {
    LinkedList localLinkedList = new LinkedList();
    Iterator localIterator = paramIterable.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return simplifyStates(localLinkedList);
      updateStateForChar((State)localIterator.next(), paramInt, localLinkedList);
    }
  }

  private static Collection<State> updateStateListForPair(Iterable<State> paramIterable, int paramInt1, int paramInt2)
  {
    LinkedList localLinkedList = new LinkedList();
    Iterator localIterator = paramIterable.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return simplifyStates(localLinkedList);
      updateStateForPair((State)localIterator.next(), paramInt1, paramInt2, localLinkedList);
    }
  }

  public BitArray encode()
  {
    Object localObject = Collections.singletonList(State.INITIAL_STATE);
    int i = 0;
    if (i >= this.text.length)
      return ((State)Collections.min((Collection)localObject, new Comparator()
      {
        public int compare(State paramState1, State paramState2)
        {
          return paramState1.getBitCount() - paramState2.getBitCount();
        }
      })).toBitArray(this.text);
    int j;
    label61: int k;
    if (i + 1 < this.text.length)
    {
      j = this.text[(i + 1)];
      switch (this.text[i])
      {
      default:
        k = 0;
        if (k <= 0)
          break;
        localObject = updateStateListForPair((Iterable)localObject, i, k);
        i++;
      case 13:
      case 46:
      case 44:
      case 58:
      }
    }
    while (true)
    {
      i++;
      break;
      j = 0;
      break label61;
      if (j == 10);
      for (k = 2; ; k = 0)
        break;
      if (j == 32);
      for (k = 3; ; k = 0)
        break;
      if (j == 32);
      for (k = 4; ; k = 0)
        break;
      if (j == 32);
      for (k = 5; ; k = 0)
        break;
      localObject = updateStateListForChar((Iterable)localObject, i);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.aztec.encoder.HighLevelEncoder
 * JD-Core Version:    0.6.0
 */