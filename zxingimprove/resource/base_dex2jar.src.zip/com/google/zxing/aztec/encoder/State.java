package com.google.zxing.aztec.encoder;

import com.google.zxing.common.BitArray;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;

final class State
{
  static final State INITIAL_STATE = new State(Token.EMPTY, 0, 0, 0);
  private final int binaryShiftByteCount;
  private final int bitCount;
  private final int mode;
  private final Token token;

  private State(Token paramToken, int paramInt1, int paramInt2, int paramInt3)
  {
    this.token = paramToken;
    this.mode = paramInt1;
    this.binaryShiftByteCount = paramInt2;
    this.bitCount = paramInt3;
  }

  State addBinaryShiftChar(int paramInt)
  {
    Token localToken = this.token;
    int i = this.mode;
    int j = this.bitCount;
    if ((this.mode == 4) || (this.mode == 2))
    {
      int k = HighLevelEncoder.LATCH_TABLE[i][0];
      localToken = localToken.add(0xFFFF & k, k >> 16);
      j += (k >> 16);
      i = 0;
    }
    int m;
    if ((this.binaryShiftByteCount == 0) || (this.binaryShiftByteCount == 31))
      m = 18;
    while (true)
    {
      State localState = new State(localToken, i, 1 + this.binaryShiftByteCount, j + m);
      if (localState.binaryShiftByteCount == 2078)
        localState = localState.endBinaryShift(paramInt + 1);
      return localState;
      if (this.binaryShiftByteCount == 62)
      {
        m = 9;
        continue;
      }
      m = 8;
    }
  }

  State endBinaryShift(int paramInt)
  {
    if (this.binaryShiftByteCount == 0)
      return this;
    return new State(this.token.addBinaryShift(paramInt - this.binaryShiftByteCount, this.binaryShiftByteCount), this.mode, 0, this.bitCount);
  }

  int getBinaryShiftByteCount()
  {
    return this.binaryShiftByteCount;
  }

  int getBitCount()
  {
    return this.bitCount;
  }

  int getMode()
  {
    return this.mode;
  }

  Token getToken()
  {
    return this.token;
  }

  boolean isBetterThanOrEqualTo(State paramState)
  {
    int i = this.bitCount + (HighLevelEncoder.LATCH_TABLE[this.mode][paramState.mode] >> 16);
    if ((paramState.binaryShiftByteCount > 0) && ((this.binaryShiftByteCount == 0) || (this.binaryShiftByteCount > paramState.binaryShiftByteCount)))
      i += 10;
    return i <= paramState.bitCount;
  }

  State latchAndAppend(int paramInt1, int paramInt2)
  {
    int i = this.bitCount;
    Token localToken = this.token;
    if (paramInt1 != this.mode)
    {
      int k = HighLevelEncoder.LATCH_TABLE[this.mode][paramInt1];
      localToken = localToken.add(0xFFFF & k, k >> 16);
      i += (k >> 16);
    }
    if (paramInt1 == 2);
    for (int j = 4; ; j = 5)
      return new State(localToken.add(paramInt2, j), paramInt1, 0, i + j);
  }

  State shiftAndAppend(int paramInt1, int paramInt2)
  {
    Token localToken = this.token;
    if (this.mode == 2);
    for (int i = 4; ; i = 5)
      return new State(localToken.add(HighLevelEncoder.SHIFT_TABLE[this.mode][paramInt1], i).add(paramInt2, 5), this.mode, 0, 5 + (i + this.bitCount));
  }

  BitArray toBitArray(byte[] paramArrayOfByte)
  {
    LinkedList localLinkedList = new LinkedList();
    Token localToken = endBinaryShift(paramArrayOfByte.length).token;
    BitArray localBitArray;
    Iterator localIterator;
    if (localToken == null)
    {
      localBitArray = new BitArray();
      localIterator = localLinkedList.iterator();
    }
    while (true)
    {
      if (!localIterator.hasNext())
      {
        return localBitArray;
        localLinkedList.addFirst(localToken);
        localToken = localToken.getPrevious();
        break;
      }
      ((Token)localIterator.next()).appendTo(localBitArray, paramArrayOfByte);
    }
  }

  public String toString()
  {
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = HighLevelEncoder.MODE_NAMES[this.mode];
    arrayOfObject[1] = Integer.valueOf(this.bitCount);
    arrayOfObject[2] = Integer.valueOf(this.binaryShiftByteCount);
    return String.format("%s bits=%d bytes=%d", arrayOfObject);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.aztec.encoder.State
 * JD-Core Version:    0.6.0
 */