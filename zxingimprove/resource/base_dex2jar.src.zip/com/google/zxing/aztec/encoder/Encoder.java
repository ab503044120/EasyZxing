package com.google.zxing.aztec.encoder;

import com.google.zxing.common.BitArray;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonEncoder;

public final class Encoder
{
  public static final int DEFAULT_AZTEC_LAYERS = 0;
  public static final int DEFAULT_EC_PERCENT = 33;
  private static final int MAX_NB_BITS = 32;
  private static final int MAX_NB_BITS_COMPACT = 4;
  private static final int[] WORD_SIZE = { 4, 6, 6, 8, 8, 8, 8, 8, 8, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12 };

  private static int[] bitsToWords(BitArray paramBitArray, int paramInt1, int paramInt2)
  {
    int[] arrayOfInt = new int[paramInt2];
    int i = 0;
    int j = paramBitArray.getSize() / paramInt1;
    int k;
    int m;
    while (true)
    {
      if (i >= j)
        return arrayOfInt;
      k = 0;
      m = 0;
      if (m < paramInt1)
        break;
      arrayOfInt[i] = k;
      i++;
    }
    if (paramBitArray.get(m + i * paramInt1));
    for (int n = 1 << -1 + (paramInt1 - m); ; n = 0)
    {
      k |= n;
      m++;
      break;
    }
  }

  private static void drawBullsEye(BitMatrix paramBitMatrix, int paramInt1, int paramInt2)
  {
    int i = 0;
    if (i >= paramInt2)
    {
      paramBitMatrix.set(paramInt1 - paramInt2, paramInt1 - paramInt2);
      paramBitMatrix.set(1 + (paramInt1 - paramInt2), paramInt1 - paramInt2);
      paramBitMatrix.set(paramInt1 - paramInt2, 1 + (paramInt1 - paramInt2));
      paramBitMatrix.set(paramInt1 + paramInt2, paramInt1 - paramInt2);
      paramBitMatrix.set(paramInt1 + paramInt2, 1 + (paramInt1 - paramInt2));
      paramBitMatrix.set(paramInt1 + paramInt2, -1 + (paramInt1 + paramInt2));
      return;
    }
    for (int j = paramInt1 - i; ; j++)
    {
      if (j > paramInt1 + i)
      {
        i += 2;
        break;
      }
      paramBitMatrix.set(j, paramInt1 - i);
      paramBitMatrix.set(j, paramInt1 + i);
      paramBitMatrix.set(paramInt1 - i, j);
      paramBitMatrix.set(paramInt1 + i, j);
    }
  }

  private static void drawModeMessage(BitMatrix paramBitMatrix, boolean paramBoolean, int paramInt, BitArray paramBitArray)
  {
    int i = paramInt / 2;
    int m;
    if (paramBoolean)
    {
      m = 0;
      if (m < 7);
    }
    while (true)
    {
      return;
      int n = m + (i - 3);
      if (paramBitArray.get(m))
        paramBitMatrix.set(n, i - 5);
      if (paramBitArray.get(m + 7))
        paramBitMatrix.set(i + 5, n);
      if (paramBitArray.get(20 - m))
        paramBitMatrix.set(n, i + 5);
      if (paramBitArray.get(27 - m))
        paramBitMatrix.set(i - 5, n);
      m++;
      break;
      for (int j = 0; j < 10; j++)
      {
        int k = j + (i - 5) + j / 5;
        if (paramBitArray.get(j))
          paramBitMatrix.set(k, i - 7);
        if (paramBitArray.get(j + 10))
          paramBitMatrix.set(i + 7, k);
        if (paramBitArray.get(29 - j))
          paramBitMatrix.set(k, i + 7);
        if (!paramBitArray.get(39 - j))
          continue;
        paramBitMatrix.set(i - 7, k);
      }
    }
  }

  public static AztecCode encode(byte[] paramArrayOfByte)
  {
    return encode(paramArrayOfByte, 33, 0);
  }

  public static AztecCode encode(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    HighLevelEncoder localHighLevelEncoder = new HighLevelEncoder(paramArrayOfByte);
    BitArray localBitArray1 = localHighLevelEncoder.encode();
    int i = 11 + paramInt1 * localBitArray1.getSize() / 100;
    int j = i + localBitArray1.getSize();
    boolean bool;
    int n;
    label107: label114: int i1;
    int k;
    BitArray localBitArray2;
    if (paramInt2 != 0)
    {
      if (paramInt2 < 0)
      {
        bool = true;
        n = Math.abs(paramInt2);
        if (!bool)
          break label107;
      }
      for (int i21 = 4; ; i21 = 32)
      {
        if (n <= i21)
          break label114;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(paramInt2);
        throw new IllegalArgumentException(String.format("Illegal value %s for layers", arrayOfObject));
        bool = false;
        break;
      }
      i1 = totalBitsInLayer(n, bool);
      k = WORD_SIZE[n];
      int i22 = i1 - i1 % k;
      localBitArray2 = stuffBits(localBitArray1, k);
      if (i + localBitArray2.getSize() > i22)
        throw new IllegalArgumentException("Data to large for user specified layer");
      if ((bool) && (localBitArray2.getSize() > k * 64))
        throw new IllegalArgumentException("Data to large for user specified layer");
    }
    else
    {
      k = 0;
      localBitArray2 = null;
      int m = 0;
      if (m > 32)
        throw new IllegalArgumentException("Data too large for an Aztec code");
      if (m <= 3)
      {
        bool = true;
        label236: if (!bool)
          break label275;
        n = m + 1;
        label247: i1 = totalBitsInLayer(n, bool);
        if (j <= i1)
          break label282;
      }
      label275: label282: int i3;
      do
      {
        m++;
        break;
        bool = false;
        break label236;
        n = m;
        break label247;
        int i2 = WORD_SIZE[n];
        if (k != i2)
        {
          k = WORD_SIZE[n];
          localBitArray2 = stuffBits(localBitArray1, k);
        }
        i3 = i1 - i1 % k;
      }
      while (((bool) && (localBitArray2.getSize() > k * 64)) || (i + localBitArray2.getSize() > i3));
    }
    BitArray localBitArray3 = generateCheckWords(localBitArray2, i1, k);
    int i4 = localBitArray2.getSize() / k;
    BitArray localBitArray4 = generateModeMessage(bool, n, i4);
    int i5;
    int[] arrayOfInt;
    int i6;
    int i20;
    if (bool)
    {
      i5 = 11 + n * 4;
      arrayOfInt = new int[i5];
      if (!bool)
        break label549;
      i6 = i5;
      i20 = 0;
      label419: if (i20 < arrayOfInt.length)
        break label536;
    }
    BitMatrix localBitMatrix;
    int i11;
    int i12;
    while (true)
    {
      localBitMatrix = new BitMatrix(i6);
      i11 = 0;
      i12 = 0;
      if (i11 < n)
        break label637;
      drawModeMessage(localBitMatrix, bool, i6, localBitArray4);
      if (!bool)
        break label922;
      drawBullsEye(localBitMatrix, i6 / 2, 5);
      AztecCode localAztecCode = new AztecCode();
      localAztecCode.setCompact(bool);
      localAztecCode.setSize(i6);
      localAztecCode.setLayers(n);
      localAztecCode.setCodeWords(i4);
      localAztecCode.setMatrix(localBitMatrix);
      return localAztecCode;
      i5 = 14 + n * 4;
      break;
      label536: arrayOfInt[i20] = i20;
      i20++;
      break label419;
      label549: i6 = i5 + 1 + 2 * ((-1 + i5 / 2) / 15);
      int i7 = i5 / 2;
      int i8 = i6 / 2;
      for (int i9 = 0; i9 < i7; i9++)
      {
        int i10 = i9 + i9 / 15;
        arrayOfInt[(-1 + (i7 - i9))] = (-1 + (i8 - i10));
        arrayOfInt[(i7 + i9)] = (1 + (i8 + i10));
      }
    }
    label637: if (bool);
    int i14;
    for (int i13 = 9 + 4 * (n - i11); ; i13 = 12 + 4 * (n - i11))
    {
      i14 = 0;
      if (i14 < i13)
        break label695;
      i12 += i13 * 8;
      i11++;
      break;
    }
    label695: int i15 = i14 * 2;
    for (int i16 = 0; ; i16++)
    {
      if (i16 >= 2)
      {
        i14++;
        break;
      }
      if (localBitArray3.get(i16 + (i12 + i15)))
        localBitMatrix.set(arrayOfInt[(i16 + i11 * 2)], arrayOfInt[(i14 + i11 * 2)]);
      if (localBitArray3.get(i16 + (i15 + (i12 + i13 * 2))))
        localBitMatrix.set(arrayOfInt[(i14 + i11 * 2)], arrayOfInt[(i5 - 1 - i11 * 2 - i16)]);
      if (localBitArray3.get(i16 + (i15 + (i12 + i13 * 4))))
        localBitMatrix.set(arrayOfInt[(i5 - 1 - i11 * 2 - i16)], arrayOfInt[(i5 - 1 - i11 * 2 - i14)]);
      if (!localBitArray3.get(i16 + (i15 + (i12 + i13 * 6))))
        continue;
      localBitMatrix.set(arrayOfInt[(i5 - 1 - i11 * 2 - i14)], arrayOfInt[(i16 + i11 * 2)]);
    }
    label922: drawBullsEye(localBitMatrix, i6 / 2, 7);
    int i17 = 0;
    int i18 = 0;
    label939: if (i17 < -1 + i5 / 2);
    for (int i19 = 0x1 & i6 / 2; ; i19 += 2)
    {
      if (i19 >= i6)
      {
        i17 += 15;
        i18 += 16;
        break label939;
        break;
      }
      localBitMatrix.set(i6 / 2 - i18, i19);
      localBitMatrix.set(i18 + i6 / 2, i19);
      localBitMatrix.set(i19, i6 / 2 - i18);
      localBitMatrix.set(i19, i18 + i6 / 2);
    }
  }

  private static BitArray generateCheckWords(BitArray paramBitArray, int paramInt1, int paramInt2)
  {
    int i = 0;
    int j = paramBitArray.getSize() / paramInt2;
    ReedSolomonEncoder localReedSolomonEncoder = new ReedSolomonEncoder(getGF(paramInt2));
    int k = paramInt1 / paramInt2;
    int[] arrayOfInt = bitsToWords(paramBitArray, paramInt2, k);
    localReedSolomonEncoder.encode(arrayOfInt, k - j);
    int m = paramInt1 % paramInt2;
    BitArray localBitArray = new BitArray();
    localBitArray.appendBits(0, m);
    int n = arrayOfInt.length;
    while (true)
    {
      if (i >= n)
        return localBitArray;
      localBitArray.appendBits(arrayOfInt[i], paramInt2);
      i++;
    }
  }

  static BitArray generateModeMessage(boolean paramBoolean, int paramInt1, int paramInt2)
  {
    BitArray localBitArray = new BitArray();
    if (paramBoolean)
    {
      localBitArray.appendBits(paramInt1 - 1, 2);
      localBitArray.appendBits(paramInt2 - 1, 6);
      return generateCheckWords(localBitArray, 28, 4);
    }
    localBitArray.appendBits(paramInt1 - 1, 5);
    localBitArray.appendBits(paramInt2 - 1, 11);
    return generateCheckWords(localBitArray, 40, 4);
  }

  private static GenericGF getGF(int paramInt)
  {
    switch (paramInt)
    {
    case 5:
    case 7:
    case 9:
    case 11:
    default:
      return null;
    case 4:
      return GenericGF.AZTEC_PARAM;
    case 6:
      return GenericGF.AZTEC_DATA_6;
    case 8:
      return GenericGF.AZTEC_DATA_8;
    case 10:
      return GenericGF.AZTEC_DATA_10;
    case 12:
    }
    return GenericGF.AZTEC_DATA_12;
  }

  static BitArray stuffBits(BitArray paramBitArray, int paramInt)
  {
    BitArray localBitArray = new BitArray();
    int i = paramBitArray.getSize();
    int j = -2 + (1 << paramInt);
    int k = 0;
    if (k >= i)
      return localBitArray;
    int m = 0;
    int n = 0;
    label38: if (n >= paramInt)
    {
      if ((m & j) != j)
        break label116;
      localBitArray.appendBits(m & j, paramInt);
      k--;
    }
    while (true)
    {
      k += paramInt;
      break;
      if ((k + n >= i) || (paramBitArray.get(k + n)))
        m |= 1 << paramInt - 1 - n;
      n++;
      break label38;
      label116: if ((m & j) == 0)
      {
        localBitArray.appendBits(m | 0x1, paramInt);
        k--;
        continue;
      }
      localBitArray.appendBits(m, paramInt);
    }
  }

  private static int totalBitsInLayer(int paramInt, boolean paramBoolean)
  {
    if (paramBoolean);
    for (int i = 88; ; i = 112)
      return paramInt * (i + paramInt * 16);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.aztec.encoder.Encoder
 * JD-Core Version:    0.6.0
 */