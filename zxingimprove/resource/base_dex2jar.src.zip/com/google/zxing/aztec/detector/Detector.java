package com.google.zxing.aztec.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.aztec.AztecDetectorResult;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.GridSampler;
import com.google.zxing.common.detector.MathUtils;
import com.google.zxing.common.detector.WhiteRectangleDetector;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonDecoder;
import com.google.zxing.common.reedsolomon.ReedSolomonException;

public final class Detector
{
  private static final int[] EXPECTED_CORNER_BITS = { 3808, 476, 2107, 1799 };
  private boolean compact;
  private final BitMatrix image;
  private int nbCenterLayers;
  private int nbDataBlocks;
  private int nbLayers;
  private int shift;

  public Detector(BitMatrix paramBitMatrix)
  {
    this.image = paramBitMatrix;
  }

  private static float distance(ResultPoint paramResultPoint1, ResultPoint paramResultPoint2)
  {
    return MathUtils.distance(paramResultPoint1.getX(), paramResultPoint1.getY(), paramResultPoint2.getX(), paramResultPoint2.getY());
  }

  private static float distance(Point paramPoint1, Point paramPoint2)
  {
    return MathUtils.distance(paramPoint1.getX(), paramPoint1.getY(), paramPoint2.getX(), paramPoint2.getY());
  }

  private static ResultPoint[] expandSquare(ResultPoint[] paramArrayOfResultPoint, float paramFloat1, float paramFloat2)
  {
    float f1 = paramFloat2 / (2.0F * paramFloat1);
    float f2 = paramArrayOfResultPoint[0].getX() - paramArrayOfResultPoint[2].getX();
    float f3 = paramArrayOfResultPoint[0].getY() - paramArrayOfResultPoint[2].getY();
    float f4 = (paramArrayOfResultPoint[0].getX() + paramArrayOfResultPoint[2].getX()) / 2.0F;
    float f5 = (paramArrayOfResultPoint[0].getY() + paramArrayOfResultPoint[2].getY()) / 2.0F;
    ResultPoint localResultPoint1 = new ResultPoint(f4 + f1 * f2, f5 + f1 * f3);
    ResultPoint localResultPoint2 = new ResultPoint(f4 - f1 * f2, f5 - f1 * f3);
    float f6 = paramArrayOfResultPoint[1].getX() - paramArrayOfResultPoint[3].getX();
    float f7 = paramArrayOfResultPoint[1].getY() - paramArrayOfResultPoint[3].getY();
    float f8 = (paramArrayOfResultPoint[1].getX() + paramArrayOfResultPoint[3].getX()) / 2.0F;
    float f9 = (paramArrayOfResultPoint[1].getY() + paramArrayOfResultPoint[3].getY()) / 2.0F;
    return new ResultPoint[] { localResultPoint1, new ResultPoint(f8 + f1 * f6, f9 + f1 * f7), localResultPoint2, new ResultPoint(f8 - f1 * f6, f9 - f1 * f7) };
  }

  private void extractParameters(ResultPoint[] paramArrayOfResultPoint)
    throws NotFoundException
  {
    if ((!isValid(paramArrayOfResultPoint[0])) || (!isValid(paramArrayOfResultPoint[1])) || (!isValid(paramArrayOfResultPoint[2])) || (!isValid(paramArrayOfResultPoint[3])))
      throw NotFoundException.getNotFoundInstance();
    int i = 2 * this.nbCenterLayers;
    int[] arrayOfInt = new int[4];
    arrayOfInt[0] = sampleLine(paramArrayOfResultPoint[0], paramArrayOfResultPoint[1], i);
    arrayOfInt[1] = sampleLine(paramArrayOfResultPoint[1], paramArrayOfResultPoint[2], i);
    arrayOfInt[2] = sampleLine(paramArrayOfResultPoint[2], paramArrayOfResultPoint[3], i);
    arrayOfInt[3] = sampleLine(paramArrayOfResultPoint[3], paramArrayOfResultPoint[0], i);
    this.shift = getRotation(arrayOfInt, i);
    long l = 0L;
    int j = 0;
    int m;
    if (j >= 4)
    {
      m = getCorrectedParameterData(l, this.compact);
      if (this.compact)
      {
        this.nbLayers = (1 + (m >> 6));
        this.nbDataBlocks = (1 + (m & 0x3F));
        return;
      }
    }
    else
    {
      int k = arrayOfInt[((j + this.shift) % 4)];
      if (this.compact)
        l = (l << 7) + (0x7F & k >> 1);
      while (true)
      {
        j++;
        break;
        l = (l << 10) + ((0x3E0 & k >> 2) + (0x1F & k >> 1));
      }
    }
    this.nbLayers = (1 + (m >> 11));
    this.nbDataBlocks = (1 + (m & 0x7FF));
  }

  private ResultPoint[] getBullsEyeCorners(Point paramPoint)
    throws NotFoundException
  {
    Object localObject1 = paramPoint;
    Object localObject2 = paramPoint;
    Object localObject3 = paramPoint;
    Object localObject4 = paramPoint;
    boolean bool1 = true;
    this.nbCenterLayers = 1;
    if (this.nbCenterLayers >= 9);
    while ((this.nbCenterLayers != 5) && (this.nbCenterLayers != 7))
    {
      throw NotFoundException.getNotFoundInstance();
      Point localPoint1 = getFirstDifferent((Point)localObject1, bool1, 1, -1);
      Point localPoint2 = getFirstDifferent((Point)localObject2, bool1, 1, 1);
      Point localPoint3 = getFirstDifferent((Point)localObject3, bool1, -1, 1);
      Point localPoint4 = getFirstDifferent((Point)localObject4, bool1, -1, -1);
      if (this.nbCenterLayers > 2)
      {
        float f = distance(localPoint4, localPoint1) * this.nbCenterLayers / (distance((Point)localObject4, (Point)localObject1) * (2 + this.nbCenterLayers));
        if ((f < 0.75D) || (f > 1.25D) || (!isWhiteOrBlackRectangle(localPoint1, localPoint2, localPoint3, localPoint4)))
          continue;
      }
      localObject1 = localPoint1;
      localObject2 = localPoint2;
      localObject3 = localPoint3;
      localObject4 = localPoint4;
      if (bool1);
      for (bool1 = false; ; bool1 = true)
      {
        this.nbCenterLayers = (1 + this.nbCenterLayers);
        break;
      }
    }
    if (this.nbCenterLayers == 5);
    for (boolean bool2 = true; ; bool2 = false)
    {
      this.compact = bool2;
      return expandSquare(new ResultPoint[] { new ResultPoint(0.5F + ((Point)localObject1).getX(), ((Point)localObject1).getY() - 0.5F), new ResultPoint(0.5F + ((Point)localObject2).getX(), 0.5F + ((Point)localObject2).getY()), new ResultPoint(((Point)localObject3).getX() - 0.5F, 0.5F + ((Point)localObject3).getY()), new ResultPoint(((Point)localObject4).getX() - 0.5F, ((Point)localObject4).getY() - 0.5F) }, -3 + 2 * this.nbCenterLayers, 2 * this.nbCenterLayers);
    }
  }

  private int getColor(Point paramPoint1, Point paramPoint2)
  {
    float f1 = distance(paramPoint1, paramPoint2);
    float f2 = (paramPoint2.getX() - paramPoint1.getX()) / f1;
    float f3 = (paramPoint2.getY() - paramPoint1.getY()) / f1;
    int i = 0;
    float f4 = paramPoint1.getX();
    float f5 = paramPoint1.getY();
    boolean bool1 = this.image.get(paramPoint1.getX(), paramPoint1.getY());
    float f6;
    for (int j = 0; ; j++)
    {
      if (j >= f1)
      {
        f6 = i / f1;
        if ((f6 <= 0.1F) || (f6 >= 0.9F))
          break;
        return 0;
      }
      f4 += f2;
      f5 += f3;
      if (this.image.get(MathUtils.round(f4), MathUtils.round(f5)) == bool1)
        continue;
      i++;
    }
    if (f6 <= 0.1F);
    for (boolean bool2 = true; bool2 == bool1; bool2 = false)
      return 1;
    return -1;
  }

  private static int getCorrectedParameterData(long paramLong, boolean paramBoolean)
    throws NotFoundException
  {
    int i;
    int j;
    int k;
    int[] arrayOfInt;
    int m;
    if (paramBoolean)
    {
      i = 7;
      j = 2;
      k = i - j;
      arrayOfInt = new int[i];
      m = i - 1;
      if (m >= 0)
        break label73;
    }
    while (true)
    {
      int i1;
      try
      {
        new ReedSolomonDecoder(GenericGF.AZTEC_PARAM).decode(arrayOfInt, k);
        n = 0;
        i1 = 0;
        if (i1 >= j)
        {
          return n;
          i = 10;
          j = 4;
          break;
          label73: arrayOfInt[m] = (0xF & (int)paramLong);
          paramLong >>= 4;
          m--;
        }
      }
      catch (ReedSolomonException localReedSolomonException)
      {
        throw NotFoundException.getNotFoundInstance();
      }
      int n = (n << 4) + arrayOfInt[i1];
      i1++;
    }
  }

  private int getDimension()
  {
    if (this.compact)
      return 11 + 4 * this.nbLayers;
    if (this.nbLayers <= 4)
      return 15 + 4 * this.nbLayers;
    return 15 + (4 * this.nbLayers + 2 * (1 + (-4 + this.nbLayers) / 8));
  }

  private Point getFirstDifferent(Point paramPoint, boolean paramBoolean, int paramInt1, int paramInt2)
  {
    int i = paramInt1 + paramPoint.getX();
    int j = paramInt2 + paramPoint.getY();
    int k;
    int m;
    label56: int n;
    if ((!isValid(i, j)) || (this.image.get(i, j) != paramBoolean))
    {
      k = i - paramInt1;
      m = j - paramInt2;
      if ((isValid(k, m)) && (this.image.get(k, m) == paramBoolean))
        break label145;
      n = k - paramInt1;
    }
    while (true)
    {
      if ((!isValid(n, m)) || (this.image.get(n, m) != paramBoolean))
      {
        return new Point(n, m - paramInt2);
        i += paramInt1;
        j += paramInt2;
        break;
        label145: k += paramInt1;
        break label56;
      }
      m += paramInt2;
    }
  }

  private Point getMatrixCenter()
  {
    try
    {
      ResultPoint[] arrayOfResultPoint2 = new WhiteRectangleDetector(this.image).detect();
      localResultPoint1 = arrayOfResultPoint2[0];
      localResultPoint2 = arrayOfResultPoint2[1];
      localResultPoint3 = arrayOfResultPoint2[2];
      localResultPoint4 = arrayOfResultPoint2[3];
      k = MathUtils.round((localResultPoint1.getX() + localResultPoint4.getX() + localResultPoint2.getX() + localResultPoint3.getX()) / 4.0F);
      m = MathUtils.round((localResultPoint1.getY() + localResultPoint4.getY() + localResultPoint2.getY() + localResultPoint3.getY()) / 4.0F);
    }
    catch (NotFoundException localNotFoundException1)
    {
      try
      {
        ResultPoint[] arrayOfResultPoint1 = new WhiteRectangleDetector(this.image, 15, k, m).detect();
        localResultPoint5 = arrayOfResultPoint1[0];
        localResultPoint6 = arrayOfResultPoint1[1];
        localResultPoint7 = arrayOfResultPoint1[2];
        localResultPoint8 = arrayOfResultPoint1[3];
        return new Point(MathUtils.round((localResultPoint5.getX() + localResultPoint8.getX() + localResultPoint6.getX() + localResultPoint7.getX()) / 4.0F), MathUtils.round((localResultPoint5.getY() + localResultPoint8.getY() + localResultPoint6.getY() + localResultPoint7.getY()) / 4.0F));
        localNotFoundException1 = localNotFoundException1;
        int i = this.image.getWidth() / 2;
        int j = this.image.getHeight() / 2;
        ResultPoint localResultPoint1 = getFirstDifferent(new Point(i + 7, j - 7), false, 1, -1).toResultPoint();
        ResultPoint localResultPoint2 = getFirstDifferent(new Point(i + 7, j + 7), false, 1, 1).toResultPoint();
        ResultPoint localResultPoint3 = getFirstDifferent(new Point(i - 7, j + 7), false, -1, 1).toResultPoint();
        ResultPoint localResultPoint4 = getFirstDifferent(new Point(i - 7, j - 7), false, -1, -1).toResultPoint();
      }
      catch (NotFoundException localNotFoundException2)
      {
        while (true)
        {
          int k;
          int m;
          ResultPoint localResultPoint5 = getFirstDifferent(new Point(k + 7, m - 7), false, 1, -1).toResultPoint();
          ResultPoint localResultPoint6 = getFirstDifferent(new Point(k + 7, m + 7), false, 1, 1).toResultPoint();
          ResultPoint localResultPoint7 = getFirstDifferent(new Point(k - 7, m + 7), false, -1, 1).toResultPoint();
          ResultPoint localResultPoint8 = getFirstDifferent(new Point(k - 7, m - 7), false, -1, -1).toResultPoint();
        }
      }
    }
  }

  private ResultPoint[] getMatrixCornerPoints(ResultPoint[] paramArrayOfResultPoint)
  {
    return expandSquare(paramArrayOfResultPoint, 2 * this.nbCenterLayers, getDimension());
  }

  private static int getRotation(int[] paramArrayOfInt, int paramInt)
    throws NotFoundException
  {
    int i = 0;
    int j = paramArrayOfInt.length;
    int k = 0;
    int n;
    if (k >= j)
      n = ((i & 0x1) << 11) + (i >> 1);
    for (int i1 = 0; ; i1++)
    {
      if (i1 >= 4)
      {
        throw NotFoundException.getNotFoundInstance();
        int m = paramArrayOfInt[k];
        i = (m >> paramInt - 2 << 1) + (m & 0x1) + (i << 3);
        k++;
        break;
      }
      if (Integer.bitCount(n ^ EXPECTED_CORNER_BITS[i1]) <= 2)
        return i1;
    }
  }

  private boolean isValid(int paramInt1, int paramInt2)
  {
    return (paramInt1 >= 0) && (paramInt1 < this.image.getWidth()) && (paramInt2 > 0) && (paramInt2 < this.image.getHeight());
  }

  private boolean isValid(ResultPoint paramResultPoint)
  {
    return isValid(MathUtils.round(paramResultPoint.getX()), MathUtils.round(paramResultPoint.getY()));
  }

  private boolean isWhiteOrBlackRectangle(Point paramPoint1, Point paramPoint2, Point paramPoint3, Point paramPoint4)
  {
    Point localPoint1 = new Point(paramPoint1.getX() - 3, 3 + paramPoint1.getY());
    Point localPoint2 = new Point(paramPoint2.getX() - 3, paramPoint2.getY() - 3);
    Point localPoint3 = new Point(3 + paramPoint3.getX(), paramPoint3.getY() - 3);
    Point localPoint4 = new Point(3 + paramPoint4.getX(), 3 + paramPoint4.getY());
    int i = getColor(localPoint4, localPoint1);
    if (i == 0);
    do
      return false;
    while ((getColor(localPoint1, localPoint2) != i) || (getColor(localPoint2, localPoint3) != i) || (getColor(localPoint3, localPoint4) != i));
    return true;
  }

  private BitMatrix sampleGrid(BitMatrix paramBitMatrix, ResultPoint paramResultPoint1, ResultPoint paramResultPoint2, ResultPoint paramResultPoint3, ResultPoint paramResultPoint4)
    throws NotFoundException
  {
    GridSampler localGridSampler = GridSampler.getInstance();
    int i = getDimension();
    float f1 = i / 2.0F - this.nbCenterLayers;
    float f2 = i / 2.0F + this.nbCenterLayers;
    return localGridSampler.sampleGrid(paramBitMatrix, i, i, f1, f1, f2, f1, f2, f2, f1, f2, paramResultPoint1.getX(), paramResultPoint1.getY(), paramResultPoint2.getX(), paramResultPoint2.getY(), paramResultPoint3.getX(), paramResultPoint3.getY(), paramResultPoint4.getX(), paramResultPoint4.getY());
  }

  private int sampleLine(ResultPoint paramResultPoint1, ResultPoint paramResultPoint2, int paramInt)
  {
    int i = 0;
    float f1 = distance(paramResultPoint1, paramResultPoint2);
    float f2 = f1 / paramInt;
    float f3 = paramResultPoint1.getX();
    float f4 = paramResultPoint1.getY();
    float f5 = f2 * (paramResultPoint2.getX() - paramResultPoint1.getX()) / f1;
    float f6 = f2 * (paramResultPoint2.getY() - paramResultPoint1.getY()) / f1;
    for (int j = 0; ; j++)
    {
      if (j >= paramInt)
        return i;
      if (!this.image.get(MathUtils.round(f3 + f5 * j), MathUtils.round(f4 + f6 * j)))
        continue;
      i |= 1 << -1 + (paramInt - j);
    }
  }

  public AztecDetectorResult detect()
    throws NotFoundException
  {
    return detect(false);
  }

  public AztecDetectorResult detect(boolean paramBoolean)
    throws NotFoundException
  {
    ResultPoint[] arrayOfResultPoint = getBullsEyeCorners(getMatrixCenter());
    if (paramBoolean)
    {
      ResultPoint localResultPoint = arrayOfResultPoint[0];
      arrayOfResultPoint[0] = arrayOfResultPoint[2];
      arrayOfResultPoint[2] = localResultPoint;
    }
    extractParameters(arrayOfResultPoint);
    return new AztecDetectorResult(sampleGrid(this.image, arrayOfResultPoint[(this.shift % 4)], arrayOfResultPoint[((1 + this.shift) % 4)], arrayOfResultPoint[((2 + this.shift) % 4)], arrayOfResultPoint[((3 + this.shift) % 4)]), getMatrixCornerPoints(arrayOfResultPoint), this.compact, this.nbDataBlocks, this.nbLayers);
  }

  static final class Point
  {
    private final int x;
    private final int y;

    Point(int paramInt1, int paramInt2)
    {
      this.x = paramInt1;
      this.y = paramInt2;
    }

    int getX()
    {
      return this.x;
    }

    int getY()
    {
      return this.y;
    }

    ResultPoint toResultPoint()
    {
      return new ResultPoint(getX(), getY());
    }

    public String toString()
    {
      return "<" + this.x + ' ' + this.y + '>';
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.aztec.detector.Detector
 * JD-Core Version:    0.6.0
 */