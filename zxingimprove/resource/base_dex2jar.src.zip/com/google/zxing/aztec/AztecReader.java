package com.google.zxing.aztec;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.Result;

public final class AztecReader
  implements Reader
{
  public Result decode(BinaryBitmap paramBinaryBitmap)
    throws NotFoundException, FormatException
  {
    return decode(paramBinaryBitmap, null);
  }

  // ERROR //
  public Result decode(BinaryBitmap paramBinaryBitmap, java.util.Map<com.google.zxing.DecodeHintType, ?> paramMap)
    throws NotFoundException, FormatException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore 4
    //   5: new 21	com/google/zxing/aztec/detector/Detector
    //   8: dup
    //   9: aload_1
    //   10: invokevirtual 27	com/google/zxing/BinaryBitmap:getBlackMatrix	()Lcom/google/zxing/common/BitMatrix;
    //   13: invokespecial 30	com/google/zxing/aztec/detector/Detector:<init>	(Lcom/google/zxing/common/BitMatrix;)V
    //   16: astore 5
    //   18: aconst_null
    //   19: astore 6
    //   21: aload 5
    //   23: iconst_0
    //   24: invokevirtual 34	com/google/zxing/aztec/detector/Detector:detect	(Z)Lcom/google/zxing/aztec/AztecDetectorResult;
    //   27: astore 19
    //   29: aload 19
    //   31: invokevirtual 40	com/google/zxing/aztec/AztecDetectorResult:getPoints	()[Lcom/google/zxing/ResultPoint;
    //   34: astore 6
    //   36: new 42	com/google/zxing/aztec/decoder/Decoder
    //   39: dup
    //   40: invokespecial 43	com/google/zxing/aztec/decoder/Decoder:<init>	()V
    //   43: aload 19
    //   45: invokevirtual 46	com/google/zxing/aztec/decoder/Decoder:decode	(Lcom/google/zxing/aztec/AztecDetectorResult;)Lcom/google/zxing/common/DecoderResult;
    //   48: astore 20
    //   50: aload 20
    //   52: astore 8
    //   54: aload 8
    //   56: ifnonnull +36 -> 92
    //   59: aload 5
    //   61: iconst_1
    //   62: invokevirtual 34	com/google/zxing/aztec/detector/Detector:detect	(Z)Lcom/google/zxing/aztec/AztecDetectorResult;
    //   65: astore 16
    //   67: aload 16
    //   69: invokevirtual 40	com/google/zxing/aztec/AztecDetectorResult:getPoints	()[Lcom/google/zxing/ResultPoint;
    //   72: astore 6
    //   74: new 42	com/google/zxing/aztec/decoder/Decoder
    //   77: dup
    //   78: invokespecial 43	com/google/zxing/aztec/decoder/Decoder:<init>	()V
    //   81: aload 16
    //   83: invokevirtual 46	com/google/zxing/aztec/decoder/Decoder:decode	(Lcom/google/zxing/aztec/AztecDetectorResult;)Lcom/google/zxing/common/DecoderResult;
    //   86: astore 17
    //   88: aload 17
    //   90: astore 8
    //   92: aload_2
    //   93: ifnull +37 -> 130
    //   96: aload_2
    //   97: getstatic 52	com/google/zxing/DecodeHintType:NEED_RESULT_POINT_CALLBACK	Lcom/google/zxing/DecodeHintType;
    //   100: invokeinterface 58 2 0
    //   105: checkcast 60	com/google/zxing/ResultPointCallback
    //   108: astore 12
    //   110: aload 12
    //   112: ifnull +18 -> 130
    //   115: aload 6
    //   117: arraylength
    //   118: istore 13
    //   120: iconst_0
    //   121: istore 14
    //   123: iload 14
    //   125: iload 13
    //   127: if_icmplt +121 -> 248
    //   130: new 62	com/google/zxing/Result
    //   133: dup
    //   134: aload 8
    //   136: invokevirtual 68	com/google/zxing/common/DecoderResult:getText	()Ljava/lang/String;
    //   139: aload 8
    //   141: invokevirtual 72	com/google/zxing/common/DecoderResult:getRawBytes	()[B
    //   144: aload 6
    //   146: getstatic 78	com/google/zxing/BarcodeFormat:AZTEC	Lcom/google/zxing/BarcodeFormat;
    //   149: invokespecial 81	com/google/zxing/Result:<init>	(Ljava/lang/String;[B[Lcom/google/zxing/ResultPoint;Lcom/google/zxing/BarcodeFormat;)V
    //   152: astore 9
    //   154: aload 8
    //   156: invokevirtual 85	com/google/zxing/common/DecoderResult:getByteSegments	()Ljava/util/List;
    //   159: astore 10
    //   161: aload 10
    //   163: ifnull +13 -> 176
    //   166: aload 9
    //   168: getstatic 91	com/google/zxing/ResultMetadataType:BYTE_SEGMENTS	Lcom/google/zxing/ResultMetadataType;
    //   171: aload 10
    //   173: invokevirtual 95	com/google/zxing/Result:putMetadata	(Lcom/google/zxing/ResultMetadataType;Ljava/lang/Object;)V
    //   176: aload 8
    //   178: invokevirtual 98	com/google/zxing/common/DecoderResult:getECLevel	()Ljava/lang/String;
    //   181: astore 11
    //   183: aload 11
    //   185: ifnull +13 -> 198
    //   188: aload 9
    //   190: getstatic 101	com/google/zxing/ResultMetadataType:ERROR_CORRECTION_LEVEL	Lcom/google/zxing/ResultMetadataType;
    //   193: aload 11
    //   195: invokevirtual 95	com/google/zxing/Result:putMetadata	(Lcom/google/zxing/ResultMetadataType;Ljava/lang/Object;)V
    //   198: aload 9
    //   200: areturn
    //   201: astore 18
    //   203: aload 18
    //   205: astore_3
    //   206: aconst_null
    //   207: astore 8
    //   209: aconst_null
    //   210: astore 4
    //   212: goto -158 -> 54
    //   215: astore 7
    //   217: aload 7
    //   219: astore 4
    //   221: aconst_null
    //   222: astore 8
    //   224: aconst_null
    //   225: astore_3
    //   226: goto -172 -> 54
    //   229: astore 15
    //   231: aload_3
    //   232: ifnull +5 -> 237
    //   235: aload_3
    //   236: athrow
    //   237: aload 4
    //   239: ifnull +6 -> 245
    //   242: aload 4
    //   244: athrow
    //   245: aload 15
    //   247: athrow
    //   248: aload 12
    //   250: aload 6
    //   252: iload 14
    //   254: aaload
    //   255: invokeinterface 105 2 0
    //   260: iinc 14 1
    //   263: goto -140 -> 123
    //
    // Exception table:
    //   from	to	target	type
    //   21	50	201	com/google/zxing/NotFoundException
    //   21	50	215	com/google/zxing/FormatException
    //   59	88	229	com/google/zxing/NotFoundException
  }

  public void reset()
  {
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.aztec.AztecReader
 * JD-Core Version:    0.6.0
 */