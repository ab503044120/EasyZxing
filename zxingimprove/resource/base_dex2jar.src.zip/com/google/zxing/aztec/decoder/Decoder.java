package com.google.zxing.aztec.decoder;

import com.google.zxing.FormatException;
import com.google.zxing.aztec.AztecDetectorResult;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonDecoder;
import com.google.zxing.common.reedsolomon.ReedSolomonException;
import java.util.Arrays;

public final class Decoder
{
  private static final String[] DIGIT_TABLE;
  private static final String[] LOWER_TABLE;
  private static final String[] MIXED_TABLE;
  private static final String[] PUNCT_TABLE;
  private static final String[] UPPER_TABLE = { "CTRL_PS", " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "CTRL_LL", "CTRL_ML", "CTRL_DL", "CTRL_BS" };
  private AztecDetectorResult ddata;

  static
  {
    LOWER_TABLE = new String[] { "CTRL_PS", " ", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "CTRL_US", "CTRL_ML", "CTRL_DL", "CTRL_BS" };
    MIXED_TABLE = new String[] { "CTRL_PS", " ", "\001", "\002", "\003", "\004", "\005", "\006", "\007", "\b", "\t", "\n", "\013", "\f", "\r", "\033", "\034", "\035", "\036", "\037", "@", "\\", "^", "_", "`", "|", "~", "", "CTRL_LL", "CTRL_UL", "CTRL_PL", "CTRL_BS" };
    PUNCT_TABLE = new String[] { "", "\r", "\r\n", ". ", ", ", ": ", "!", "\"", "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";", "<", "=", ">", "?", "[", "]", "{", "}", "CTRL_UL" };
    DIGIT_TABLE = new String[] { "CTRL_PS", " ", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", ",", ".", "CTRL_UL", "CTRL_US" };
  }

  private boolean[] correctBits(boolean[] paramArrayOfBoolean)
    throws FormatException
  {
    int i;
    GenericGF localGenericGF;
    if (this.ddata.getNbLayers() <= 2)
    {
      i = 6;
      localGenericGF = GenericGF.AZTEC_DATA_6;
    }
    int j;
    int k;
    while (true)
    {
      j = this.ddata.getNbDatablocks();
      k = paramArrayOfBoolean.length / i;
      if (k >= j)
        break;
      throw FormatException.getFormatInstance();
      if (this.ddata.getNbLayers() <= 8)
      {
        i = 8;
        localGenericGF = GenericGF.AZTEC_DATA_8;
        continue;
      }
      if (this.ddata.getNbLayers() <= 22)
      {
        i = 10;
        localGenericGF = GenericGF.AZTEC_DATA_10;
        continue;
      }
      i = 12;
      localGenericGF = GenericGF.AZTEC_DATA_12;
    }
    int m = paramArrayOfBoolean.length % i;
    int n = k - j;
    int[] arrayOfInt = new int[k];
    int i1 = 0;
    if (i1 >= k);
    int i2;
    boolean[] arrayOfBoolean;
    int i6;
    int i7;
    while (true)
    {
      int i3;
      int i4;
      try
      {
        ReedSolomonDecoder localReedSolomonDecoder = new ReedSolomonDecoder(localGenericGF);
        localReedSolomonDecoder.decode(arrayOfInt, n);
        i2 = -1 + (1 << i);
        i3 = 0;
        i4 = 0;
        if (i4 >= j)
        {
          arrayOfBoolean = new boolean[j * i - i3];
          i6 = 0;
          i7 = 0;
          if (i7 < j)
            break label270;
          return arrayOfBoolean;
          arrayOfInt[i1] = readCode(paramArrayOfBoolean, m, i);
          i1++;
          m += i;
        }
      }
      catch (ReedSolomonException localReedSolomonException)
      {
        throw FormatException.getFormatInstance();
      }
      int i5 = arrayOfInt[i4];
      if ((i5 == 0) || (i5 == i2))
        throw FormatException.getFormatInstance();
      if ((i5 == 1) || (i5 == i2 - 1))
        i3++;
      i4++;
    }
    label270: int i8 = arrayOfInt[i7];
    boolean bool;
    if ((i8 == 1) || (i8 == i2 - 1))
    {
      int i9 = -1 + (i6 + i);
      if (i8 > 1)
      {
        bool = true;
        label309: Arrays.fill(arrayOfBoolean, i6, i9, bool);
        i6 += i - 1;
      }
    }
    int i10;
    int i11;
    while (true)
    {
      i7++;
      break;
      bool = false;
      break label309;
      i10 = i - 1;
      i11 = i6;
      if (i10 >= 0)
        break label361;
      i6 = i11;
    }
    label361: int i12 = i11 + 1;
    if ((i8 & 1 << i10) != 0);
    for (int i13 = 1; ; i13 = 0)
    {
      arrayOfBoolean[i11] = i13;
      i10--;
      i11 = i12;
      break;
    }
  }

  private static String getCharacter(Table paramTable, int paramInt)
  {
    switch ($SWITCH_TABLE$com$google$zxing$aztec$decoder$Decoder$Table()[paramTable.ordinal()])
    {
    default:
      throw new IllegalStateException("Bad table");
    case 1:
      return UPPER_TABLE[paramInt];
    case 2:
      return LOWER_TABLE[paramInt];
    case 3:
      return MIXED_TABLE[paramInt];
    case 5:
      return PUNCT_TABLE[paramInt];
    case 4:
    }
    return DIGIT_TABLE[paramInt];
  }

  private static String getEncodedData(boolean[] paramArrayOfBoolean)
  {
    int i = paramArrayOfBoolean.length;
    Object localObject1 = Table.UPPER;
    Object localObject2 = Table.UPPER;
    StringBuilder localStringBuilder = new StringBuilder(20);
    int j = 0;
    while (true)
    {
      if (j >= i);
      label124: String str;
      label234: 
      while (true)
      {
        return localStringBuilder.toString();
        if (localObject2 == Table.BINARY)
        {
          if (i - j < 5)
            continue;
          int n = readCode(paramArrayOfBoolean, j, 5);
          j += 5;
          if (n == 0)
          {
            if (i - j < 11)
              continue;
            n = 31 + readCode(paramArrayOfBoolean, j, 11);
            j += 11;
          }
          for (int i1 = 0; ; i1++)
          {
            if (i1 >= n);
            while (true)
            {
              localObject2 = localObject1;
              break;
              if (i - j >= 8)
                break label124;
              j = i;
            }
            localStringBuilder.append((char)readCode(paramArrayOfBoolean, j, 8));
            j += 8;
          }
        }
        if (localObject2 == Table.DIGIT);
        for (int k = 4; ; k = 5)
        {
          if (i - j < k)
            break label234;
          int m = readCode(paramArrayOfBoolean, j, k);
          j += k;
          str = getCharacter((Table)localObject2, m);
          if (!str.startsWith("CTRL_"))
            break label236;
          localObject2 = getTable(str.charAt(5));
          if (str.charAt(6) != 'L')
            break;
          localObject1 = localObject2;
          break;
        }
      }
      label236: localStringBuilder.append(str);
      localObject2 = localObject1;
    }
  }

  private static Table getTable(char paramChar)
  {
    switch (paramChar)
    {
    default:
      return Table.UPPER;
    case 'L':
      return Table.LOWER;
    case 'P':
      return Table.PUNCT;
    case 'M':
      return Table.MIXED;
    case 'D':
      return Table.DIGIT;
    case 'B':
    }
    return Table.BINARY;
  }

  public static String highLevelDecode(boolean[] paramArrayOfBoolean)
  {
    return getEncodedData(paramArrayOfBoolean);
  }

  private static int readCode(boolean[] paramArrayOfBoolean, int paramInt1, int paramInt2)
  {
    int i = 0;
    for (int j = paramInt1; ; j++)
    {
      if (j >= paramInt1 + paramInt2)
        return i;
      i <<= 1;
      if (paramArrayOfBoolean[j] == 0)
        continue;
      i |= 1;
    }
  }

  private static int totalBitsInLayer(int paramInt, boolean paramBoolean)
  {
    if (paramBoolean);
    for (int i = 88; ; i = 112)
      return paramInt * (i + paramInt * 16);
  }

  public DecoderResult decode(AztecDetectorResult paramAztecDetectorResult)
    throws FormatException
  {
    this.ddata = paramAztecDetectorResult;
    return new DecoderResult(null, getEncodedData(correctBits(extractBits(paramAztecDetectorResult.getBits()))), null, null);
  }

  boolean[] extractBits(BitMatrix paramBitMatrix)
  {
    boolean bool = this.ddata.isCompact();
    int i = this.ddata.getNbLayers();
    int j;
    int[] arrayOfInt;
    boolean[] arrayOfBoolean;
    int i11;
    if (bool)
    {
      j = 11 + i * 4;
      arrayOfInt = new int[j];
      arrayOfBoolean = new boolean[totalBitsInLayer(i, bool)];
      if (!bool)
        break label97;
      i11 = 0;
      label50: if (i11 < arrayOfInt.length)
        break label84;
    }
    int i3;
    int i4;
    while (true)
    {
      i3 = 0;
      i4 = 0;
      if (i3 < i)
        break label185;
      return arrayOfBoolean;
      j = 14 + i * 4;
      break;
      label84: arrayOfInt[i11] = i11;
      i11++;
      break label50;
      label97: int k = j + 1 + 2 * ((-1 + j / 2) / 15);
      int m = j / 2;
      int n = k / 2;
      for (int i1 = 0; i1 < m; i1++)
      {
        int i2 = i1 + i1 / 15;
        arrayOfInt[(-1 + (m - i1))] = (-1 + (n - i2));
        arrayOfInt[(m + i1)] = (1 + (n + i2));
      }
    }
    label185: if (bool);
    int i6;
    int i7;
    int i8;
    for (int i5 = 9 + 4 * (i - i3); ; i5 = 12 + 4 * (i - i3))
    {
      i6 = i3 * 2;
      i7 = j - 1 - i6;
      i8 = 0;
      if (i8 < i5)
        break label255;
      i4 += i5 * 8;
      i3++;
      break;
    }
    label255: int i9 = i8 * 2;
    for (int i10 = 0; ; i10++)
    {
      if (i10 >= 2)
      {
        i8++;
        break;
      }
      arrayOfBoolean[(i10 + (i4 + i9))] = paramBitMatrix.get(arrayOfInt[(i6 + i10)], arrayOfInt[(i6 + i8)]);
      arrayOfBoolean[(i10 + (i9 + (i4 + i5 * 2)))] = paramBitMatrix.get(arrayOfInt[(i6 + i8)], arrayOfInt[(i7 - i10)]);
      arrayOfBoolean[(i10 + (i9 + (i4 + i5 * 4)))] = paramBitMatrix.get(arrayOfInt[(i7 - i10)], arrayOfInt[(i7 - i8)]);
      arrayOfBoolean[(i10 + (i9 + (i4 + i5 * 6)))] = paramBitMatrix.get(arrayOfInt[(i7 - i8)], arrayOfInt[(i6 + i10)]);
    }
  }

  private static enum Table
  {
    static
    {
      LOWER = new Table("LOWER", 1);
      MIXED = new Table("MIXED", 2);
      DIGIT = new Table("DIGIT", 3);
      PUNCT = new Table("PUNCT", 4);
      BINARY = new Table("BINARY", 5);
      Table[] arrayOfTable = new Table[6];
      arrayOfTable[0] = UPPER;
      arrayOfTable[1] = LOWER;
      arrayOfTable[2] = MIXED;
      arrayOfTable[3] = DIGIT;
      arrayOfTable[4] = PUNCT;
      arrayOfTable[5] = BINARY;
      ENUM$VALUES = arrayOfTable;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.aztec.decoder.Decoder
 * JD-Core Version:    0.6.0
 */