package com.google.zxing.aztec;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.Writer;
import com.google.zxing.aztec.encoder.AztecCode;
import com.google.zxing.aztec.encoder.Encoder;
import com.google.zxing.common.BitMatrix;
import java.nio.charset.Charset;
import java.util.Map;

public final class AztecWriter
  implements Writer
{
  private static final Charset DEFAULT_CHARSET = Charset.forName("ISO-8859-1");

  private static BitMatrix encode(String paramString, BarcodeFormat paramBarcodeFormat, int paramInt1, int paramInt2, Charset paramCharset, int paramInt3, int paramInt4)
  {
    if (paramBarcodeFormat != BarcodeFormat.AZTEC)
      throw new IllegalArgumentException("Can only encode AZTEC, but got " + paramBarcodeFormat);
    return renderResult(Encoder.encode(paramString.getBytes(paramCharset), paramInt3, paramInt4), paramInt1, paramInt2);
  }

  private static BitMatrix renderResult(AztecCode paramAztecCode, int paramInt1, int paramInt2)
  {
    BitMatrix localBitMatrix1 = paramAztecCode.getMatrix();
    if (localBitMatrix1 == null)
      throw new IllegalStateException();
    int i = localBitMatrix1.getWidth();
    int j = localBitMatrix1.getHeight();
    int k = Math.max(paramInt1, i);
    int m = Math.max(paramInt2, j);
    int n = Math.min(k / i, m / j);
    int i1 = (k - i * n) / 2;
    int i2 = (m - j * n) / 2;
    BitMatrix localBitMatrix2 = new BitMatrix(k, m);
    int i3 = 0;
    int i4 = i2;
    if (i3 >= j)
      return localBitMatrix2;
    int i5 = 0;
    int i6 = i1;
    while (true)
    {
      if (i5 >= i)
      {
        i3++;
        i4 += n;
        break;
      }
      if (localBitMatrix1.get(i5, i3))
        localBitMatrix2.setRegion(i6, i4, n, n);
      i5++;
      i6 += n;
    }
  }

  public BitMatrix encode(String paramString, BarcodeFormat paramBarcodeFormat, int paramInt1, int paramInt2)
  {
    return encode(paramString, paramBarcodeFormat, paramInt1, paramInt2, null);
  }

  public BitMatrix encode(String paramString, BarcodeFormat paramBarcodeFormat, int paramInt1, int paramInt2, Map<EncodeHintType, ?> paramMap)
  {
    String str;
    Number localNumber1;
    label16: Number localNumber2;
    label24: Charset localCharset;
    label34: int i;
    if (paramMap == null)
    {
      str = null;
      if (paramMap != null)
        break label84;
      localNumber1 = null;
      localNumber2 = null;
      if (paramMap != null)
        break label102;
      if (str != null)
        break label120;
      localCharset = DEFAULT_CHARSET;
      if (localNumber1 != null)
        break label130;
      i = 33;
      label43: if (localNumber2 != null)
        break label140;
    }
    label130: label140: for (int j = 0; ; j = localNumber2.intValue())
    {
      return encode(paramString, paramBarcodeFormat, paramInt1, paramInt2, localCharset, i, j);
      str = (String)paramMap.get(EncodeHintType.CHARACTER_SET);
      break;
      label84: localNumber1 = (Number)paramMap.get(EncodeHintType.ERROR_CORRECTION);
      break label16;
      label102: localNumber2 = (Number)paramMap.get(EncodeHintType.AZTEC_LAYERS);
      break label24;
      label120: localCharset = Charset.forName(str);
      break label34;
      i = localNumber1.intValue();
      break label43;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.aztec.AztecWriter
 * JD-Core Version:    0.6.0
 */