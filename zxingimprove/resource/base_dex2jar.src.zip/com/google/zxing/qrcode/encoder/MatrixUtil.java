package com.google.zxing.qrcode.encoder;

import com.google.zxing.WriterException;
import com.google.zxing.common.BitArray;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.decoder.Version;

final class MatrixUtil
{
  private static final int[][] POSITION_ADJUSTMENT_PATTERN;
  private static final int[][] POSITION_ADJUSTMENT_PATTERN_COORDINATE_TABLE;
  private static final int[][] POSITION_DETECTION_PATTERN;
  private static final int[][] TYPE_INFO_COORDINATES;
  private static final int TYPE_INFO_MASK_PATTERN = 21522;
  private static final int TYPE_INFO_POLY = 1335;
  private static final int VERSION_INFO_POLY = 7973;

  static
  {
    int[][] arrayOfInt1 = new int[7][];
    arrayOfInt1[0] = { 1, 1, 1, 1, 1, 1, 1 };
    int[] arrayOfInt2 = new int[7];
    arrayOfInt2[0] = 1;
    arrayOfInt2[6] = 1;
    arrayOfInt1[1] = arrayOfInt2;
    int[] arrayOfInt3 = new int[7];
    arrayOfInt3[0] = 1;
    arrayOfInt3[2] = 1;
    arrayOfInt3[3] = 1;
    arrayOfInt3[4] = 1;
    arrayOfInt3[6] = 1;
    arrayOfInt1[2] = arrayOfInt3;
    int[] arrayOfInt4 = new int[7];
    arrayOfInt4[0] = 1;
    arrayOfInt4[2] = 1;
    arrayOfInt4[3] = 1;
    arrayOfInt4[4] = 1;
    arrayOfInt4[6] = 1;
    arrayOfInt1[3] = arrayOfInt4;
    int[] arrayOfInt5 = new int[7];
    arrayOfInt5[0] = 1;
    arrayOfInt5[2] = 1;
    arrayOfInt5[3] = 1;
    arrayOfInt5[4] = 1;
    arrayOfInt5[6] = 1;
    arrayOfInt1[4] = arrayOfInt5;
    int[] arrayOfInt6 = new int[7];
    arrayOfInt6[0] = 1;
    arrayOfInt6[6] = 1;
    arrayOfInt1[5] = arrayOfInt6;
    arrayOfInt1[6] = { 1, 1, 1, 1, 1, 1, 1 };
    POSITION_DETECTION_PATTERN = arrayOfInt1;
    int[][] arrayOfInt7 = new int[5][];
    arrayOfInt7[0] = { 1, 1, 1, 1, 1 };
    int[] arrayOfInt8 = new int[5];
    arrayOfInt8[0] = 1;
    arrayOfInt8[4] = 1;
    arrayOfInt7[1] = arrayOfInt8;
    int[] arrayOfInt9 = new int[5];
    arrayOfInt9[0] = 1;
    arrayOfInt9[2] = 1;
    arrayOfInt9[4] = 1;
    arrayOfInt7[2] = arrayOfInt9;
    int[] arrayOfInt10 = new int[5];
    arrayOfInt10[0] = 1;
    arrayOfInt10[4] = 1;
    arrayOfInt7[3] = arrayOfInt10;
    arrayOfInt7[4] = { 1, 1, 1, 1, 1 };
    POSITION_ADJUSTMENT_PATTERN = arrayOfInt7;
    POSITION_ADJUSTMENT_PATTERN_COORDINATE_TABLE = new int[][] { { -1, -1, -1, -1, -1, -1, -1 }, { 6, 18, -1, -1, -1, -1, -1 }, { 6, 22, -1, -1, -1, -1, -1 }, { 6, 26, -1, -1, -1, -1, -1 }, { 6, 30, -1, -1, -1, -1, -1 }, { 6, 34, -1, -1, -1, -1, -1 }, { 6, 22, 38, -1, -1, -1, -1 }, { 6, 24, 42, -1, -1, -1, -1 }, { 6, 26, 46, -1, -1, -1, -1 }, { 6, 28, 50, -1, -1, -1, -1 }, { 6, 30, 54, -1, -1, -1, -1 }, { 6, 32, 58, -1, -1, -1, -1 }, { 6, 34, 62, -1, -1, -1, -1 }, { 6, 26, 46, 66, -1, -1, -1 }, { 6, 26, 48, 70, -1, -1, -1 }, { 6, 26, 50, 74, -1, -1, -1 }, { 6, 30, 54, 78, -1, -1, -1 }, { 6, 30, 56, 82, -1, -1, -1 }, { 6, 30, 58, 86, -1, -1, -1 }, { 6, 34, 62, 90, -1, -1, -1 }, { 6, 28, 50, 72, 94, -1, -1 }, { 6, 26, 50, 74, 98, -1, -1 }, { 6, 30, 54, 78, 102, -1, -1 }, { 6, 28, 54, 80, 106, -1, -1 }, { 6, 32, 58, 84, 110, -1, -1 }, { 6, 30, 58, 86, 114, -1, -1 }, { 6, 34, 62, 90, 118, -1, -1 }, { 6, 26, 50, 74, 98, 122, -1 }, { 6, 30, 54, 78, 102, 126, -1 }, { 6, 26, 52, 78, 104, 130, -1 }, { 6, 30, 56, 82, 108, 134, -1 }, { 6, 34, 60, 86, 112, 138, -1 }, { 6, 30, 58, 86, 114, 142, -1 }, { 6, 34, 62, 90, 118, 146, -1 }, { 6, 30, 54, 78, 102, 126, 150 }, { 6, 24, 50, 76, 102, 128, 154 }, { 6, 28, 54, 80, 106, 132, 158 }, { 6, 32, 58, 84, 110, 136, 162 }, { 6, 26, 54, 82, 110, 138, 166 }, { 6, 30, 58, 86, 114, 142, 170 } };
    int[][] arrayOfInt11 = new int[15][];
    int[] arrayOfInt12 = new int[2];
    arrayOfInt12[0] = 8;
    arrayOfInt11[0] = arrayOfInt12;
    arrayOfInt11[1] = { 8, 1 };
    arrayOfInt11[2] = { 8, 2 };
    arrayOfInt11[3] = { 8, 3 };
    arrayOfInt11[4] = { 8, 4 };
    arrayOfInt11[5] = { 8, 5 };
    arrayOfInt11[6] = { 8, 7 };
    arrayOfInt11[7] = { 8, 8 };
    arrayOfInt11[8] = { 7, 8 };
    arrayOfInt11[9] = { 5, 8 };
    arrayOfInt11[10] = { 4, 8 };
    arrayOfInt11[11] = { 3, 8 };
    arrayOfInt11[12] = { 2, 8 };
    arrayOfInt11[13] = { 1, 8 };
    int[] arrayOfInt13 = new int[2];
    arrayOfInt13[1] = 8;
    arrayOfInt11[14] = arrayOfInt13;
    TYPE_INFO_COORDINATES = arrayOfInt11;
  }

  static void buildMatrix(BitArray paramBitArray, ErrorCorrectionLevel paramErrorCorrectionLevel, Version paramVersion, int paramInt, ByteMatrix paramByteMatrix)
    throws WriterException
  {
    clearMatrix(paramByteMatrix);
    embedBasicPatterns(paramVersion, paramByteMatrix);
    embedTypeInfo(paramErrorCorrectionLevel, paramInt, paramByteMatrix);
    maybeEmbedVersionInfo(paramVersion, paramByteMatrix);
    embedDataBits(paramBitArray, paramInt, paramByteMatrix);
  }

  static int calculateBCHCode(int paramInt1, int paramInt2)
  {
    if (paramInt2 == 0)
      throw new IllegalArgumentException("0 polynomial");
    int i = findMSBSet(paramInt2);
    int j = paramInt1 << i - 1;
    while (true)
    {
      if (findMSBSet(j) < i)
        return j;
      j ^= paramInt2 << findMSBSet(j) - i;
    }
  }

  static void clearMatrix(ByteMatrix paramByteMatrix)
  {
    paramByteMatrix.clear(-1);
  }

  static void embedBasicPatterns(Version paramVersion, ByteMatrix paramByteMatrix)
    throws WriterException
  {
    embedPositionDetectionPatternsAndSeparators(paramByteMatrix);
    embedDarkDotAtLeftBottomCorner(paramByteMatrix);
    maybeEmbedPositionAdjustmentPatterns(paramVersion, paramByteMatrix);
    embedTimingPatterns(paramByteMatrix);
  }

  private static void embedDarkDotAtLeftBottomCorner(ByteMatrix paramByteMatrix)
    throws WriterException
  {
    if (paramByteMatrix.get(8, -8 + paramByteMatrix.getHeight()) == 0)
      throw new WriterException();
    paramByteMatrix.set(8, -8 + paramByteMatrix.getHeight(), 1);
  }

  static void embedDataBits(BitArray paramBitArray, int paramInt, ByteMatrix paramByteMatrix)
    throws WriterException
  {
    int i = 0;
    int j = -1;
    int k = -1 + paramByteMatrix.getWidth();
    int m = -1 + paramByteMatrix.getHeight();
    while (true)
      if (k <= 0)
      {
        if (i == paramBitArray.getSize())
          break;
        throw new WriterException("Not all bits consumed: " + i + '/' + paramBitArray.getSize());
      }
      else
      {
        if (k == 6)
          k--;
        if ((m < 0) || (m >= paramByteMatrix.getHeight()))
        {
          j = -j;
          m += j;
          k -= 2;
          continue;
        }
        int i1;
        for (int n = 0; ; n++)
        {
          if (n >= 2)
          {
            m += j;
            break;
          }
          i1 = k - n;
          if (isEmpty(paramByteMatrix.get(i1, m)))
            break label158;
        }
        label158: if (i < paramBitArray.getSize())
        {
          bool = paramBitArray.get(i);
          i++;
          label176: if ((paramInt != -1) && (MaskUtil.getDataMaskBit(paramInt, i1, m)))
            if (!bool)
              break label219;
        }
        label219: for (boolean bool = false; ; bool = true)
        {
          paramByteMatrix.set(i1, m, bool);
          break;
          bool = false;
          break label176;
        }
      }
  }

  private static void embedHorizontalSeparationPattern(int paramInt1, int paramInt2, ByteMatrix paramByteMatrix)
    throws WriterException
  {
    for (int i = 0; ; i++)
    {
      if (i >= 8)
        return;
      if (!isEmpty(paramByteMatrix.get(paramInt1 + i, paramInt2)))
        throw new WriterException();
      paramByteMatrix.set(paramInt1 + i, paramInt2, 0);
    }
  }

  private static void embedPositionAdjustmentPattern(int paramInt1, int paramInt2, ByteMatrix paramByteMatrix)
  {
    int i = 0;
    if (i >= 5)
      return;
    for (int j = 0; ; j++)
    {
      if (j >= 5)
      {
        i++;
        break;
      }
      paramByteMatrix.set(paramInt1 + j, paramInt2 + i, POSITION_ADJUSTMENT_PATTERN[i][j]);
    }
  }

  private static void embedPositionDetectionPattern(int paramInt1, int paramInt2, ByteMatrix paramByteMatrix)
  {
    int i = 0;
    if (i >= 7)
      return;
    for (int j = 0; ; j++)
    {
      if (j >= 7)
      {
        i++;
        break;
      }
      paramByteMatrix.set(paramInt1 + j, paramInt2 + i, POSITION_DETECTION_PATTERN[i][j]);
    }
  }

  private static void embedPositionDetectionPatternsAndSeparators(ByteMatrix paramByteMatrix)
    throws WriterException
  {
    int i = POSITION_DETECTION_PATTERN[0].length;
    embedPositionDetectionPattern(0, 0, paramByteMatrix);
    embedPositionDetectionPattern(paramByteMatrix.getWidth() - i, 0, paramByteMatrix);
    embedPositionDetectionPattern(0, paramByteMatrix.getWidth() - i, paramByteMatrix);
    embedHorizontalSeparationPattern(0, 7, paramByteMatrix);
    embedHorizontalSeparationPattern(paramByteMatrix.getWidth() - 8, 7, paramByteMatrix);
    embedHorizontalSeparationPattern(0, paramByteMatrix.getWidth() - 8, paramByteMatrix);
    embedVerticalSeparationPattern(7, 0, paramByteMatrix);
    embedVerticalSeparationPattern(-1 + (paramByteMatrix.getHeight() - 7), 0, paramByteMatrix);
    embedVerticalSeparationPattern(7, paramByteMatrix.getHeight() - 7, paramByteMatrix);
  }

  private static void embedTimingPatterns(ByteMatrix paramByteMatrix)
  {
    for (int i = 8; ; i++)
    {
      if (i >= -8 + paramByteMatrix.getWidth())
        return;
      int j = (i + 1) % 2;
      if (isEmpty(paramByteMatrix.get(i, 6)))
        paramByteMatrix.set(i, 6, j);
      if (!isEmpty(paramByteMatrix.get(6, i)))
        continue;
      paramByteMatrix.set(6, i, j);
    }
  }

  static void embedTypeInfo(ErrorCorrectionLevel paramErrorCorrectionLevel, int paramInt, ByteMatrix paramByteMatrix)
    throws WriterException
  {
    BitArray localBitArray = new BitArray();
    makeTypeInfoBits(paramErrorCorrectionLevel, paramInt, localBitArray);
    int i = 0;
    if (i >= localBitArray.getSize())
      return;
    boolean bool = localBitArray.get(-1 + localBitArray.getSize() - i);
    paramByteMatrix.set(TYPE_INFO_COORDINATES[i][0], TYPE_INFO_COORDINATES[i][1], bool);
    if (i < 8)
      paramByteMatrix.set(-1 + (paramByteMatrix.getWidth() - i), 8, bool);
    while (true)
    {
      i++;
      break;
      paramByteMatrix.set(8, -7 + paramByteMatrix.getHeight() + (i - 8), bool);
    }
  }

  private static void embedVerticalSeparationPattern(int paramInt1, int paramInt2, ByteMatrix paramByteMatrix)
    throws WriterException
  {
    for (int i = 0; ; i++)
    {
      if (i >= 7)
        return;
      if (!isEmpty(paramByteMatrix.get(paramInt1, paramInt2 + i)))
        throw new WriterException();
      paramByteMatrix.set(paramInt1, paramInt2 + i, 0);
    }
  }

  static int findMSBSet(int paramInt)
  {
    for (int i = 0; ; i++)
    {
      if (paramInt == 0)
        return i;
      paramInt >>>= 1;
    }
  }

  private static boolean isEmpty(int paramInt)
  {
    return paramInt == -1;
  }

  static void makeTypeInfoBits(ErrorCorrectionLevel paramErrorCorrectionLevel, int paramInt, BitArray paramBitArray)
    throws WriterException
  {
    if (!QRCode.isValidMaskPattern(paramInt))
      throw new WriterException("Invalid mask pattern");
    int i = paramInt | paramErrorCorrectionLevel.getBits() << 3;
    paramBitArray.appendBits(i, 5);
    paramBitArray.appendBits(calculateBCHCode(i, 1335), 10);
    BitArray localBitArray = new BitArray();
    localBitArray.appendBits(21522, 15);
    paramBitArray.xor(localBitArray);
    if (paramBitArray.getSize() != 15)
      throw new WriterException("should not happen but we got: " + paramBitArray.getSize());
  }

  static void makeVersionInfoBits(Version paramVersion, BitArray paramBitArray)
    throws WriterException
  {
    paramBitArray.appendBits(paramVersion.getVersionNumber(), 6);
    paramBitArray.appendBits(calculateBCHCode(paramVersion.getVersionNumber(), 7973), 12);
    if (paramBitArray.getSize() != 18)
      throw new WriterException("should not happen but we got: " + paramBitArray.getSize());
  }

  private static void maybeEmbedPositionAdjustmentPatterns(Version paramVersion, ByteMatrix paramByteMatrix)
  {
    if (paramVersion.getVersionNumber() < 2);
    int[] arrayOfInt;
    int k;
    int m;
    while (true)
    {
      return;
      int i = -1 + paramVersion.getVersionNumber();
      arrayOfInt = POSITION_ADJUSTMENT_PATTERN_COORDINATE_TABLE[i];
      int j = POSITION_ADJUSTMENT_PATTERN_COORDINATE_TABLE[i].length;
      for (k = 0; k < j; k++)
      {
        m = 0;
        if (m < j)
          break label56;
      }
    }
    label56: int n = arrayOfInt[k];
    int i1 = arrayOfInt[m];
    if ((i1 == -1) || (n == -1));
    while (true)
    {
      m++;
      break;
      if (!isEmpty(paramByteMatrix.get(i1, n)))
        continue;
      embedPositionAdjustmentPattern(i1 - 2, n - 2, paramByteMatrix);
    }
  }

  static void maybeEmbedVersionInfo(Version paramVersion, ByteMatrix paramByteMatrix)
    throws WriterException
  {
    if (paramVersion.getVersionNumber() < 7)
      return;
    BitArray localBitArray = new BitArray();
    makeVersionInfoBits(paramVersion, localBitArray);
    int i = 17;
    int j = 0;
    label29: if (j < 6);
    for (int k = 0; ; k++)
    {
      if (k >= 3)
      {
        j++;
        break label29;
        break;
      }
      boolean bool = localBitArray.get(i);
      i--;
      paramByteMatrix.set(j, k + (-11 + paramByteMatrix.getHeight()), bool);
      paramByteMatrix.set(k + (-11 + paramByteMatrix.getHeight()), j, bool);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.qrcode.encoder.MatrixUtil
 * JD-Core Version:    0.6.0
 */