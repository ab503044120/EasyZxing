package com.google.zxing.qrcode.encoder;

final class MaskUtil
{
  private static final int N1 = 3;
  private static final int N2 = 3;
  private static final int N3 = 40;
  private static final int N4 = 10;

  static int applyMaskPenaltyRule1(ByteMatrix paramByteMatrix)
  {
    return applyMaskPenaltyRule1Internal(paramByteMatrix, true) + applyMaskPenaltyRule1Internal(paramByteMatrix, false);
  }

  private static int applyMaskPenaltyRule1Internal(ByteMatrix paramByteMatrix, boolean paramBoolean)
  {
    int i = 0;
    int j;
    int k;
    label21: byte[][] arrayOfByte;
    if (paramBoolean)
    {
      j = paramByteMatrix.getHeight();
      if (!paramBoolean)
        break label46;
      k = paramByteMatrix.getWidth();
      arrayOfByte = paramByteMatrix.getArray();
    }
    label46: int n;
    int i1;
    int i2;
    for (int m = 0; ; m++)
    {
      if (m >= j)
      {
        return i;
        j = paramByteMatrix.getWidth();
        break;
        k = paramByteMatrix.getHeight();
        break label21;
      }
      n = 0;
      i1 = -1;
      i2 = 0;
      if (i2 < k)
        break label92;
      if (n < 5)
        continue;
      i += 3 + (n - 5);
    }
    label92: int i3;
    if (paramBoolean)
    {
      i3 = arrayOfByte[m][i2];
      label106: if (i3 != i1)
        break label135;
      n++;
    }
    while (true)
    {
      i2++;
      break;
      i3 = arrayOfByte[i2][m];
      break label106;
      label135: if (n >= 5)
        i += 3 + (n - 5);
      n = 1;
      i1 = i3;
    }
  }

  static int applyMaskPenaltyRule2(ByteMatrix paramByteMatrix)
  {
    int i = 0;
    byte[][] arrayOfByte = paramByteMatrix.getArray();
    int j = paramByteMatrix.getWidth();
    int k = paramByteMatrix.getHeight();
    int m = 0;
    if (m >= k - 1)
      return i * 3;
    for (int n = 0; ; n++)
    {
      if (n >= j - 1)
      {
        m++;
        break;
      }
      int i1 = arrayOfByte[m][n];
      if ((i1 != arrayOfByte[m][(n + 1)]) || (i1 != arrayOfByte[(m + 1)][n]) || (i1 != arrayOfByte[(m + 1)][(n + 1)]))
        continue;
      i++;
    }
  }

  static int applyMaskPenaltyRule3(ByteMatrix paramByteMatrix)
  {
    int i = 0;
    byte[][] arrayOfByte = paramByteMatrix.getArray();
    int j = paramByteMatrix.getWidth();
    int k = paramByteMatrix.getHeight();
    int m = 0;
    if (m >= k)
      return i * 40;
    for (int n = 0; ; n++)
    {
      if (n >= j)
      {
        m++;
        break;
      }
      byte[] arrayOfByte1 = arrayOfByte[m];
      if ((n + 6 < j) && (arrayOfByte1[n] == 1) && (arrayOfByte1[(n + 1)] == 0) && (arrayOfByte1[(n + 2)] == 1) && (arrayOfByte1[(n + 3)] == 1) && (arrayOfByte1[(n + 4)] == 1) && (arrayOfByte1[(n + 5)] == 0) && (arrayOfByte1[(n + 6)] == 1) && ((isWhiteHorizontal(arrayOfByte1, n - 4, n)) || (isWhiteHorizontal(arrayOfByte1, n + 7, n + 11))))
        i++;
      if ((m + 6 >= k) || (arrayOfByte[m][n] != 1) || (arrayOfByte[(m + 1)][n] != 0) || (arrayOfByte[(m + 2)][n] != 1) || (arrayOfByte[(m + 3)][n] != 1) || (arrayOfByte[(m + 4)][n] != 1) || (arrayOfByte[(m + 5)][n] != 0) || (arrayOfByte[(m + 6)][n] != 1) || ((!isWhiteVertical(arrayOfByte, n, m - 4, m)) && (!isWhiteVertical(arrayOfByte, n, m + 7, m + 11))))
        continue;
      i++;
    }
  }

  static int applyMaskPenaltyRule4(ByteMatrix paramByteMatrix)
  {
    int i = 0;
    byte[][] arrayOfByte = paramByteMatrix.getArray();
    int j = paramByteMatrix.getWidth();
    int k = paramByteMatrix.getHeight();
    int m = 0;
    if (m >= k)
    {
      int i1 = paramByteMatrix.getHeight() * paramByteMatrix.getWidth();
      return 10 * (10 * Math.abs(i * 2 - i1) / i1);
    }
    byte[] arrayOfByte1 = arrayOfByte[m];
    for (int n = 0; ; n++)
    {
      if (n >= j)
      {
        m++;
        break;
      }
      if (arrayOfByte1[n] != 1)
        continue;
      i++;
    }
  }

  static boolean getDataMaskBit(int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    switch (paramInt1)
    {
    default:
      throw new IllegalArgumentException("Invalid mask pattern: " + paramInt1);
    case 0:
      i = 0x1 & paramInt3 + paramInt2;
    case 1:
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
    }
    while (i == 0)
    {
      return true;
      i = paramInt3 & 0x1;
      continue;
      i = paramInt2 % 3;
      continue;
      i = (paramInt3 + paramInt2) % 3;
      continue;
      i = 0x1 & paramInt3 / 2 + paramInt2 / 3;
      continue;
      int k = paramInt3 * paramInt2;
      i = (k & 0x1) + k % 3;
      continue;
      int j = paramInt3 * paramInt2;
      i = 0x1 & (j & 0x1) + j % 3;
      continue;
      i = 0x1 & paramInt3 * paramInt2 % 3 + (0x1 & paramInt3 + paramInt2);
    }
    return false;
  }

  private static boolean isWhiteHorizontal(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    for (int i = paramInt1; ; i++)
    {
      if (i >= paramInt2)
        return true;
      if ((i >= 0) && (i < paramArrayOfByte.length) && (paramArrayOfByte[i] == 1))
        return false;
    }
  }

  private static boolean isWhiteVertical(byte[][] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    for (int i = paramInt2; ; i++)
    {
      if (i >= paramInt3)
        return true;
      if ((i >= 0) && (i < paramArrayOfByte.length) && (paramArrayOfByte[i][paramInt1] == 1))
        return false;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.qrcode.encoder.MaskUtil
 * JD-Core Version:    0.6.0
 */