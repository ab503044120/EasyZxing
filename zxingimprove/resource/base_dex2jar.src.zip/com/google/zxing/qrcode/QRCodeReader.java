package com.google.zxing.qrcode;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.Reader;
import com.google.zxing.Result;
import com.google.zxing.ResultMetadataType;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.DetectorResult;
import com.google.zxing.qrcode.decoder.Decoder;
import com.google.zxing.qrcode.decoder.QRCodeDecoderMetaData;
import com.google.zxing.qrcode.detector.Detector;
import java.util.List;
import java.util.Map;

public class QRCodeReader
  implements Reader
{
  private static final ResultPoint[] NO_POINTS = new ResultPoint[0];
  private final Decoder decoder = new Decoder();

  private static BitMatrix extractPureBits(BitMatrix paramBitMatrix)
    throws NotFoundException
  {
    int[] arrayOfInt1 = paramBitMatrix.getTopLeftOnBit();
    int[] arrayOfInt2 = paramBitMatrix.getBottomRightOnBit();
    if ((arrayOfInt1 == null) || (arrayOfInt2 == null))
      throw NotFoundException.getNotFoundInstance();
    float f = moduleSize(arrayOfInt1, paramBitMatrix);
    int i = arrayOfInt1[1];
    int j = arrayOfInt2[1];
    int k = arrayOfInt1[0];
    int m = arrayOfInt2[0];
    if ((k >= m) || (i >= j))
      throw NotFoundException.getNotFoundInstance();
    if (j - i != m - k)
      m = k + (j - i);
    int n = Math.round((1 + (m - k)) / f);
    int i1 = Math.round((1 + (j - i)) / f);
    if ((n <= 0) || (i1 <= 0))
      throw NotFoundException.getNotFoundInstance();
    if (i1 != n)
      throw NotFoundException.getNotFoundInstance();
    int i2 = (int)(f / 2.0F);
    int i3 = i + i2;
    int i4 = k + i2;
    int i5 = i4 + (int)(f * (n - 1)) - m;
    if (i5 > 0)
    {
      if (i5 > i2)
        throw NotFoundException.getNotFoundInstance();
      i4 -= i5;
    }
    int i6 = i3 + (int)(f * (i1 - 1)) - j;
    if (i6 > 0)
    {
      if (i6 > i2)
        throw NotFoundException.getNotFoundInstance();
      i3 -= i6;
    }
    BitMatrix localBitMatrix = new BitMatrix(n, i1);
    int i7 = 0;
    if (i7 >= i1)
      return localBitMatrix;
    int i8 = i3 + (int)(f * i7);
    for (int i9 = 0; ; i9++)
    {
      if (i9 >= n)
      {
        i7++;
        break;
      }
      if (!paramBitMatrix.get(i4 + (int)(f * i9), i8))
        continue;
      localBitMatrix.set(i9, i7);
    }
  }

  private static float moduleSize(int[] paramArrayOfInt, BitMatrix paramBitMatrix)
    throws NotFoundException
  {
    int i = paramBitMatrix.getHeight();
    int j = paramBitMatrix.getWidth();
    int k = paramArrayOfInt[0];
    int m = paramArrayOfInt[1];
    int n = 1;
    int i1 = 0;
    if ((k >= j) || (m >= i));
    while (true)
    {
      if ((k != j) && (m != i))
        break label99;
      throw NotFoundException.getNotFoundInstance();
      if (n == paramBitMatrix.get(k, m))
        break;
      i1++;
      if (i1 == 5)
        continue;
      if (n == 0)
        break label93;
    }
    label93: for (n = 0; ; n = 1)
    {
      k++;
      m++;
      break;
    }
    label99: return (k - paramArrayOfInt[0]) / 7.0F;
  }

  public Result decode(BinaryBitmap paramBinaryBitmap)
    throws NotFoundException, ChecksumException, FormatException
  {
    return decode(paramBinaryBitmap, null);
  }

  public final Result decode(BinaryBitmap paramBinaryBitmap, Map<DecodeHintType, ?> paramMap)
    throws NotFoundException, ChecksumException, FormatException
  {
    DecoderResult localDecoderResult;
    if ((paramMap != null) && (paramMap.containsKey(DecodeHintType.PURE_BARCODE)))
    {
      BitMatrix localBitMatrix = extractPureBits(paramBinaryBitmap.getBlackMatrix());
      localDecoderResult = this.decoder.decode(localBitMatrix, paramMap);
    }
    DetectorResult localDetectorResult;
    for (ResultPoint[] arrayOfResultPoint = NO_POINTS; ; arrayOfResultPoint = localDetectorResult.getPoints())
    {
      if ((localDecoderResult.getOther() instanceof QRCodeDecoderMetaData))
        ((QRCodeDecoderMetaData)localDecoderResult.getOther()).applyMirroredCorrection(arrayOfResultPoint);
      Result localResult = new Result(localDecoderResult.getText(), localDecoderResult.getRawBytes(), arrayOfResultPoint, BarcodeFormat.QR_CODE);
      List localList = localDecoderResult.getByteSegments();
      if (localList != null)
        localResult.putMetadata(ResultMetadataType.BYTE_SEGMENTS, localList);
      String str = localDecoderResult.getECLevel();
      if (str != null)
        localResult.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, str);
      if (localDecoderResult.hasStructuredAppend())
      {
        localResult.putMetadata(ResultMetadataType.STRUCTURED_APPEND_SEQUENCE, Integer.valueOf(localDecoderResult.getStructuredAppendSequenceNumber()));
        localResult.putMetadata(ResultMetadataType.STRUCTURED_APPEND_PARITY, Integer.valueOf(localDecoderResult.getStructuredAppendParity()));
      }
      return localResult;
      localDetectorResult = new Detector(paramBinaryBitmap.getBlackMatrix()).detect(paramMap);
      localDecoderResult = this.decoder.decode(localDetectorResult.getBits(), paramMap);
    }
  }

  protected final Decoder getDecoder()
  {
    return this.decoder;
  }

  public void reset()
  {
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.qrcode.QRCodeReader
 * JD-Core Version:    0.6.0
 */