package com.google.zxing.qrcode.decoder;

import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.reedsolomon.GenericGF;
import com.google.zxing.common.reedsolomon.ReedSolomonDecoder;
import com.google.zxing.common.reedsolomon.ReedSolomonException;
import java.util.Map;

public final class Decoder
{
  private final ReedSolomonDecoder rsDecoder = new ReedSolomonDecoder(GenericGF.QR_CODE_FIELD_256);

  private void correctErrors(byte[] paramArrayOfByte, int paramInt)
    throws ChecksumException
  {
    int i = paramArrayOfByte.length;
    int[] arrayOfInt = new int[i];
    int j = 0;
    int k;
    if (j >= i)
      k = paramArrayOfByte.length - paramInt;
    while (true)
    {
      int m;
      try
      {
        this.rsDecoder.decode(arrayOfInt, k);
        m = 0;
        if (m >= paramInt)
        {
          return;
          arrayOfInt[j] = (0xFF & paramArrayOfByte[j]);
          j++;
        }
      }
      catch (ReedSolomonException localReedSolomonException)
      {
        throw ChecksumException.getChecksumInstance();
      }
      paramArrayOfByte[m] = (byte)arrayOfInt[m];
      m++;
    }
  }

  private DecoderResult decode(BitMatrixParser paramBitMatrixParser, Map<DecodeHintType, ?> paramMap)
    throws FormatException, ChecksumException
  {
    Version localVersion = paramBitMatrixParser.readVersion();
    ErrorCorrectionLevel localErrorCorrectionLevel = paramBitMatrixParser.readFormatInformation().getErrorCorrectionLevel();
    DataBlock[] arrayOfDataBlock = DataBlock.getDataBlocks(paramBitMatrixParser.readCodewords(), localVersion, localErrorCorrectionLevel);
    int i = 0;
    int j = arrayOfDataBlock.length;
    byte[] arrayOfByte1;
    int m;
    int i1;
    for (int k = 0; ; k++)
    {
      if (k >= j)
      {
        arrayOfByte1 = new byte[i];
        m = 0;
        int n = arrayOfDataBlock.length;
        i1 = 0;
        if (i1 < n)
          break;
        return DecodedBitStreamParser.decode(arrayOfByte1, localVersion, localErrorCorrectionLevel, paramMap);
      }
      i += arrayOfDataBlock[k].getNumDataCodewords();
    }
    DataBlock localDataBlock = arrayOfDataBlock[i1];
    byte[] arrayOfByte2 = localDataBlock.getCodewords();
    int i2 = localDataBlock.getNumDataCodewords();
    correctErrors(arrayOfByte2, i2);
    int i3 = 0;
    int i5;
    for (int i4 = m; ; i4 = i5)
    {
      if (i3 >= i2)
      {
        i1++;
        m = i4;
        break;
      }
      i5 = i4 + 1;
      arrayOfByte1[i4] = arrayOfByte2[i3];
      i3++;
    }
  }

  public DecoderResult decode(BitMatrix paramBitMatrix)
    throws ChecksumException, FormatException
  {
    return decode(paramBitMatrix, null);
  }

  public DecoderResult decode(BitMatrix paramBitMatrix, Map<DecodeHintType, ?> paramMap)
    throws FormatException, ChecksumException
  {
    BitMatrixParser localBitMatrixParser = new BitMatrixParser(paramBitMatrix);
    Object localObject = null;
    try
    {
      DecoderResult localDecoderResult2 = decode(localBitMatrixParser, paramMap);
      return localDecoderResult2;
    }
    catch (FormatException localFormatException3)
    {
      localFormatException1 = localFormatException3;
      try
      {
        localBitMatrixParser.remask();
        localBitMatrixParser.setMirror(true);
        localBitMatrixParser.readVersion();
        localBitMatrixParser.readFormatInformation();
        localBitMatrixParser.mirror();
        DecoderResult localDecoderResult1 = decode(localBitMatrixParser, paramMap);
        localDecoderResult1.setOther(new QRCodeDecoderMetaData(true));
        return localDecoderResult1;
      }
      catch (FormatException localFormatException2)
      {
        if (localFormatException1 == null)
          break label98;
      }
      throw localFormatException1;
    }
    catch (ChecksumException localChecksumException)
    {
      while (true)
      {
        localObject = localChecksumException;
        FormatException localFormatException1 = null;
      }
      label98: if (localObject != null)
        throw localObject;
    }
    throw localFormatException2;
  }

  public DecoderResult decode(boolean[][] paramArrayOfBoolean)
    throws ChecksumException, FormatException
  {
    return decode(paramArrayOfBoolean, null);
  }

  public DecoderResult decode(boolean[][] paramArrayOfBoolean, Map<DecodeHintType, ?> paramMap)
    throws ChecksumException, FormatException
  {
    int i = paramArrayOfBoolean.length;
    BitMatrix localBitMatrix = new BitMatrix(i);
    int j = 0;
    if (j >= i)
      return decode(localBitMatrix, paramMap);
    for (int k = 0; ; k++)
    {
      if (k >= i)
      {
        j++;
        break;
      }
      if (paramArrayOfBoolean[j][k] == 0)
        continue;
      localBitMatrix.set(k, j);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.qrcode.decoder.Decoder
 * JD-Core Version:    0.6.0
 */