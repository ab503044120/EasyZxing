package com.google.zxing.qrcode.decoder;

final class DataBlock
{
  private final byte[] codewords;
  private final int numDataCodewords;

  private DataBlock(int paramInt, byte[] paramArrayOfByte)
  {
    this.numDataCodewords = paramInt;
    this.codewords = paramArrayOfByte;
  }

  static DataBlock[] getDataBlocks(byte[] paramArrayOfByte, Version paramVersion, ErrorCorrectionLevel paramErrorCorrectionLevel)
  {
    if (paramArrayOfByte.length != paramVersion.getTotalCodewords())
      throw new IllegalArgumentException();
    Version.ECBlocks localECBlocks = paramVersion.getECBlocksForLevel(paramErrorCorrectionLevel);
    int i = 0;
    Version.ECB[] arrayOfECB = localECBlocks.getECBlocks();
    int j = arrayOfECB.length;
    int k = 0;
    DataBlock[] arrayOfDataBlock;
    int m;
    int i1;
    int i6;
    int i7;
    label89: label94: int i8;
    int i9;
    int i10;
    int i11;
    int i15;
    int i16;
    label130: int i18;
    int i19;
    if (k >= j)
    {
      arrayOfDataBlock = new DataBlock[i];
      m = 0;
      int n = arrayOfECB.length;
      i1 = 0;
      if (i1 < n)
        break label184;
      i6 = arrayOfDataBlock[0].codewords.length;
      i7 = -1 + arrayOfDataBlock.length;
      if (i7 >= 0)
        break label264;
      i8 = i7 + 1;
      i9 = i6 - localECBlocks.getECCodewordsPerBlock();
      i10 = 0;
      i11 = 0;
      if (i11 < i9)
        break label284;
      i15 = i8;
      i16 = i10;
      if (i15 < m)
        break label343;
      i18 = arrayOfDataBlock[0].codewords.length;
      i19 = i9;
    }
    label184: label343: int i21;
    label264: label284: int i22;
    for (int i20 = i16; ; i20 = i22)
    {
      if (i19 >= i18)
      {
        return arrayOfDataBlock;
        i += arrayOfECB[k].getCount();
        k++;
        break;
        Version.ECB localECB = arrayOfECB[i1];
        int i2 = 0;
        while (true)
        {
          if (i2 >= localECB.getCount())
          {
            i1++;
            break;
          }
          int i3 = localECB.getDataCodewords();
          int i4 = i3 + localECBlocks.getECCodewordsPerBlock();
          int i5 = m + 1;
          DataBlock localDataBlock = new DataBlock(i3, new byte[i4]);
          arrayOfDataBlock[m] = localDataBlock;
          i2++;
          m = i5;
        }
        if (arrayOfDataBlock[i7].codewords.length == i6)
          break label94;
        i7--;
        break label89;
        int i12 = 0;
        int i14;
        for (int i13 = i10; ; i13 = i14)
        {
          if (i12 >= m)
          {
            i11++;
            i10 = i13;
            break;
          }
          byte[] arrayOfByte1 = arrayOfDataBlock[i12].codewords;
          i14 = i13 + 1;
          arrayOfByte1[i11] = paramArrayOfByte[i13];
          i12++;
        }
        byte[] arrayOfByte2 = arrayOfDataBlock[i15].codewords;
        int i17 = i16 + 1;
        arrayOfByte2[i9] = paramArrayOfByte[i16];
        i15++;
        i16 = i17;
        break label130;
      }
      i21 = 0;
      i22 = i20;
      if (i21 < m)
        break label402;
      i19++;
    }
    label402: if (i21 < i8);
    for (int i23 = i19; ; i23 = i19 + 1)
    {
      byte[] arrayOfByte3 = arrayOfDataBlock[i21].codewords;
      int i24 = i22 + 1;
      arrayOfByte3[i23] = paramArrayOfByte[i22];
      i21++;
      i22 = i24;
      break;
    }
  }

  byte[] getCodewords()
  {
    return this.codewords;
  }

  int getNumDataCodewords()
  {
    return this.numDataCodewords;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.qrcode.decoder.DataBlock
 * JD-Core Version:    0.6.0
 */