package com.google.zxing.qrcode.decoder;

import com.google.zxing.DecodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.common.BitSource;
import com.google.zxing.common.CharacterSetECI;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.StringUtils;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

final class DecodedBitStreamParser
{
  private static final char[] ALPHANUMERIC_CHARS = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 32, 36, 37, 42, 43, 45, 46, 47, 58 };
  private static final int GB2312_SUBSET = 1;

  static DecoderResult decode(byte[] paramArrayOfByte, Version paramVersion, ErrorCorrectionLevel paramErrorCorrectionLevel, Map<DecodeHintType, ?> paramMap)
    throws FormatException
  {
    BitSource localBitSource = new BitSource(paramArrayOfByte);
    StringBuilder localStringBuilder = new StringBuilder(50);
    ArrayList localArrayList = new ArrayList(1);
    int i = -1;
    int j = -1;
    CharacterSetECI localCharacterSetECI = null;
    boolean bool = false;
    while (true)
    {
      Mode localMode1;
      try
      {
        if (localBitSource.available() >= 4)
          continue;
        localMode1 = Mode.TERMINATOR;
        Mode localMode2 = Mode.TERMINATOR;
        if (localMode1 == localMode2)
          continue;
        Mode localMode3 = Mode.FNC1_FIRST_POSITION;
        if (localMode1 == localMode3)
          break label439;
        Mode localMode4 = Mode.FNC1_SECOND_POSITION;
        if (localMode1 != localMode4)
          continue;
        break label439;
        Mode localMode5 = Mode.TERMINATOR;
        if (localMode1 != localMode5)
          continue;
        String str1 = localStringBuilder.toString();
        if (!localArrayList.isEmpty())
          break label423;
        localObject = null;
        if (paramErrorCorrectionLevel != null)
          break label430;
        str2 = null;
        return new DecoderResult(paramArrayOfByte, str1, (List)localObject, str2, i, j);
        localMode1 = Mode.forBits(localBitSource.readBits(4));
        continue;
        Mode localMode6 = Mode.STRUCTURED_APPEND;
        if (localMode1 != localMode6)
          break label221;
        if (localBitSource.available() < 16)
          throw FormatException.getFormatInstance();
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        throw FormatException.getFormatInstance();
      }
      i = localBitSource.readBits(8);
      j = localBitSource.readBits(8);
      continue;
      label221: Mode localMode7 = Mode.ECI;
      if (localMode1 == localMode7)
      {
        localCharacterSetECI = CharacterSetECI.getCharacterSetECIByValue(parseECIValue(localBitSource));
        if (localCharacterSetECI != null)
          continue;
        throw FormatException.getFormatInstance();
      }
      Mode localMode8 = Mode.HANZI;
      if (localMode1 == localMode8)
      {
        int k = localBitSource.readBits(4);
        int m = localBitSource.readBits(localMode1.getCharacterCountBits(paramVersion));
        if (k != 1)
          continue;
        decodeHanziSegment(localBitSource, localStringBuilder, m);
        continue;
      }
      int n = localBitSource.readBits(localMode1.getCharacterCountBits(paramVersion));
      Mode localMode9 = Mode.NUMERIC;
      if (localMode1 == localMode9)
      {
        decodeNumericSegment(localBitSource, localStringBuilder, n);
        continue;
      }
      Mode localMode10 = Mode.ALPHANUMERIC;
      if (localMode1 == localMode10)
      {
        decodeAlphanumericSegment(localBitSource, localStringBuilder, n, bool);
        continue;
      }
      Mode localMode11 = Mode.BYTE;
      if (localMode1 == localMode11)
      {
        decodeByteSegment(localBitSource, localStringBuilder, n, localCharacterSetECI, localArrayList, paramMap);
        continue;
      }
      Mode localMode12 = Mode.KANJI;
      if (localMode1 == localMode12)
      {
        decodeKanjiSegment(localBitSource, localStringBuilder, n);
        continue;
      }
      throw FormatException.getFormatInstance();
      label423: Object localObject = localArrayList;
      continue;
      label430: String str2 = paramErrorCorrectionLevel.toString();
      continue;
      label439: bool = true;
    }
  }

  private static void decodeAlphanumericSegment(BitSource paramBitSource, StringBuilder paramStringBuilder, int paramInt, boolean paramBoolean)
    throws FormatException
  {
    int i = paramStringBuilder.length();
    while (true)
    {
      if (paramInt <= 1)
      {
        if (paramInt != 1)
          break;
        if (paramBitSource.available() < 6)
          throw FormatException.getFormatInstance();
      }
      else
      {
        if (paramBitSource.available() < 11)
          throw FormatException.getFormatInstance();
        int j = paramBitSource.readBits(11);
        paramStringBuilder.append(toAlphaNumericChar(j / 45));
        paramStringBuilder.append(toAlphaNumericChar(j % 45));
        paramInt -= 2;
        continue;
      }
      paramStringBuilder.append(toAlphaNumericChar(paramBitSource.readBits(6)));
    }
    int k;
    if (paramBoolean)
    {
      k = i;
      if (k < paramStringBuilder.length());
    }
    else
    {
      return;
    }
    if (paramStringBuilder.charAt(k) == '%')
    {
      if ((k >= -1 + paramStringBuilder.length()) || (paramStringBuilder.charAt(k + 1) != '%'))
        break label164;
      paramStringBuilder.deleteCharAt(k + 1);
    }
    while (true)
    {
      k++;
      break;
      label164: paramStringBuilder.setCharAt(k, '\035');
    }
  }

  private static void decodeByteSegment(BitSource paramBitSource, StringBuilder paramStringBuilder, int paramInt, CharacterSetECI paramCharacterSetECI, Collection<byte[]> paramCollection, Map<DecodeHintType, ?> paramMap)
    throws FormatException
  {
    if (paramInt * 8 > paramBitSource.available())
      throw FormatException.getFormatInstance();
    byte[] arrayOfByte = new byte[paramInt];
    int i = 0;
    while (true)
    {
      String str;
      if (i >= paramInt)
      {
        if (paramCharacterSetECI != null)
          break label87;
        str = StringUtils.guessEncoding(arrayOfByte, paramMap);
      }
      try
      {
        while (true)
        {
          paramStringBuilder.append(new String(arrayOfByte, str));
          paramCollection.add(arrayOfByte);
          return;
          arrayOfByte[i] = (byte)paramBitSource.readBits(8);
          i++;
          break;
          label87: str = paramCharacterSetECI.name();
        }
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
      }
    }
    throw FormatException.getFormatInstance();
  }

  private static void decodeHanziSegment(BitSource paramBitSource, StringBuilder paramStringBuilder, int paramInt)
    throws FormatException
  {
    if (paramInt * 13 > paramBitSource.available())
      throw FormatException.getFormatInstance();
    byte[] arrayOfByte = new byte[paramInt * 2];
    int i = 0;
    while (true)
    {
      if (paramInt <= 0);
      try
      {
        paramStringBuilder.append(new String(arrayOfByte, "GB2312"));
        return;
        int j = paramBitSource.readBits(13);
        int k = j / 96 << 8 | j % 96;
        if (k < 959);
        for (int m = k + 41377; ; m = k + 42657)
        {
          arrayOfByte[i] = (byte)(0xFF & m >> 8);
          arrayOfByte[(i + 1)] = (byte)(m & 0xFF);
          i += 2;
          paramInt--;
          break;
        }
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
      }
    }
    throw FormatException.getFormatInstance();
  }

  private static void decodeKanjiSegment(BitSource paramBitSource, StringBuilder paramStringBuilder, int paramInt)
    throws FormatException
  {
    if (paramInt * 13 > paramBitSource.available())
      throw FormatException.getFormatInstance();
    byte[] arrayOfByte = new byte[paramInt * 2];
    int i = 0;
    while (true)
    {
      if (paramInt <= 0);
      try
      {
        paramStringBuilder.append(new String(arrayOfByte, "SJIS"));
        return;
        int j = paramBitSource.readBits(13);
        int k = j / 192 << 8 | j % 192;
        if (k < 7936);
        for (int m = k + 33088; ; m = k + 49472)
        {
          arrayOfByte[i] = (byte)(m >> 8);
          arrayOfByte[(i + 1)] = (byte)m;
          i += 2;
          paramInt--;
          break;
        }
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
      }
    }
    throw FormatException.getFormatInstance();
  }

  private static void decodeNumericSegment(BitSource paramBitSource, StringBuilder paramStringBuilder, int paramInt)
    throws FormatException
  {
    while (true)
    {
      if (paramInt < 3)
      {
        if (paramInt != 2)
          break;
        if (paramBitSource.available() < 7)
          throw FormatException.getFormatInstance();
      }
      else
      {
        if (paramBitSource.available() < 10)
          throw FormatException.getFormatInstance();
        int i = paramBitSource.readBits(10);
        if (i >= 1000)
          throw FormatException.getFormatInstance();
        paramStringBuilder.append(toAlphaNumericChar(i / 100));
        paramStringBuilder.append(toAlphaNumericChar(i / 10 % 10));
        paramStringBuilder.append(toAlphaNumericChar(i % 10));
        paramInt -= 3;
        continue;
      }
      int k = paramBitSource.readBits(7);
      if (k >= 100)
        throw FormatException.getFormatInstance();
      paramStringBuilder.append(toAlphaNumericChar(k / 10));
      paramStringBuilder.append(toAlphaNumericChar(k % 10));
    }
    do
      return;
    while (paramInt != 1);
    if (paramBitSource.available() < 4)
      throw FormatException.getFormatInstance();
    int j = paramBitSource.readBits(4);
    if (j >= 10)
      throw FormatException.getFormatInstance();
    paramStringBuilder.append(toAlphaNumericChar(j));
  }

  private static int parseECIValue(BitSource paramBitSource)
    throws FormatException
  {
    int i = paramBitSource.readBits(8);
    if ((i & 0x80) == 0)
      return i & 0x7F;
    if ((i & 0xC0) == 128)
      return paramBitSource.readBits(8) | (i & 0x3F) << 8;
    if ((i & 0xE0) == 192)
      return paramBitSource.readBits(16) | (i & 0x1F) << 16;
    throw FormatException.getFormatInstance();
  }

  private static char toAlphaNumericChar(int paramInt)
    throws FormatException
  {
    if (paramInt >= ALPHANUMERIC_CHARS.length)
      throw FormatException.getFormatInstance();
    return ALPHANUMERIC_CHARS[paramInt];
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.qrcode.decoder.DecodedBitStreamParser
 * JD-Core Version:    0.6.0
 */