package com.google.zxing;

public final class WriterException extends Exception
{
  public WriterException()
  {
  }

  public WriterException(String paramString)
  {
    super(paramString);
  }

  public WriterException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.WriterException
 * JD-Core Version:    0.6.0
 */