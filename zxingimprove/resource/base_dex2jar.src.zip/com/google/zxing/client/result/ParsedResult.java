package com.google.zxing.client.result;

import java.io.Serializable;

public abstract class ParsedResult
  implements Serializable
{
  private static final long serialVersionUID = 86511096872631386L;
  private final ParsedResultType type;

  protected ParsedResult(ParsedResultType paramParsedResultType)
  {
    this.type = paramParsedResultType;
  }

  public static void maybeAppend(String paramString, StringBuilder paramStringBuilder)
  {
    if ((paramString != null) && (!paramString.isEmpty()))
    {
      if (paramStringBuilder.length() > 0)
        paramStringBuilder.append('\n');
      paramStringBuilder.append(paramString);
    }
  }

  public static void maybeAppend(String[] paramArrayOfString, StringBuilder paramStringBuilder)
  {
    int i;
    if (paramArrayOfString != null)
      i = paramArrayOfString.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return;
      maybeAppend(paramArrayOfString[j], paramStringBuilder);
    }
  }

  public abstract String getDisplayResult();

  public final ParsedResultType getType()
  {
    return this.type;
  }

  public final String toString()
  {
    return getDisplayResult();
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.result.ParsedResult
 * JD-Core Version:    0.6.0
 */