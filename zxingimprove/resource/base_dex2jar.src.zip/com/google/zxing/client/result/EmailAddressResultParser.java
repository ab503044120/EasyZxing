package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.Map;
import java.util.regex.Pattern;

public final class EmailAddressResultParser extends ResultParser
{
  private static final Pattern COMMA = Pattern.compile(",");

  public EmailAddressParsedResult parse(Result paramResult)
  {
    String str1 = getMassagedText(paramResult);
    if ((str1.startsWith("mailto:")) || (str1.startsWith("MAILTO:")))
    {
      String str2 = str1.substring(7);
      int i = str2.indexOf('?');
      if (i >= 0)
        str2 = str2.substring(0, i);
      String str3 = urlDecode(str2);
      boolean bool = str3.isEmpty();
      String[] arrayOfString1 = null;
      if (!bool)
        arrayOfString1 = COMMA.split(str3);
      Map localMap = parseNameValuePairs(str1);
      String[] arrayOfString2 = null;
      String[] arrayOfString3 = null;
      String str4 = null;
      String str5 = null;
      if (localMap != null)
      {
        if (arrayOfString1 == null)
        {
          String str8 = (String)localMap.get("to");
          if (str8 != null)
            arrayOfString1 = COMMA.split(str8);
        }
        String str6 = (String)localMap.get("cc");
        arrayOfString2 = null;
        if (str6 != null)
          arrayOfString2 = COMMA.split(str6);
        String str7 = (String)localMap.get("bcc");
        arrayOfString3 = null;
        if (str7 != null)
          arrayOfString3 = COMMA.split(str7);
        str4 = (String)localMap.get("subject");
        str5 = (String)localMap.get("body");
      }
      return new EmailAddressParsedResult(arrayOfString1, arrayOfString2, arrayOfString3, str4, str5);
    }
    if (!EmailDoCoMoResultParser.isBasicallyValidEmailAddress(str1))
      return null;
    return new EmailAddressParsedResult(str1);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.result.EmailAddressResultParser
 * JD-Core Version:    0.6.0
 */