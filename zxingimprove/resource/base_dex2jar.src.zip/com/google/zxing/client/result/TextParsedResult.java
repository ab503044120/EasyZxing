package com.google.zxing.client.result;

import java.io.Serializable;

public final class TextParsedResult extends ParsedResult
  implements Serializable
{
  private static final long serialVersionUID = 970901617618378757L;
  private final String language;
  private final String text;

  public TextParsedResult(String paramString1, String paramString2)
  {
    super(ParsedResultType.TEXT);
    this.text = paramString1;
    this.language = paramString2;
  }

  public String getDisplayResult()
  {
    return this.text;
  }

  public String getLanguage()
  {
    return this.language;
  }

  public String getText()
  {
    return this.text;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.result.TextParsedResult
 * JD-Core Version:    0.6.0
 */