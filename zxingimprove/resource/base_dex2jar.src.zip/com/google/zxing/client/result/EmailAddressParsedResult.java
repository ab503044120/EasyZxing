package com.google.zxing.client.result;

import java.io.Serializable;

public final class EmailAddressParsedResult extends ParsedResult
  implements Serializable
{
  private static final long serialVersionUID = 8253004672361895655L;
  private final String[] bccs;
  private final String body;
  private final String[] ccs;
  private final String subject;
  private final String[] tos;

  EmailAddressParsedResult(String paramString)
  {
    this(new String[] { paramString }, null, null, null, null);
  }

  EmailAddressParsedResult(String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, String paramString1, String paramString2)
  {
    super(ParsedResultType.EMAIL_ADDRESS);
    this.tos = paramArrayOfString1;
    this.ccs = paramArrayOfString2;
    this.bccs = paramArrayOfString3;
    this.subject = paramString1;
    this.body = paramString2;
  }

  public String[] getBCCs()
  {
    return this.bccs;
  }

  public String getBody()
  {
    return this.body;
  }

  public String[] getCCs()
  {
    return this.ccs;
  }

  public String getDisplayResult()
  {
    StringBuilder localStringBuilder = new StringBuilder(30);
    maybeAppend(this.tos, localStringBuilder);
    maybeAppend(this.ccs, localStringBuilder);
    maybeAppend(this.bccs, localStringBuilder);
    maybeAppend(this.subject, localStringBuilder);
    maybeAppend(this.body, localStringBuilder);
    return localStringBuilder.toString();
  }

  @Deprecated
  public String getEmailAddress()
  {
    if ((this.tos == null) || (this.tos.length == 0))
      return null;
    return this.tos[0];
  }

  @Deprecated
  public String getMailtoURI()
  {
    return "mailto:";
  }

  public String getSubject()
  {
    return this.subject;
  }

  public String[] getTos()
  {
    return this.tos;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.result.EmailAddressParsedResult
 * JD-Core Version:    0.6.0
 */