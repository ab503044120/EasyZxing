package com.google.zxing.client.android;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.client.android.camera.CameraManager;
import java.util.Vector;
import mobi.thinkchange.android.superqrcode.data.HistorySource;
import mobi.thinkchange.android.superqrcode.fragment.scanfragmentstack.ScanFragmentChild01Scan;

public final class CaptureActivityHandler extends Handler
{
  private static final String TAG = CaptureActivityHandler.class.getSimpleName();
  private final ScanFragmentChild01Scan activity;
  private final DecodeThread decodeThread;
  private State state;

  public CaptureActivityHandler(ScanFragmentChild01Scan paramScanFragmentChild01Scan, Vector<BarcodeFormat> paramVector, String paramString)
  {
    this.activity = paramScanFragmentChild01Scan;
    this.decodeThread = new DecodeThread(paramScanFragmentChild01Scan, paramVector, paramString, new ViewfinderResultPointCallback(paramScanFragmentChild01Scan.getViewfinderView()));
    this.decodeThread.start();
    this.state = State.SUCCESS;
    CameraManager.get().startPreview();
    restartPreviewAndDecode();
  }

  private void restartPreviewAndDecode()
  {
    if (this.state == State.SUCCESS)
    {
      this.state = State.PREVIEW;
      CameraManager.get().requestPreviewFrame(this.decodeThread.getHandler(), 2131623937);
      CameraManager.get().requestAutoFocus(this, 2131623936);
      this.activity.drawViewfinder();
    }
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    case 2131623937:
    case 2131623941:
    default:
    case 2131623936:
      do
        return;
      while (this.state != State.PREVIEW);
      CameraManager.get().requestAutoFocus(this, 2131623936);
      return;
    case 2131623942:
      Log.d(TAG, "Got restart preview message");
      restartPreviewAndDecode();
      return;
    case 2131623939:
      Log.d(TAG, "Got decode succeeded message");
      this.state = State.SUCCESS;
      Bundle localBundle = paramMessage.getData();
      if (localBundle == null);
      for (Bitmap localBitmap = null; ; localBitmap = (Bitmap)localBundle.getParcelable("barcode_bitmap"))
      {
        this.activity.handleDecode((Result)paramMessage.obj, localBitmap, HistorySource.SCAN_FROM_CAMERA);
        return;
      }
    case 2131623938:
      this.state = State.PREVIEW;
      CameraManager.get().requestPreviewFrame(this.decodeThread.getHandler(), 2131623937);
      return;
    case 2131623943:
      Log.d(TAG, "Got return scan result message");
      this.activity.getActivity().setResult(-1, (Intent)paramMessage.obj);
      this.activity.getActivity().finish();
      return;
    case 2131623940:
    }
    Log.d(TAG, "Got product query message");
    Intent localIntent = new Intent("android.intent.action.VIEW", Uri.parse((String)paramMessage.obj));
    localIntent.addFlags(524288);
    this.activity.startActivity(localIntent);
  }

  public void quitSynchronously()
  {
    this.state = State.DONE;
    CameraManager.get().stopPreview();
    Message.obtain(this.decodeThread.getHandler(), 2131623941).sendToTarget();
    try
    {
      this.decodeThread.join();
      label35: removeMessages(2131623939);
      removeMessages(2131623938);
      return;
    }
    catch (InterruptedException localInterruptedException)
    {
      break label35;
    }
  }

  private static enum State
  {
    static
    {
      DONE = new State("DONE", 2);
      State[] arrayOfState = new State[3];
      arrayOfState[0] = PREVIEW;
      arrayOfState[1] = SUCCESS;
      arrayOfState[2] = DONE;
      ENUM$VALUES = arrayOfState;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.android.CaptureActivityHandler
 * JD-Core Version:    0.6.0
 */