package com.google.zxing.client.android.camera;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.os.Build.VERSION;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.SurfaceHolder;
import com.google.zxing.client.android.PlanarYUVLuminanceSource;
import java.io.IOException;

public final class CameraManager
{
  private static int MAX_FRAME_HEIGHT;
  private static int MAX_FRAME_WIDTH;
  private static int MIN_FRAME_HEIGHT;
  private static int MIN_FRAME_WIDTH;
  static final int SDK_INT;
  private static final String TAG = CameraManager.class.getSimpleName();
  public static Camera camera;
  private static CameraManager cameraManager;
  public static int screenHeight;
  private static int screenWidth;
  private final AutoFocusCallback autoFocusCallback;
  private final CameraConfigurationManager configManager;
  private final Context context;
  private Rect framingRect;
  private Rect framingRectInPreview;
  private boolean initialized;
  private final PreviewCallback previewCallback;
  private boolean previewing;
  private final boolean useOneShotPreviewCallback;

  static
  {
    MIN_FRAME_WIDTH = 240;
    MIN_FRAME_HEIGHT = 240;
    MAX_FRAME_WIDTH = 480;
    MAX_FRAME_HEIGHT = 360;
    try
    {
      int j = Integer.parseInt(Build.VERSION.SDK);
      i = j;
      SDK_INT = i;
      return;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      while (true)
        int i = 10000;
    }
  }

  private CameraManager(Context paramContext)
  {
    this.context = paramContext;
    this.configManager = new CameraConfigurationManager(paramContext);
    if (Integer.parseInt(Build.VERSION.SDK) > 3);
    for (boolean bool = true; ; bool = false)
    {
      this.useOneShotPreviewCallback = bool;
      this.previewCallback = new PreviewCallback(this.configManager, this.useOneShotPreviewCallback);
      this.autoFocusCallback = new AutoFocusCallback();
      return;
    }
  }

  public static void closeLight()
  {
    if (camera != null)
    {
      Camera.Parameters localParameters = camera.getParameters();
      localParameters.setFlashMode("off");
      camera.setParameters(localParameters);
    }
  }

  private static int findDesiredDimensionInRange(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = paramInt1 * 5 / 7;
    if (i < paramInt2)
      return paramInt2;
    if (i > paramInt3)
      return paramInt3;
    return i;
  }

  public static CameraManager get()
  {
    return cameraManager;
  }

  public static void init(Context paramContext, int paramInt1, int paramInt2)
  {
    screenWidth = paramInt1;
    screenHeight = paramInt2;
    if (cameraManager == null)
      cameraManager = new CameraManager(paramContext);
  }

  public static void openLight()
  {
    if (camera != null);
    try
    {
      Camera.Parameters localParameters = camera.getParameters();
      localParameters.setFlashMode("torch");
      camera.setParameters(localParameters);
      camera.startPreview();
      return;
    }
    catch (Exception localException)
    {
      Log.e("Exception", localException.toString());
    }
  }

  public static void setZoom(int paramInt)
  {
    if (camera != null)
    {
      Camera.Parameters localParameters = camera.getParameters();
      localParameters.setZoom(paramInt);
      camera.setParameters(localParameters);
    }
  }

  public PlanarYUVLuminanceSource buildLuminanceSource(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    Rect localRect = getFramingRectInPreview();
    int i = this.configManager.getPreviewFormat();
    String str = this.configManager.getPreviewFormatString();
    switch (i)
    {
    default:
      if (!"yuv420p".equals(str))
        break;
      return new PlanarYUVLuminanceSource(paramArrayOfByte, paramInt1, paramInt2, localRect.left, localRect.top, localRect.width(), localRect.height());
    case 16:
    case 17:
      return new PlanarYUVLuminanceSource(paramArrayOfByte, paramInt1, paramInt2, localRect.left, localRect.top, localRect.width(), localRect.height());
    }
    throw new IllegalArgumentException("Unsupported picture format: " + i + '/' + str);
  }

  public void closeDriver()
  {
    if (camera != null)
    {
      FlashlightManager.disableFlashlight();
      camera.release();
      camera = null;
    }
  }

  public Rect getFramingRect()
  {
    monitorenter;
    try
    {
      MIN_FRAME_WIDTH = (int)(0.5D * screenWidth);
      MIN_FRAME_HEIGHT = (int)(0.281D * screenHeight);
      MAX_FRAME_WIDTH = screenWidth;
      MAX_FRAME_HEIGHT = (int)(0.421D * screenHeight);
      Point localPoint = this.configManager.getScreenResolution();
      Rect localRect;
      int i;
      label98: int j;
      if (this.framingRect == null)
      {
        Camera localCamera = camera;
        if (localCamera == null)
        {
          localRect = null;
          return localRect;
        }
        i = 3 * localPoint.x / 4;
        if (i >= MIN_FRAME_WIDTH)
          break label219;
        i = MIN_FRAME_WIDTH;
        j = 3 * localPoint.y / 4;
        if (j >= MIN_FRAME_HEIGHT)
          break label235;
        j = MIN_FRAME_HEIGHT;
      }
      while (true)
      {
        int k = (localPoint.x - i) / 2;
        int m = (localPoint.y - j) / 2;
        int n = j * 100 / 800;
        this.framingRect = new Rect(k, m - n, k + i, m + j - n);
        Log.d(TAG, "Calculated framing rect: " + this.framingRect);
        localRect = this.framingRect;
        break;
        label219: if (i <= MAX_FRAME_WIDTH)
          break label98;
        i = MAX_FRAME_WIDTH;
        break label98;
        label235: if (j <= MAX_FRAME_HEIGHT)
          continue;
        j = MAX_FRAME_HEIGHT;
      }
    }
    finally
    {
      monitorexit;
    }
    throw localObject;
  }

  public Rect getFramingRectInPreview()
  {
    if (this.framingRectInPreview == null)
    {
      Rect localRect = new Rect(getFramingRect());
      Point localPoint1 = this.configManager.getCameraResolution();
      Point localPoint2 = this.configManager.getScreenResolution();
      localRect.left = (localRect.left * localPoint1.y / localPoint2.x);
      localRect.right = (localRect.right * localPoint1.y / localPoint2.x);
      localRect.top = (localRect.top * localPoint1.x / localPoint2.y);
      localRect.bottom = (localRect.bottom * localPoint1.x / localPoint2.y);
      this.framingRectInPreview = localRect;
    }
    return this.framingRectInPreview;
  }

  public void openDriver(SurfaceHolder paramSurfaceHolder)
    throws IOException
  {
    if (camera == null)
    {
      camera = Camera.open();
      if (camera == null)
        throw new IOException();
      camera.setPreviewDisplay(paramSurfaceHolder);
      if (!this.initialized)
      {
        this.initialized = true;
        this.configManager.initFromCameraParameters(camera);
      }
      this.configManager.setDesiredCameraParameters(camera);
      PreferenceManager.getDefaultSharedPreferences(this.context);
    }
  }

  public void requestAutoFocus(Handler paramHandler, int paramInt)
  {
    if ((camera != null) && (this.previewing))
    {
      this.autoFocusCallback.setHandler(paramHandler, paramInt);
      camera.autoFocus(this.autoFocusCallback);
    }
  }

  public void requestPreviewFrame(Handler paramHandler, int paramInt)
  {
    if ((camera != null) && (this.previewing))
    {
      this.previewCallback.setHandler(paramHandler, paramInt);
      if (this.useOneShotPreviewCallback)
        camera.setOneShotPreviewCallback(this.previewCallback);
    }
    else
    {
      return;
    }
    camera.setPreviewCallback(this.previewCallback);
  }

  public void startPreview()
  {
    if ((camera != null) && (!this.previewing))
    {
      camera.startPreview();
      this.previewing = true;
    }
  }

  public void stopPreview()
  {
    if ((camera != null) && (this.previewing))
    {
      if (!this.useOneShotPreviewCallback)
        camera.setPreviewCallback(null);
      camera.stopPreview();
      this.previewCallback.setHandler(null, 0);
      this.autoFocusCallback.setHandler(null, 0);
      this.previewing = false;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.android.camera.CameraManager
 * JD-Core Version:    0.6.0
 */