package com.google.zxing.client.android;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import java.util.Hashtable;
import mobi.thinkchange.android.superqrcode.fragment.scanfragmentstack.ScanFragmentChild01Scan;

final class DecodeHandler extends Handler
{
  private static final String TAG = DecodeHandler.class.getSimpleName();
  private final ScanFragmentChild01Scan activity;
  private final MultiFormatReader multiFormatReader = new MultiFormatReader();

  DecodeHandler(ScanFragmentChild01Scan paramScanFragmentChild01Scan, Hashtable<DecodeHintType, Object> paramHashtable)
  {
    this.multiFormatReader.setHints(paramHashtable);
    this.activity = paramScanFragmentChild01Scan;
  }

  // ERROR //
  private void decode(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    // Byte code:
    //   0: aload_1
    //   1: arraylength
    //   2: newarray byte
    //   4: astore 4
    //   6: iconst_0
    //   7: istore 5
    //   9: iload 5
    //   11: iload_3
    //   12: if_icmplt +160 -> 172
    //   15: invokestatic 45	java/lang/System:currentTimeMillis	()J
    //   18: lstore 7
    //   20: invokestatic 51	com/google/zxing/client/android/camera/CameraManager:get	()Lcom/google/zxing/client/android/camera/CameraManager;
    //   23: aload 4
    //   25: iload_3
    //   26: iload_2
    //   27: invokevirtual 55	com/google/zxing/client/android/camera/CameraManager:buildLuminanceSource	([BII)Lcom/google/zxing/client/android/PlanarYUVLuminanceSource;
    //   30: astore 9
    //   32: new 57	com/google/zxing/BinaryBitmap
    //   35: dup
    //   36: new 59	com/google/zxing/common/HybridBinarizer
    //   39: dup
    //   40: aload 9
    //   42: invokespecial 62	com/google/zxing/common/HybridBinarizer:<init>	(Lcom/google/zxing/LuminanceSource;)V
    //   45: invokespecial 65	com/google/zxing/BinaryBitmap:<init>	(Lcom/google/zxing/Binarizer;)V
    //   48: astore 10
    //   50: aload_0
    //   51: getfield 29	com/google/zxing/client/android/DecodeHandler:multiFormatReader	Lcom/google/zxing/MultiFormatReader;
    //   54: aload 10
    //   56: invokevirtual 69	com/google/zxing/MultiFormatReader:decodeWithState	(Lcom/google/zxing/BinaryBitmap;)Lcom/google/zxing/Result;
    //   59: astore 19
    //   61: aload 19
    //   63: astore 13
    //   65: aload_0
    //   66: getfield 29	com/google/zxing/client/android/DecodeHandler:multiFormatReader	Lcom/google/zxing/MultiFormatReader;
    //   69: invokevirtual 72	com/google/zxing/MultiFormatReader:reset	()V
    //   72: aload 13
    //   74: ifnull +169 -> 243
    //   77: invokestatic 45	java/lang/System:currentTimeMillis	()J
    //   80: lstore 14
    //   82: getstatic 20	com/google/zxing/client/android/DecodeHandler:TAG	Ljava/lang/String;
    //   85: new 74	java/lang/StringBuilder
    //   88: dup
    //   89: ldc 76
    //   91: invokespecial 79	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   94: lload 14
    //   96: lload 7
    //   98: lsub
    //   99: invokevirtual 83	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   102: ldc 85
    //   104: invokevirtual 88	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   107: aload 13
    //   109: invokevirtual 93	com/google/zxing/Result:toString	()Ljava/lang/String;
    //   112: invokevirtual 88	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: invokevirtual 94	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   118: invokestatic 100	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   121: pop
    //   122: aload_0
    //   123: getfield 35	com/google/zxing/client/android/DecodeHandler:activity	Lmobi/thinkchange/android/superqrcode/fragment/scanfragmentstack/ScanFragmentChild01Scan;
    //   126: invokevirtual 106	mobi/thinkchange/android/superqrcode/fragment/scanfragmentstack/ScanFragmentChild01Scan:getHandler	()Landroid/os/Handler;
    //   129: ldc 107
    //   131: aload 13
    //   133: invokestatic 113	android/os/Message:obtain	(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;
    //   136: astore 17
    //   138: new 115	android/os/Bundle
    //   141: dup
    //   142: invokespecial 116	android/os/Bundle:<init>	()V
    //   145: astore 18
    //   147: aload 18
    //   149: ldc 118
    //   151: aload 9
    //   153: invokevirtual 124	com/google/zxing/client/android/PlanarYUVLuminanceSource:renderCroppedGreyscaleBitmap	()Landroid/graphics/Bitmap;
    //   156: invokevirtual 128	android/os/Bundle:putParcelable	(Ljava/lang/String;Landroid/os/Parcelable;)V
    //   159: aload 17
    //   161: aload 18
    //   163: invokevirtual 132	android/os/Message:setData	(Landroid/os/Bundle;)V
    //   166: aload 17
    //   168: invokevirtual 135	android/os/Message:sendToTarget	()V
    //   171: return
    //   172: iconst_0
    //   173: istore 6
    //   175: iload 6
    //   177: iload_2
    //   178: if_icmplt +9 -> 187
    //   181: iinc 5 1
    //   184: goto -175 -> 9
    //   187: aload 4
    //   189: iconst_m1
    //   190: iload_3
    //   191: iload 6
    //   193: iload_3
    //   194: imul
    //   195: iadd
    //   196: iload 5
    //   198: isub
    //   199: iadd
    //   200: aload_1
    //   201: iload 6
    //   203: iload 5
    //   205: iload_2
    //   206: imul
    //   207: iadd
    //   208: baload
    //   209: bastore
    //   210: iinc 6 1
    //   213: goto -38 -> 175
    //   216: astore 12
    //   218: aload_0
    //   219: getfield 29	com/google/zxing/client/android/DecodeHandler:multiFormatReader	Lcom/google/zxing/MultiFormatReader;
    //   222: invokevirtual 72	com/google/zxing/MultiFormatReader:reset	()V
    //   225: aconst_null
    //   226: astore 13
    //   228: goto -156 -> 72
    //   231: astore 11
    //   233: aload_0
    //   234: getfield 29	com/google/zxing/client/android/DecodeHandler:multiFormatReader	Lcom/google/zxing/MultiFormatReader;
    //   237: invokevirtual 72	com/google/zxing/MultiFormatReader:reset	()V
    //   240: aload 11
    //   242: athrow
    //   243: aload_0
    //   244: getfield 35	com/google/zxing/client/android/DecodeHandler:activity	Lmobi/thinkchange/android/superqrcode/fragment/scanfragmentstack/ScanFragmentChild01Scan;
    //   247: invokevirtual 106	mobi/thinkchange/android/superqrcode/fragment/scanfragmentstack/ScanFragmentChild01Scan:getHandler	()Landroid/os/Handler;
    //   250: ldc 136
    //   252: invokestatic 139	android/os/Message:obtain	(Landroid/os/Handler;I)Landroid/os/Message;
    //   255: invokevirtual 135	android/os/Message:sendToTarget	()V
    //   258: return
    //
    // Exception table:
    //   from	to	target	type
    //   50	61	216	com/google/zxing/ReaderException
    //   50	61	231	finally
  }

  public void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      return;
    case 2131623937:
      decode((byte[])paramMessage.obj, paramMessage.arg1, paramMessage.arg2);
      return;
    case 2131623941:
    }
    Looper.myLooper().quit();
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.android.DecodeHandler
 * JD-Core Version:    0.6.0
 */