package com.google.zxing.client.android.camera;

import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Camera.Area;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.Size;
import android.os.Build;
import android.os.Build.VERSION;
import android.util.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

public final class CameraConfigurationUtils
{
  private static final int AREA_PER_1000 = 400;
  private static final double MAX_ASPECT_DISTORTION = 0.15D;
  private static final float MAX_EXPOSURE_COMPENSATION = 1.5F;
  private static final int MAX_FPS = 20;
  private static final float MIN_EXPOSURE_COMPENSATION = 0.0F;
  private static final int MIN_FPS = 10;
  private static final int MIN_PREVIEW_PIXELS = 153600;
  private static final Pattern SEMICOLON = Pattern.compile(";");
  private static final String TAG = "CameraConfiguration";

  private static List<Camera.Area> buildMiddleArea(int paramInt)
  {
    return Collections.singletonList(new Camera.Area(new Rect(-paramInt, -paramInt, paramInt, paramInt), 1));
  }

  public static String collectStats(Camera.Parameters paramParameters)
  {
    return collectStats(paramParameters.flatten());
  }

  public static String collectStats(CharSequence paramCharSequence)
  {
    StringBuilder localStringBuilder = new StringBuilder(1000);
    localStringBuilder.append("BOARD=").append(Build.BOARD).append('\n');
    localStringBuilder.append("BRAND=").append(Build.BRAND).append('\n');
    localStringBuilder.append("CPU_ABI=").append(Build.CPU_ABI).append('\n');
    localStringBuilder.append("DEVICE=").append(Build.DEVICE).append('\n');
    localStringBuilder.append("DISPLAY=").append(Build.DISPLAY).append('\n');
    localStringBuilder.append("FINGERPRINT=").append(Build.FINGERPRINT).append('\n');
    localStringBuilder.append("HOST=").append(Build.HOST).append('\n');
    localStringBuilder.append("ID=").append(Build.ID).append('\n');
    localStringBuilder.append("MANUFACTURER=").append(Build.MANUFACTURER).append('\n');
    localStringBuilder.append("MODEL=").append(Build.MODEL).append('\n');
    localStringBuilder.append("PRODUCT=").append(Build.PRODUCT).append('\n');
    localStringBuilder.append("TAGS=").append(Build.TAGS).append('\n');
    localStringBuilder.append("TIME=").append(Build.TIME).append('\n');
    localStringBuilder.append("TYPE=").append(Build.TYPE).append('\n');
    localStringBuilder.append("USER=").append(Build.USER).append('\n');
    localStringBuilder.append("VERSION.CODENAME=").append(Build.VERSION.CODENAME).append('\n');
    localStringBuilder.append("VERSION.INCREMENTAL=").append(Build.VERSION.INCREMENTAL).append('\n');
    localStringBuilder.append("VERSION.RELEASE=").append(Build.VERSION.RELEASE).append('\n');
    localStringBuilder.append("VERSION.SDK_INT=").append(Build.VERSION.SDK_INT).append('\n');
    String[] arrayOfString;
    int i;
    if (paramCharSequence != null)
    {
      arrayOfString = SEMICOLON.split(paramCharSequence);
      Arrays.sort(arrayOfString);
      i = arrayOfString.length;
    }
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return localStringBuilder.toString();
      localStringBuilder.append(arrayOfString[j]).append('\n');
    }
  }

  public static Point findBestPreviewSizeValue(Camera.Parameters paramParameters, Point paramPoint)
  {
    List localList = paramParameters.getSupportedPreviewSizes();
    if (localList == null)
    {
      Log.w("CameraConfiguration", "Device returned no supported preview sizes; using default");
      Camera.Size localSize5 = paramParameters.getPreviewSize();
      if (localSize5 == null)
        throw new IllegalStateException("Parameters contained no preview size!");
      return new Point(localSize5.width, localSize5.height);
    }
    ArrayList localArrayList = new ArrayList(localList);
    Collections.sort(localArrayList, new Comparator()
    {
      public int compare(Camera.Size paramSize1, Camera.Size paramSize2)
      {
        int i = paramSize1.height * paramSize1.width;
        int j = paramSize2.height * paramSize2.width;
        if (j < i)
          return -1;
        if (j > i)
          return 1;
        return 0;
      }
    });
    StringBuilder localStringBuilder;
    Iterator localIterator1;
    double d;
    Iterator localIterator2;
    if (Log.isLoggable("CameraConfiguration", 4))
    {
      localStringBuilder = new StringBuilder();
      localIterator1 = localArrayList.iterator();
      if (!localIterator1.hasNext())
        Log.i("CameraConfiguration", "Supported preview sizes: " + localStringBuilder);
    }
    else
    {
      d = paramPoint.x / paramPoint.y;
      localIterator2 = localArrayList.iterator();
    }
    int i;
    int j;
    label324: label334: int m;
    label343: int n;
    label388: label395: label402: 
    do
    {
      while (true)
      {
        if (!localIterator2.hasNext())
        {
          if (localArrayList.isEmpty())
            break label460;
          Camera.Size localSize4 = (Camera.Size)localArrayList.get(0);
          Point localPoint3 = new Point(localSize4.width, localSize4.height);
          Log.i("CameraConfiguration", "Using largest suitable preview size: " + localPoint3);
          return localPoint3;
          Camera.Size localSize1 = (Camera.Size)localIterator1.next();
          localStringBuilder.append(localSize1.width).append('x').append(localSize1.height).append(' ');
          break;
        }
        Camera.Size localSize2 = (Camera.Size)localIterator2.next();
        i = localSize2.width;
        j = localSize2.height;
        if (i * j >= 153600)
          break label324;
        localIterator2.remove();
      }
      int k;
      if (i < j)
      {
        k = 1;
        if (k == 0)
          break label388;
        m = j;
        if (k == 0)
          break label395;
      }
      for (n = i; ; n = j)
      {
        if (Math.abs(m / n - d) <= 0.15D)
          break label402;
        localIterator2.remove();
        break;
        k = 0;
        break label334;
        m = i;
        break label343;
      }
    }
    while ((m != paramPoint.x) || (n != paramPoint.y));
    Point localPoint1 = new Point(i, j);
    Log.i("CameraConfiguration", "Found preview size exactly matching screen size: " + localPoint1);
    return localPoint1;
    label460: Camera.Size localSize3 = paramParameters.getPreviewSize();
    if (localSize3 == null)
      throw new IllegalStateException("Parameters contained no preview size!");
    Point localPoint2 = new Point(localSize3.width, localSize3.height);
    Log.i("CameraConfiguration", "No suitable preview sizes, using default: " + localPoint2);
    return localPoint2;
  }

  private static String findSettableValue(String paramString, Collection<String> paramCollection, String[] paramArrayOfString)
  {
    Log.i("CameraConfiguration", "Requesting " + paramString + " value from among: " + Arrays.toString(paramArrayOfString));
    Log.i("CameraConfiguration", "Supported " + paramString + " values: " + paramCollection);
    int i;
    if (paramCollection != null)
      i = paramArrayOfString.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        Log.i("CameraConfiguration", "No supported values match");
        return null;
      }
      String str = paramArrayOfString[j];
      if (!paramCollection.contains(str))
        continue;
      Log.i("CameraConfiguration", "Can set " + paramString + " to: " + str);
      return str;
    }
  }

  private static Integer indexOfClosestZoom(Camera.Parameters paramParameters, double paramDouble)
  {
    List localList = paramParameters.getZoomRatios();
    Log.i("CameraConfiguration", "Zoom ratios: " + localList);
    int i = paramParameters.getMaxZoom();
    if ((localList == null) || (localList.isEmpty()) || (localList.size() != i + 1))
    {
      Log.w("CameraConfiguration", "Invalid zoom ratios!");
      return null;
    }
    double d1 = 100.0D * paramDouble;
    double d2 = (1.0D / 0.0D);
    int j = 0;
    for (int k = 0; ; k++)
    {
      if (k >= localList.size())
      {
        Log.i("CameraConfiguration", "Chose zoom ratio of " + ((Integer)localList.get(j)).intValue() / 100.0D);
        return Integer.valueOf(j);
      }
      double d3 = Math.abs(((Integer)localList.get(k)).intValue() - d1);
      if (d3 >= d2)
        continue;
      d2 = d3;
      j = k;
    }
  }

  public static void setBarcodeSceneMode(Camera.Parameters paramParameters)
  {
    if ("barcode".equals(paramParameters.getSceneMode()))
      Log.i("CameraConfiguration", "Barcode scene mode already set");
    String str;
    do
    {
      return;
      str = findSettableValue("scene mode", paramParameters.getSupportedSceneModes(), new String[] { "barcode" });
    }
    while (str == null);
    paramParameters.setSceneMode(str);
  }

  public static void setBestExposure(Camera.Parameters paramParameters, boolean paramBoolean)
  {
    int i = paramParameters.getMinExposureCompensation();
    int j = paramParameters.getMaxExposureCompensation();
    float f1 = paramParameters.getExposureCompensationStep();
    if (((i != 0) || (j != 0)) && (f1 > 0.0F))
    {
      float f2 = 0.0F;
      if (paramBoolean);
      float f3;
      int m;
      while (true)
      {
        int k = Math.round(f2 / f1);
        f3 = f1 * k;
        m = Math.max(Math.min(k, j), i);
        if (paramParameters.getExposureCompensation() != m)
          break;
        Log.i("CameraConfiguration", "Exposure compensation already set to " + m + " / " + f3);
        return;
        f2 = 1.5F;
      }
      Log.i("CameraConfiguration", "Setting exposure compensation to " + m + " / " + f3);
      paramParameters.setExposureCompensation(m);
      return;
    }
    Log.i("CameraConfiguration", "Camera does not support exposure compensation");
  }

  public static void setBestPreviewFPS(Camera.Parameters paramParameters)
  {
    setBestPreviewFPS(paramParameters, 10, 20);
  }

  public static void setBestPreviewFPS(Camera.Parameters paramParameters, int paramInt1, int paramInt2)
  {
    List localList = paramParameters.getSupportedPreviewFpsRange();
    Log.i("CameraConfiguration", "Supported FPS ranges: " + toString(localList));
    Iterator localIterator;
    Object localObject;
    if ((localList != null) && (!localList.isEmpty()))
    {
      localIterator = localList.iterator();
      boolean bool = localIterator.hasNext();
      localObject = null;
      if (bool)
        break label84;
    }
    while (true)
    {
      if (localObject != null)
        break label135;
      Log.i("CameraConfiguration", "No suitable FPS range?");
      return;
      label84: int[] arrayOfInt1 = (int[])localIterator.next();
      int i = arrayOfInt1[0];
      int j = arrayOfInt1[1];
      if ((i < paramInt1 * 1000) || (j > paramInt2 * 1000))
        break;
      localObject = arrayOfInt1;
    }
    label135: int[] arrayOfInt2 = new int[2];
    paramParameters.getPreviewFpsRange(arrayOfInt2);
    if (Arrays.equals(arrayOfInt2, localObject))
    {
      Log.i("CameraConfiguration", "FPS range already set to " + Arrays.toString(localObject));
      return;
    }
    Log.i("CameraConfiguration", "Setting FPS range to " + Arrays.toString(localObject));
    paramParameters.setPreviewFpsRange(localObject[0], localObject[1]);
  }

  public static void setFocus(Camera.Parameters paramParameters, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    List localList = paramParameters.getSupportedFocusModes();
    String str = null;
    if (paramBoolean1)
      if ((!paramBoolean3) && (!paramBoolean2))
        break label118;
    label118: for (str = findSettableValue("focus mode", localList, new String[] { "auto" }); ; str = findSettableValue("focus mode", localList, new String[] { "continuous-picture", "continuous-video", "auto" }))
    {
      if ((!paramBoolean3) && (str == null))
        str = findSettableValue("focus mode", localList, new String[] { "macro", "edof" });
      if (str != null)
      {
        if (!str.equals(paramParameters.getFocusMode()))
          break;
        Log.i("CameraConfiguration", "Focus mode already set to " + str);
      }
      return;
    }
    paramParameters.setFocusMode(str);
  }

  public static void setFocusArea(Camera.Parameters paramParameters)
  {
    if (paramParameters.getMaxNumFocusAreas() > 0)
    {
      Log.i("CameraConfiguration", "Old focus areas: " + toString(paramParameters.getFocusAreas()));
      List localList = buildMiddleArea(400);
      Log.i("CameraConfiguration", "Setting focus area to : " + toString(localList));
      paramParameters.setFocusAreas(localList);
      return;
    }
    Log.i("CameraConfiguration", "Device does not support focus areas");
  }

  public static void setInvertColor(Camera.Parameters paramParameters)
  {
    if ("negative".equals(paramParameters.getColorEffect()))
      Log.i("CameraConfiguration", "Negative effect already set");
    String str;
    do
    {
      return;
      str = findSettableValue("color effect", paramParameters.getSupportedColorEffects(), new String[] { "negative" });
    }
    while (str == null);
    paramParameters.setColorEffect(str);
  }

  public static void setMetering(Camera.Parameters paramParameters)
  {
    if (paramParameters.getMaxNumMeteringAreas() > 0)
    {
      Log.i("CameraConfiguration", "Old metering areas: " + paramParameters.getMeteringAreas());
      List localList = buildMiddleArea(400);
      Log.i("CameraConfiguration", "Setting metering area to : " + toString(localList));
      paramParameters.setMeteringAreas(localList);
      return;
    }
    Log.i("CameraConfiguration", "Device does not support metering areas");
  }

  public static void setTorch(Camera.Parameters paramParameters, boolean paramBoolean)
  {
    List localList = paramParameters.getSupportedFlashModes();
    if (paramBoolean);
    for (String str = findSettableValue("flash mode", localList, new String[] { "torch", "on" }); ; str = findSettableValue("flash mode", localList, new String[] { "off" }))
    {
      if (str != null)
      {
        if (!str.equals(paramParameters.getFlashMode()))
          break;
        Log.i("CameraConfiguration", "Flash mode already set to " + str);
      }
      return;
    }
    Log.i("CameraConfiguration", "Setting flash mode to " + str);
    paramParameters.setFlashMode(str);
  }

  public static void setVideoStabilization(Camera.Parameters paramParameters)
  {
    if (paramParameters.isVideoStabilizationSupported())
    {
      if (paramParameters.getVideoStabilization())
      {
        Log.i("CameraConfiguration", "Video stabilization already enabled");
        return;
      }
      Log.i("CameraConfiguration", "Enabling video stabilization...");
      paramParameters.setVideoStabilization(true);
      return;
    }
    Log.i("CameraConfiguration", "This device does not support video stabilization");
  }

  public static void setZoom(Camera.Parameters paramParameters, double paramDouble)
  {
    if (paramParameters.isZoomSupported())
    {
      Integer localInteger = indexOfClosestZoom(paramParameters, paramDouble);
      if (localInteger == null)
        return;
      if (paramParameters.getZoom() == localInteger.intValue())
      {
        Log.i("CameraConfiguration", "Zoom is already set to " + localInteger);
        return;
      }
      Log.i("CameraConfiguration", "Setting zoom to " + localInteger);
      paramParameters.setZoom(localInteger.intValue());
      return;
    }
    Log.i("CameraConfiguration", "Zoom is not supported");
  }

  private static String toString(Iterable<Camera.Area> paramIterable)
  {
    if (paramIterable == null)
      return null;
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = paramIterable.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return localStringBuilder.toString();
      Camera.Area localArea = (Camera.Area)localIterator.next();
      localStringBuilder.append(localArea.rect).append(':').append(localArea.weight).append(' ');
    }
  }

  private static String toString(Collection<int[]> paramCollection)
  {
    if ((paramCollection == null) || (paramCollection.isEmpty()))
      return "[]";
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append('[');
    Iterator localIterator = paramCollection.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        localStringBuilder.append(']');
        return localStringBuilder.toString();
      }
      localStringBuilder.append(Arrays.toString((int[])localIterator.next()));
      if (!localIterator.hasNext())
        continue;
      localStringBuilder.append(", ");
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.android.camera.CameraConfigurationUtils
 * JD-Core Version:    0.6.0
 */