package com.google.zxing.client.android;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.camera.CameraManager;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public final class ViewfinderView extends View
{
  private static final long ANIMATION_DELAY = 10L;
  private static final int CORNER_WIDTH = 6;
  private static final int MIDDLE_LINE_PADDING = 5;
  private static final int MIDDLE_LINE_WIDTH = 10;
  private static final int OPAQUE = 255;
  private static final int SPEEN_DISTANCE = 5;
  private static final String TAG = "log";
  private static final int TEXT_PADDING_TOP = 30;
  private static final int TEXT_SIZE = 16;
  private static float density;
  private int ScreenRate;
  boolean isFirst;
  private Collection<ResultPoint> lastPossibleResultPoints;
  private final int maskColor;
  private Paint paint;
  private Collection<ResultPoint> possibleResultPoints;
  private Bitmap resultBitmap;
  private final int resultColor;
  private final int resultPointColor;
  private int slideBottom;
  private int slideTop;

  public ViewfinderView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    density = paramContext.getResources().getDisplayMetrics().density;
    this.ScreenRate = (int)(20.0F * density);
    this.paint = new Paint();
    Resources localResources = getResources();
    this.maskColor = localResources.getColor(2131165233);
    this.resultColor = localResources.getColor(2131165230);
    this.resultPointColor = localResources.getColor(2131165234);
    this.possibleResultPoints = new HashSet(5);
  }

  public void addPossibleResultPoint(ResultPoint paramResultPoint)
  {
    this.possibleResultPoints.add(paramResultPoint);
  }

  public void drawResultBitmap(Bitmap paramBitmap)
  {
    this.resultBitmap = paramBitmap;
    invalidate();
  }

  public void drawViewfinder()
  {
    this.resultBitmap = null;
    invalidate();
  }

  public void onDraw(Canvas paramCanvas)
  {
    Rect localRect1 = CameraManager.get().getFramingRect();
    if (localRect1 == null)
      return;
    if (!this.isFirst)
    {
      this.isFirst = true;
      this.slideTop = localRect1.top;
      this.slideBottom = localRect1.bottom;
    }
    int i = paramCanvas.getWidth();
    int j = paramCanvas.getHeight();
    int k = 5 * CameraManager.screenHeight / 800;
    Paint localPaint = this.paint;
    if (this.resultBitmap != null);
    for (int m = this.resultColor; ; m = this.maskColor)
    {
      localPaint.setColor(m);
      paramCanvas.drawRect(0.0F, 0.0F, i, localRect1.top, this.paint);
      paramCanvas.drawRect(0.0F, localRect1.top, localRect1.left, 1 + localRect1.bottom, this.paint);
      paramCanvas.drawRect(1 + localRect1.right, localRect1.top, i, 1 + localRect1.bottom, this.paint);
      paramCanvas.drawRect(0.0F, 1 + localRect1.bottom, i, j, this.paint);
      if (this.resultBitmap == null)
        break;
      this.paint.setAlpha(255);
      paramCanvas.drawBitmap(this.resultBitmap, localRect1.left, localRect1.top, this.paint);
      return;
    }
    this.paint.setColor(-16711936);
    paramCanvas.drawRect(localRect1.left, localRect1.top, localRect1.left + this.ScreenRate, 6 + localRect1.top, this.paint);
    paramCanvas.drawRect(localRect1.left, localRect1.top, 6 + localRect1.left, localRect1.top + this.ScreenRate, this.paint);
    paramCanvas.drawRect(localRect1.right - this.ScreenRate, localRect1.top, localRect1.right, 6 + localRect1.top, this.paint);
    paramCanvas.drawRect(-6 + localRect1.right, localRect1.top, localRect1.right, localRect1.top + this.ScreenRate, this.paint);
    paramCanvas.drawRect(localRect1.left, -6 + localRect1.bottom, localRect1.left + this.ScreenRate, localRect1.bottom, this.paint);
    paramCanvas.drawRect(localRect1.left, localRect1.bottom - this.ScreenRate, 6 + localRect1.left, localRect1.bottom, this.paint);
    paramCanvas.drawRect(localRect1.right - this.ScreenRate, -6 + localRect1.bottom, localRect1.right, localRect1.bottom, this.paint);
    paramCanvas.drawRect(-6 + localRect1.right, localRect1.bottom - this.ScreenRate, localRect1.right, localRect1.bottom, this.paint);
    this.slideTop = (k + this.slideTop);
    if (this.slideTop >= localRect1.bottom)
      this.slideTop = localRect1.top;
    Rect localRect2 = new Rect(5 + localRect1.left, -5 + this.slideTop, -5 + localRect1.right, 5 + this.slideTop);
    paramCanvas.drawBitmap(BitmapFactory.decodeResource(getResources(), 2130837733), null, localRect2, this.paint);
    this.paint.setColor(-1);
    this.paint.setTextSize(16.0F * density);
    this.paint.setAlpha(64);
    this.paint.setTypeface(Typeface.create("System", 1));
    Collection localCollection1 = this.possibleResultPoints;
    Collection localCollection2 = this.lastPossibleResultPoints;
    Iterator localIterator2;
    if (localCollection1.isEmpty())
    {
      this.lastPossibleResultPoints = null;
      if (localCollection2 != null)
      {
        this.paint.setAlpha(127);
        this.paint.setColor(this.resultPointColor);
        localIterator2 = localCollection2.iterator();
      }
    }
    while (true)
    {
      if (!localIterator2.hasNext())
      {
        postInvalidateDelayed(10L, localRect1.left, localRect1.top, localRect1.right, localRect1.bottom);
        return;
        this.possibleResultPoints = new HashSet(5);
        this.lastPossibleResultPoints = localCollection1;
        this.paint.setAlpha(255);
        this.paint.setColor(this.resultPointColor);
        Iterator localIterator1 = localCollection1.iterator();
        while (localIterator1.hasNext())
        {
          ResultPoint localResultPoint1 = (ResultPoint)localIterator1.next();
          paramCanvas.drawCircle(localRect1.left + localResultPoint1.getX(), localRect1.top + localResultPoint1.getY(), 6.0F, this.paint);
        }
        break;
      }
      ResultPoint localResultPoint2 = (ResultPoint)localIterator2.next();
      paramCanvas.drawCircle(localRect1.left + localResultPoint2.getX(), localRect1.top + localResultPoint2.getY(), 3.0F, this.paint);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.client.android.ViewfinderView
 * JD-Core Version:    0.6.0
 */