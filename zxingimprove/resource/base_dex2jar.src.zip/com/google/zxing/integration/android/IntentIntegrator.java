package com.google.zxing.integration.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class IntentIntegrator
{
  public static final Collection<String> ALL_CODE_TYPES;
  private static final String BSPLUS_PACKAGE = "com.srowen.bs.android";
  private static final String BS_PACKAGE = "com.google.zxing.client.android.qr";
  public static final Collection<String> DATA_MATRIX_TYPES;
  public static final String DEFAULT_MESSAGE = "This application requires Barcode Scanner. Would you like to install it?";
  public static final String DEFAULT_NO = "No";
  public static final String DEFAULT_TITLE = "Install Barcode Scanner?";
  public static final String DEFAULT_YES = "Yes";
  public static final Collection<String> ONE_D_CODE_TYPES;
  public static final Collection<String> PRODUCT_CODE_TYPES;
  public static final Collection<String> QR_CODE_TYPES;
  public static final int REQUEST_CODE = 49374;
  private static final String TAG = IntentIntegrator.class.getSimpleName();
  public static final List<String> TARGET_ALL_KNOWN;
  public static final List<String> TARGET_BARCODE_SCANNER_ONLY;
  private final Activity activity;
  private String buttonNo;
  private String buttonYes;
  private final Fragment fragment;
  private String message;
  private final Map<String, Object> moreExtras = new HashMap(3);
  private List<String> targetApplications;
  private String title;

  static
  {
    PRODUCT_CODE_TYPES = list(new String[] { "UPC_A", "UPC_E", "EAN_8", "EAN_13", "RSS_14" });
    ONE_D_CODE_TYPES = list(new String[] { "UPC_A", "UPC_E", "EAN_8", "EAN_13", "CODE_39", "CODE_93", "CODE_128", "ITF", "RSS_14", "RSS_EXPANDED" });
    QR_CODE_TYPES = Collections.singleton("QR_CODE");
    DATA_MATRIX_TYPES = Collections.singleton("DATA_MATRIX");
    ALL_CODE_TYPES = null;
    TARGET_BARCODE_SCANNER_ONLY = Collections.singletonList("com.google.zxing.client.android.qr");
    TARGET_ALL_KNOWN = list(new String[] { "com.srowen.bs.android", "com.srowen.bs.android.simple", "com.google.zxing.client.android.qr" });
  }

  public IntentIntegrator(Activity paramActivity)
  {
    this.activity = paramActivity;
    this.fragment = null;
    initializeConfiguration();
  }

  public IntentIntegrator(Fragment paramFragment)
  {
    this.activity = paramFragment.getActivity();
    this.fragment = paramFragment;
    initializeConfiguration();
  }

  private void attachMoreExtras(Intent paramIntent)
  {
    Iterator localIterator = this.moreExtras.entrySet().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str = (String)localEntry.getKey();
      Object localObject = localEntry.getValue();
      if ((localObject instanceof Integer))
      {
        paramIntent.putExtra(str, (Integer)localObject);
        continue;
      }
      if ((localObject instanceof Long))
      {
        paramIntent.putExtra(str, (Long)localObject);
        continue;
      }
      if ((localObject instanceof Boolean))
      {
        paramIntent.putExtra(str, (Boolean)localObject);
        continue;
      }
      if ((localObject instanceof Double))
      {
        paramIntent.putExtra(str, (Double)localObject);
        continue;
      }
      if ((localObject instanceof Float))
      {
        paramIntent.putExtra(str, (Float)localObject);
        continue;
      }
      if ((localObject instanceof Bundle))
      {
        paramIntent.putExtra(str, (Bundle)localObject);
        continue;
      }
      paramIntent.putExtra(str, localObject.toString());
    }
  }

  private static boolean contains(Iterable<ResolveInfo> paramIterable, String paramString)
  {
    Iterator localIterator = paramIterable.iterator();
    do
      if (!localIterator.hasNext())
        return false;
    while (!paramString.equals(((ResolveInfo)localIterator.next()).activityInfo.packageName));
    return true;
  }

  private String findTargetAppPackage(Intent paramIntent)
  {
    List localList = this.activity.getPackageManager().queryIntentActivities(paramIntent, 65536);
    Iterator localIterator;
    if (localList != null)
      localIterator = this.targetApplications.iterator();
    String str;
    do
    {
      if (!localIterator.hasNext())
        return null;
      str = (String)localIterator.next();
    }
    while (!contains(localList, str));
    return str;
  }

  private void initializeConfiguration()
  {
    this.title = "Install Barcode Scanner?";
    this.message = "This application requires Barcode Scanner. Would you like to install it?";
    this.buttonYes = "Yes";
    this.buttonNo = "No";
    this.targetApplications = TARGET_ALL_KNOWN;
  }

  private static List<String> list(String[] paramArrayOfString)
  {
    return Collections.unmodifiableList(Arrays.asList(paramArrayOfString));
  }

  public static IntentResult parseActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    if (paramInt1 == 49374)
    {
      if (paramInt2 == -1)
      {
        String str1 = paramIntent.getStringExtra("SCAN_RESULT");
        String str2 = paramIntent.getStringExtra("SCAN_RESULT_FORMAT");
        byte[] arrayOfByte = paramIntent.getByteArrayExtra("SCAN_RESULT_BYTES");
        int i = paramIntent.getIntExtra("SCAN_RESULT_ORIENTATION", -2147483648);
        Integer localInteger = null;
        if (i == -2147483648);
        while (true)
        {
          return new IntentResult(str1, str2, arrayOfByte, localInteger, paramIntent.getStringExtra("SCAN_RESULT_ERROR_CORRECTION_LEVEL"));
          localInteger = Integer.valueOf(i);
        }
      }
      return new IntentResult();
    }
    return null;
  }

  public final void addExtra(String paramString, Object paramObject)
  {
    this.moreExtras.put(paramString, paramObject);
  }

  public String getButtonNo()
  {
    return this.buttonNo;
  }

  public String getButtonYes()
  {
    return this.buttonYes;
  }

  public String getMessage()
  {
    return this.message;
  }

  public Map<String, ?> getMoreExtras()
  {
    return this.moreExtras;
  }

  public Collection<String> getTargetApplications()
  {
    return this.targetApplications;
  }

  public String getTitle()
  {
    return this.title;
  }

  public final AlertDialog initiateScan()
  {
    return initiateScan(ALL_CODE_TYPES, -1);
  }

  public final AlertDialog initiateScan(int paramInt)
  {
    return initiateScan(ALL_CODE_TYPES, paramInt);
  }

  public final AlertDialog initiateScan(Collection<String> paramCollection)
  {
    return initiateScan(paramCollection, -1);
  }

  public final AlertDialog initiateScan(Collection<String> paramCollection, int paramInt)
  {
    Intent localIntent = new Intent("com.google.zxing.client.android.qr.SCAN");
    localIntent.addCategory("android.intent.category.DEFAULT");
    StringBuilder localStringBuilder;
    Iterator localIterator;
    if (paramCollection != null)
    {
      localStringBuilder = new StringBuilder();
      localIterator = paramCollection.iterator();
    }
    while (true)
    {
      if (!localIterator.hasNext())
      {
        localIntent.putExtra("SCAN_FORMATS", localStringBuilder.toString());
        if (paramInt >= 0)
          localIntent.putExtra("SCAN_CAMERA_ID", paramInt);
        localIntent.setPackage(findTargetAppPackage(localIntent));
        localIntent.addFlags(67108864);
        localIntent.addFlags(524288);
        attachMoreExtras(localIntent);
        startActivityForResult(localIntent, 49374);
        return null;
      }
      String str = (String)localIterator.next();
      if (localStringBuilder.length() > 0)
        localStringBuilder.append(',');
      localStringBuilder.append(str);
    }
  }

  public void setButtonNo(String paramString)
  {
    this.buttonNo = paramString;
  }

  public void setButtonNoByID(int paramInt)
  {
    this.buttonNo = this.activity.getString(paramInt);
  }

  public void setButtonYes(String paramString)
  {
    this.buttonYes = paramString;
  }

  public void setButtonYesByID(int paramInt)
  {
    this.buttonYes = this.activity.getString(paramInt);
  }

  public void setMessage(String paramString)
  {
    this.message = paramString;
  }

  public void setMessageByID(int paramInt)
  {
    this.message = this.activity.getString(paramInt);
  }

  public void setSingleTargetApplication(String paramString)
  {
    this.targetApplications = Collections.singletonList(paramString);
  }

  public final void setTargetApplications(List<String> paramList)
  {
    if (paramList.isEmpty())
      throw new IllegalArgumentException("No target applications");
    this.targetApplications = paramList;
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
  }

  public void setTitleByID(int paramInt)
  {
    this.title = this.activity.getString(paramInt);
  }

  public final AlertDialog shareText(CharSequence paramCharSequence)
  {
    return shareText(paramCharSequence, "TEXT_TYPE");
  }

  public final AlertDialog shareText(CharSequence paramCharSequence1, CharSequence paramCharSequence2)
  {
    Intent localIntent = new Intent();
    localIntent.addCategory("android.intent.category.DEFAULT");
    localIntent.setAction("com.google.zxing.client.android.qr.ENCODE");
    localIntent.putExtra("ENCODE_TYPE", paramCharSequence2);
    localIntent.putExtra("ENCODE_DATA", paramCharSequence1);
    localIntent.setPackage(findTargetAppPackage(localIntent));
    localIntent.addFlags(67108864);
    localIntent.addFlags(524288);
    attachMoreExtras(localIntent);
    if (this.fragment == null)
      this.activity.startActivity(localIntent);
    while (true)
    {
      return null;
      this.fragment.startActivity(localIntent);
    }
  }

  protected void startActivityForResult(Intent paramIntent, int paramInt)
  {
    if (this.fragment == null)
    {
      this.activity.startActivityForResult(paramIntent, paramInt);
      return;
    }
    this.fragment.startActivityForResult(paramIntent, paramInt);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.integration.android.IntentIntegrator
 * JD-Core Version:    0.6.0
 */