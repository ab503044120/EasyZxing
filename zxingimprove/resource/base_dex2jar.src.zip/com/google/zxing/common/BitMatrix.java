package com.google.zxing.common;

import I;
import java.util.Arrays;

public final class BitMatrix
  implements Cloneable
{
  private final int[] bits;
  private final int height;
  private final int rowSize;
  private final int width;

  public BitMatrix(int paramInt)
  {
    this(paramInt, paramInt);
  }

  public BitMatrix(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 1) || (paramInt2 < 1))
      throw new IllegalArgumentException("Both dimensions must be greater than 0");
    this.width = paramInt1;
    this.height = paramInt2;
    this.rowSize = ((paramInt1 + 31) / 32);
    this.bits = new int[paramInt2 * this.rowSize];
  }

  private BitMatrix(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt)
  {
    this.width = paramInt1;
    this.height = paramInt2;
    this.rowSize = paramInt3;
    this.bits = paramArrayOfInt;
  }

  public void clear()
  {
    int i = this.bits.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return;
      this.bits[j] = 0;
    }
  }

  public BitMatrix clone()
  {
    return new BitMatrix(this.width, this.height, this.rowSize, (int[])this.bits.clone());
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof BitMatrix));
    BitMatrix localBitMatrix;
    do
    {
      return false;
      localBitMatrix = (BitMatrix)paramObject;
    }
    while ((this.width != localBitMatrix.width) || (this.height != localBitMatrix.height) || (this.rowSize != localBitMatrix.rowSize) || (!Arrays.equals(this.bits, localBitMatrix.bits)));
    return true;
  }

  public void flip(int paramInt1, int paramInt2)
  {
    int i = paramInt2 * this.rowSize + paramInt1 / 32;
    int[] arrayOfInt = this.bits;
    arrayOfInt[i] ^= 1 << (paramInt1 & 0x1F);
  }

  public boolean get(int paramInt1, int paramInt2)
  {
    int i = paramInt2 * this.rowSize + paramInt1 / 32;
    return (0x1 & this.bits[i] >>> (paramInt1 & 0x1F)) != 0;
  }

  public int[] getBottomRightOnBit()
  {
    for (int i = -1 + this.bits.length; ; i--)
    {
      if ((i >= 0) && (this.bits[i] == 0))
        continue;
      if (i >= 0)
        break;
      return null;
    }
    int j = i / this.rowSize;
    int k = 32 * (i % this.rowSize);
    int m = this.bits[i];
    for (int n = 31; ; n--)
      if (m >>> n != 0)
        return new int[] { k + n, j };
  }

  public int[] getEnclosingRectangle()
  {
    int i = this.width;
    int j = this.height;
    int k = -1;
    int m = -1;
    int n = 0;
    int i5;
    int i6;
    while (true)
      if (n >= this.height)
      {
        i5 = k - i;
        i6 = m - j;
        if ((i5 >= 0) && (i6 >= 0))
          break;
        return null;
      }
      else
      {
        int i1 = 0;
        if (i1 >= this.rowSize)
        {
          n++;
          continue;
        }
        int i2 = this.bits[(i1 + n * this.rowSize)];
        int i4;
        if (i2 != 0)
        {
          if (n < j)
            j = n;
          if (n > m)
            m = n;
          if (i1 * 32 < i)
          {
            i4 = 0;
            label122: if (i2 << 31 - i4 == 0)
              break label205;
            if (i4 + i1 * 32 < i)
              i = i4 + i1 * 32;
          }
          if (31 + i1 * 32 <= k);
        }
        for (int i3 = 31; ; i3--)
        {
          if (i2 >>> i3 == 0)
            continue;
          if (i3 + i1 * 32 > k)
            k = i3 + i1 * 32;
          i1++;
          break;
          label205: i4++;
          break label122;
        }
      }
    return new int[] { i, j, i5, i6 };
  }

  public int getHeight()
  {
    return this.height;
  }

  public BitArray getRow(int paramInt, BitArray paramBitArray)
  {
    int i;
    if ((paramBitArray == null) || (paramBitArray.getSize() < this.width))
    {
      paramBitArray = new BitArray(this.width);
      i = paramInt * this.rowSize;
    }
    for (int j = 0; ; j++)
    {
      if (j >= this.rowSize)
      {
        return paramBitArray;
        paramBitArray.clear();
        break;
      }
      paramBitArray.setBulk(j * 32, this.bits[(i + j)]);
    }
  }

  public int[] getTopLeftOnBit()
  {
    for (int i = 0; ; i++)
    {
      if ((i < this.bits.length) && (this.bits[i] == 0))
        continue;
      if (i != this.bits.length)
        break;
      return null;
    }
    int j = i / this.rowSize;
    int k = 32 * (i % this.rowSize);
    int m = this.bits[i];
    for (int n = 0; ; n++)
      if (m << 31 - n != 0)
        return new int[] { k + n, j };
  }

  public int getWidth()
  {
    return this.width;
  }

  public int hashCode()
  {
    return 31 * (31 * (31 * (31 * this.width + this.width) + this.height) + this.rowSize) + Arrays.hashCode(this.bits);
  }

  public void rotate180()
  {
    int i = getWidth();
    int j = getHeight();
    BitArray localBitArray1 = new BitArray(i);
    BitArray localBitArray2 = new BitArray(i);
    for (int k = 0; ; k++)
    {
      if (k >= (j + 1) / 2)
        return;
      localBitArray1 = getRow(k, localBitArray1);
      localBitArray2 = getRow(j - 1 - k, localBitArray2);
      localBitArray1.reverse();
      localBitArray2.reverse();
      setRow(k, localBitArray2);
      setRow(j - 1 - k, localBitArray1);
    }
  }

  public void set(int paramInt1, int paramInt2)
  {
    int i = paramInt2 * this.rowSize + paramInt1 / 32;
    int[] arrayOfInt = this.bits;
    arrayOfInt[i] |= 1 << (paramInt1 & 0x1F);
  }

  public void setRegion(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if ((paramInt2 < 0) || (paramInt1 < 0))
      throw new IllegalArgumentException("Left and top must be nonnegative");
    if ((paramInt4 < 1) || (paramInt3 < 1))
      throw new IllegalArgumentException("Height and width must be at least 1");
    int i = paramInt1 + paramInt3;
    int j = paramInt2 + paramInt4;
    if ((j > this.height) || (i > this.width))
      throw new IllegalArgumentException("The region must fit inside the matrix");
    int k = paramInt2;
    if (k >= j)
      return;
    int m = k * this.rowSize;
    for (int n = paramInt1; ; n++)
    {
      if (n >= i)
      {
        k++;
        break;
      }
      int[] arrayOfInt = this.bits;
      int i1 = m + n / 32;
      arrayOfInt[i1] |= 1 << (n & 0x1F);
    }
  }

  public void setRow(int paramInt, BitArray paramBitArray)
  {
    System.arraycopy(paramBitArray.getBitArray(), 0, this.bits, paramInt * this.rowSize, this.rowSize);
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(this.height * (1 + this.width));
    int j;
    for (int i = 0; ; i++)
    {
      if (i >= this.height)
        return localStringBuilder.toString();
      j = 0;
      if (j < this.width)
        break;
      localStringBuilder.append('\n');
    }
    if (get(j, i));
    for (String str = "X "; ; str = "  ")
    {
      localStringBuilder.append(str);
      j++;
      break;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.common.BitMatrix
 * JD-Core Version:    0.6.0
 */