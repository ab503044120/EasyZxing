package com.google.zxing.common.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.BitMatrix;

public final class WhiteRectangleDetector
{
  private static final int CORR = 1;
  private static final int INIT_SIZE = 10;
  private final int downInit;
  private final int height;
  private final BitMatrix image;
  private final int leftInit;
  private final int rightInit;
  private final int upInit;
  private final int width;

  public WhiteRectangleDetector(BitMatrix paramBitMatrix)
    throws NotFoundException
  {
    this(paramBitMatrix, 10, paramBitMatrix.getWidth() / 2, paramBitMatrix.getHeight() / 2);
  }

  public WhiteRectangleDetector(BitMatrix paramBitMatrix, int paramInt1, int paramInt2, int paramInt3)
    throws NotFoundException
  {
    this.image = paramBitMatrix;
    this.height = paramBitMatrix.getHeight();
    this.width = paramBitMatrix.getWidth();
    int i = paramInt1 / 2;
    this.leftInit = (paramInt2 - i);
    this.rightInit = (paramInt2 + i);
    this.upInit = (paramInt3 - i);
    this.downInit = (paramInt3 + i);
    if ((this.upInit < 0) || (this.leftInit < 0) || (this.downInit >= this.height) || (this.rightInit >= this.width))
      throw NotFoundException.getNotFoundInstance();
  }

  private ResultPoint[] centerEdges(ResultPoint paramResultPoint1, ResultPoint paramResultPoint2, ResultPoint paramResultPoint3, ResultPoint paramResultPoint4)
  {
    float f1 = paramResultPoint1.getX();
    float f2 = paramResultPoint1.getY();
    float f3 = paramResultPoint2.getX();
    float f4 = paramResultPoint2.getY();
    float f5 = paramResultPoint3.getX();
    float f6 = paramResultPoint3.getY();
    float f7 = paramResultPoint4.getX();
    float f8 = paramResultPoint4.getY();
    if (f1 < this.width / 2.0F)
    {
      ResultPoint[] arrayOfResultPoint2 = new ResultPoint[4];
      arrayOfResultPoint2[0] = new ResultPoint(f7 - 1.0F, 1.0F + f8);
      arrayOfResultPoint2[1] = new ResultPoint(1.0F + f3, 1.0F + f4);
      arrayOfResultPoint2[2] = new ResultPoint(f5 - 1.0F, f6 - 1.0F);
      arrayOfResultPoint2[3] = new ResultPoint(1.0F + f1, f2 - 1.0F);
      return arrayOfResultPoint2;
    }
    ResultPoint[] arrayOfResultPoint1 = new ResultPoint[4];
    arrayOfResultPoint1[0] = new ResultPoint(1.0F + f7, 1.0F + f8);
    arrayOfResultPoint1[1] = new ResultPoint(1.0F + f3, f4 - 1.0F);
    arrayOfResultPoint1[2] = new ResultPoint(f5 - 1.0F, 1.0F + f6);
    arrayOfResultPoint1[3] = new ResultPoint(f1 - 1.0F, f2 - 1.0F);
    return arrayOfResultPoint1;
  }

  private boolean containsBlackPoint(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    int i = 1;
    int k;
    if (paramBoolean)
    {
      k = paramInt1;
      if (k <= paramInt2);
    }
    label68: 
    while (true)
    {
      i = 0;
      do
        return i;
      while (this.image.get(k, paramInt3));
      k++;
      break;
      for (int j = paramInt1; ; j++)
      {
        if (j > paramInt2)
          break label68;
        if (this.image.get(paramInt3, j))
          break;
      }
    }
  }

  private ResultPoint getBlackPointOnSegment(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    int i = MathUtils.round(MathUtils.distance(paramFloat1, paramFloat2, paramFloat3, paramFloat4));
    float f1 = (paramFloat3 - paramFloat1) / i;
    float f2 = (paramFloat4 - paramFloat2) / i;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return null;
      int k = MathUtils.round(paramFloat1 + f1 * j);
      int m = MathUtils.round(paramFloat2 + f2 * j);
      if (this.image.get(k, m))
        return new ResultPoint(k, m);
    }
  }

  public ResultPoint[] detect()
    throws NotFoundException
  {
    int i = this.leftInit;
    int j = this.rightInit;
    int k = this.upInit;
    int m = this.downInit;
    int n = 1;
    int i1 = 0;
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    int i5 = 0;
    int i6 = 0;
    int i9;
    ResultPoint localResultPoint1;
    if (n == 0)
    {
      if ((i6 == 0) && (i1 != 0))
      {
        i9 = j - i;
        localResultPoint1 = null;
      }
    }
    else
    {
      label169: label311: for (int i10 = 1; ; i10++)
      {
        if (i10 >= i9);
        label245: label376: 
        do
        {
          if (localResultPoint1 != null)
            break label420;
          throw NotFoundException.getNotFoundInstance();
          n = 0;
          boolean bool1 = true;
          while (true)
          {
            if ((bool1) || (i2 == 0))
            {
              int i7 = this.width;
              if (j < i7);
            }
            else
            {
              int i8 = this.width;
              if (j < i8)
                break label169;
              i6 = 1;
              break;
            }
            bool1 = containsBlackPoint(k, m, j, false);
            if (bool1)
            {
              j++;
              n = 1;
              i2 = 1;
              continue;
            }
            if (i2 != 0)
              continue;
            j++;
          }
          boolean bool2 = true;
          while (true)
          {
            if (((!bool2) && (i3 != 0)) || (m >= this.height))
            {
              if (m < this.height)
                break label245;
              i6 = 1;
              break;
            }
            bool2 = containsBlackPoint(i, j, m, true);
            if (bool2)
            {
              m++;
              n = 1;
              i3 = 1;
              continue;
            }
            if (i3 != 0)
              continue;
            m++;
          }
          boolean bool3 = true;
          while (true)
          {
            if (((!bool3) && (i4 != 0)) || (i < 0))
            {
              if (i >= 0)
                break label311;
              i6 = 1;
              break;
            }
            bool3 = containsBlackPoint(k, m, i, false);
            if (bool3)
            {
              i--;
              n = 1;
              i4 = 1;
              continue;
            }
            if (i4 != 0)
              continue;
            i--;
          }
          boolean bool4 = true;
          while (true)
          {
            if (((!bool4) && (i5 != 0)) || (k < 0))
            {
              if (k >= 0)
                break label376;
              i6 = 1;
              break;
            }
            bool4 = containsBlackPoint(i, j, k, true);
            if (bool4)
            {
              k--;
              n = 1;
              i5 = 1;
              continue;
            }
            if (i5 != 0)
              continue;
            k--;
          }
          if (n == 0)
            break;
          i1 = 1;
          break;
          localResultPoint1 = getBlackPointOnSegment(i, m - i10, i + i10, m);
        }
        while (localResultPoint1 != null);
      }
      label420: ResultPoint localResultPoint2 = null;
      for (int i11 = 1; ; i11++)
      {
        if (i11 >= i9);
        do
        {
          if (localResultPoint2 != null)
            break;
          throw NotFoundException.getNotFoundInstance();
          localResultPoint2 = getBlackPointOnSegment(i, k + i11, i + i11, k);
        }
        while (localResultPoint2 != null);
      }
      ResultPoint localResultPoint3 = null;
      for (int i12 = 1; ; i12++)
      {
        if (i12 >= i9);
        do
        {
          if (localResultPoint3 != null)
            break;
          throw NotFoundException.getNotFoundInstance();
          localResultPoint3 = getBlackPointOnSegment(j, k + i12, j - i12, k);
        }
        while (localResultPoint3 != null);
      }
      ResultPoint localResultPoint4 = null;
      for (int i13 = 1; ; i13++)
      {
        if (i13 >= i9);
        do
        {
          if (localResultPoint4 != null)
            break;
          throw NotFoundException.getNotFoundInstance();
          localResultPoint4 = getBlackPointOnSegment(j, m - i13, j - i13, m);
        }
        while (localResultPoint4 != null);
      }
      return centerEdges(localResultPoint4, localResultPoint1, localResultPoint3, localResultPoint2);
    }
    throw NotFoundException.getNotFoundInstance();
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.common.detector.WhiteRectangleDetector
 * JD-Core Version:    0.6.0
 */