package com.google.zxing.common;

import I;
import java.util.Arrays;

public final class BitArray
  implements Cloneable
{
  private int[] bits;
  private int size;

  public BitArray()
  {
    this.size = 0;
    this.bits = new int[1];
  }

  public BitArray(int paramInt)
  {
    this.size = paramInt;
    this.bits = makeArray(paramInt);
  }

  BitArray(int[] paramArrayOfInt, int paramInt)
  {
    this.bits = paramArrayOfInt;
    this.size = paramInt;
  }

  private void ensureCapacity(int paramInt)
  {
    if (paramInt > 32 * this.bits.length)
    {
      int[] arrayOfInt = makeArray(paramInt);
      System.arraycopy(this.bits, 0, arrayOfInt, 0, this.bits.length);
      this.bits = arrayOfInt;
    }
  }

  private static int[] makeArray(int paramInt)
  {
    return new int[(paramInt + 31) / 32];
  }

  public void appendBit(boolean paramBoolean)
  {
    ensureCapacity(1 + this.size);
    if (paramBoolean)
    {
      int[] arrayOfInt = this.bits;
      int i = this.size / 32;
      arrayOfInt[i] |= 1 << (0x1F & this.size);
    }
    this.size = (1 + this.size);
  }

  public void appendBitArray(BitArray paramBitArray)
  {
    int i = paramBitArray.size;
    ensureCapacity(i + this.size);
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return;
      appendBit(paramBitArray.get(j));
    }
  }

  public void appendBits(int paramInt1, int paramInt2)
  {
    if ((paramInt2 < 0) || (paramInt2 > 32))
      throw new IllegalArgumentException("Num bits must be between 0 and 32");
    ensureCapacity(paramInt2 + this.size);
    int i = paramInt2;
    if (i <= 0)
      return;
    if ((0x1 & paramInt1 >> i - 1) == 1);
    for (boolean bool = true; ; bool = false)
    {
      appendBit(bool);
      i--;
      break;
    }
  }

  public void clear()
  {
    int i = this.bits.length;
    for (int j = 0; ; j++)
    {
      if (j >= i)
        return;
      this.bits[j] = 0;
    }
  }

  public BitArray clone()
  {
    return new BitArray((int[])this.bits.clone(), this.size);
  }

  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof BitArray));
    BitArray localBitArray;
    do
    {
      return false;
      localBitArray = (BitArray)paramObject;
    }
    while ((this.size != localBitArray.size) || (!Arrays.equals(this.bits, localBitArray.bits)));
    return true;
  }

  public void flip(int paramInt)
  {
    int[] arrayOfInt = this.bits;
    int i = paramInt / 32;
    arrayOfInt[i] ^= 1 << (paramInt & 0x1F);
  }

  public boolean get(int paramInt)
  {
    return (this.bits[(paramInt / 32)] & 1 << (paramInt & 0x1F)) != 0;
  }

  public int[] getBitArray()
  {
    return this.bits;
  }

  public int getNextSet(int paramInt)
  {
    int k;
    if (paramInt >= this.size)
    {
      k = this.size;
      return k;
    }
    int i = paramInt / 32;
    for (int j = this.bits[i] & (0xFFFFFFFF ^ -1 + (1 << (paramInt & 0x1F))); ; j = this.bits[i])
    {
      if (j != 0)
      {
        k = i * 32 + Integer.numberOfTrailingZeros(j);
        if (k <= this.size)
          break;
        return this.size;
      }
      i++;
      if (i == this.bits.length)
        return this.size;
    }
  }

  public int getNextUnset(int paramInt)
  {
    int k;
    if (paramInt >= this.size)
    {
      k = this.size;
      return k;
    }
    int i = paramInt / 32;
    for (int j = (0xFFFFFFFF ^ this.bits[i]) & (0xFFFFFFFF ^ -1 + (1 << (paramInt & 0x1F))); ; j = 0xFFFFFFFF ^ this.bits[i])
    {
      if (j != 0)
      {
        k = i * 32 + Integer.numberOfTrailingZeros(j);
        if (k <= this.size)
          break;
        return this.size;
      }
      i++;
      if (i == this.bits.length)
        return this.size;
    }
  }

  public int getSize()
  {
    return this.size;
  }

  public int getSizeInBytes()
  {
    return (7 + this.size) / 8;
  }

  public int hashCode()
  {
    return 31 * this.size + Arrays.hashCode(this.bits);
  }

  public boolean isRange(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramInt2 < paramInt1)
      throw new IllegalArgumentException();
    if (paramInt2 == paramInt1);
    while (true)
    {
      return true;
      int i = paramInt2 - 1;
      int j = paramInt1 / 32;
      int k = i / 32;
      label129: label158: label164: for (int m = j; m <= k; m++)
      {
        int n;
        int i1;
        label70: int i2;
        label85: int i4;
        if (m > j)
        {
          n = 0;
          if (m >= k)
            break label119;
          i1 = 31;
          if ((n != 0) || (i1 != 31))
            break label129;
          i2 = -1;
          i4 = i2 & this.bits[m];
          if (!paramBoolean)
            break label158;
        }
        while (true)
        {
          if (i4 == i2)
            break label164;
          return false;
          n = paramInt1 & 0x1F;
          break;
          label119: i1 = i & 0x1F;
          break label70;
          i2 = 0;
          for (int i3 = n; i3 <= i1; i3++)
            i2 |= 1 << i3;
          break label85;
          i2 = 0;
        }
      }
    }
  }

  public void reverse()
  {
    int[] arrayOfInt = new int[this.bits.length];
    int i = (-1 + this.size) / 32;
    int j = i + 1;
    int k = 0;
    int m;
    int n;
    int i1;
    label59: int i2;
    if (k >= j)
      if (this.size != j * 32)
      {
        m = j * 32 - this.size;
        n = 1;
        i1 = 0;
        if (i1 < 31 - m)
          break label226;
        i2 = n & arrayOfInt[0] >> m;
      }
    for (int i3 = 1; ; i3++)
    {
      if (i3 >= j)
      {
        arrayOfInt[(j - 1)] = i2;
        this.bits = arrayOfInt;
        return;
        long l1 = this.bits[k];
        long l2 = 0x55555555 & l1 >> 1 | (0x55555555 & l1) << 1;
        long l3 = 0x33333333 & l2 >> 2 | (0x33333333 & l2) << 2;
        long l4 = 0xF0F0F0F & l3 >> 4 | (0xF0F0F0F & l3) << 4;
        long l5 = 0xFF00FF & l4 >> 8 | (0xFF00FF & l4) << 8;
        long l6 = 0xFFFF & l5 >> 16 | (0xFFFF & l5) << 16;
        arrayOfInt[(i - k)] = (int)l6;
        k++;
        break;
        label226: n = 0x1 | n << 1;
        i1++;
        break label59;
      }
      int i4 = arrayOfInt[i3];
      int i5 = i2 | i4 << 32 - m;
      arrayOfInt[(i3 - 1)] = i5;
      i2 = n & i4 >> m;
    }
  }

  public void set(int paramInt)
  {
    int[] arrayOfInt = this.bits;
    int i = paramInt / 32;
    arrayOfInt[i] |= 1 << (paramInt & 0x1F);
  }

  public void setBulk(int paramInt1, int paramInt2)
  {
    this.bits[(paramInt1 / 32)] = paramInt2;
  }

  public void setRange(int paramInt1, int paramInt2)
  {
    if (paramInt2 < paramInt1)
      throw new IllegalArgumentException();
    if (paramInt2 == paramInt1)
      return;
    int i = paramInt2 - 1;
    int j = paramInt1 / 32;
    int k = i / 32;
    int m = j;
    label39: int n;
    label56: int i1;
    label67: int i2;
    if (m <= k)
    {
      if (m <= j)
        break label107;
      n = 0;
      if (m >= k)
        break label116;
      i1 = 31;
      if ((n != 0) || (i1 != 31))
        break label125;
      i2 = -1;
    }
    while (true)
    {
      int[] arrayOfInt = this.bits;
      arrayOfInt[m] = (i2 | arrayOfInt[m]);
      m++;
      break label39;
      break;
      label107: n = paramInt1 & 0x1F;
      break label56;
      label116: i1 = i & 0x1F;
      break label67;
      label125: i2 = 0;
      for (int i3 = n; i3 <= i1; i3++)
        i2 |= 1 << i3;
    }
  }

  public void toBytes(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    int i = 0;
    if (i >= paramInt3)
      return;
    int j = 0;
    for (int k = 0; ; k++)
    {
      if (k >= 8)
      {
        paramArrayOfByte[(paramInt2 + i)] = (byte)j;
        i++;
        break;
      }
      if (get(paramInt1))
        j |= 1 << 7 - k;
      paramInt1++;
    }
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(this.size);
    int i = 0;
    if (i >= this.size)
      return localStringBuilder.toString();
    if ((i & 0x7) == 0)
      localStringBuilder.append(' ');
    if (get(i));
    for (char c = 'X'; ; c = '.')
    {
      localStringBuilder.append(c);
      i++;
      break;
    }
  }

  public void xor(BitArray paramBitArray)
  {
    if (this.bits.length != paramBitArray.bits.length)
      throw new IllegalArgumentException("Sizes don't match");
    for (int i = 0; ; i++)
    {
      if (i >= this.bits.length)
        return;
      int[] arrayOfInt = this.bits;
      arrayOfInt[i] ^= paramBitArray.bits[i];
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.common.BitArray
 * JD-Core Version:    0.6.0
 */