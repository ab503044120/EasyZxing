package com.google.zxing;

public abstract interface ResultPointCallback
{
  public abstract void foundPossibleResultPoint(ResultPoint paramResultPoint);
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.ResultPointCallback
 * JD-Core Version:    0.6.0
 */