package com.google.zxing.datamatrix.encoder;

final class Base256Encoder
  implements Encoder
{
  private static char randomize255State(char paramChar, int paramInt)
  {
    int i = paramChar + (1 + paramInt * 149 % 255);
    if (i <= 255)
      return (char)i;
    return (char)(i - 256);
  }

  public void encode(EncoderContext paramEncoderContext)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append('\000');
    label21: int j;
    int m;
    label62: label90: int n;
    int i1;
    if (!paramEncoderContext.hasMoreCharacters())
    {
      j = -1 + localStringBuilder.length();
      int k = 1 + (j + paramEncoderContext.getCodewordCount());
      paramEncoderContext.updateSymbolInfo(k);
      if (paramEncoderContext.getSymbolInfo().getDataCapacity() - k <= 0)
        break label161;
      m = 1;
      if ((paramEncoderContext.hasMoreCharacters()) || (m != 0))
      {
        if (j > 249)
          break label167;
        localStringBuilder.setCharAt(0, (char)j);
      }
      n = 0;
      i1 = localStringBuilder.length();
    }
    while (true)
    {
      if (n >= i1)
      {
        return;
        localStringBuilder.append(paramEncoderContext.getCurrentChar());
        paramEncoderContext.pos = (1 + paramEncoderContext.pos);
        int i = HighLevelEncoder.lookAheadTest(paramEncoderContext.getMessage(), paramEncoderContext.pos, getEncodingMode());
        if (i == getEncodingMode())
          break;
        paramEncoderContext.signalEncoderChange(i);
        break label21;
        label161: m = 0;
        break label62;
        label167: if ((j > 249) && (j <= 1555))
        {
          localStringBuilder.setCharAt(0, (char)(249 + j / 250));
          localStringBuilder.insert(1, (char)(j % 250));
          break label90;
        }
        throw new IllegalStateException("Message length not in valid ranges: " + j);
      }
      paramEncoderContext.writeCodeword(randomize255State(localStringBuilder.charAt(n), 1 + paramEncoderContext.getCodewordCount()));
      n++;
    }
  }

  public int getEncodingMode()
  {
    return 5;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.datamatrix.encoder.Base256Encoder
 * JD-Core Version:    0.6.0
 */