package com.google.zxing.datamatrix.encoder;

abstract interface Encoder
{
  public abstract void encode(EncoderContext paramEncoderContext);

  public abstract int getEncodingMode();
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.datamatrix.encoder.Encoder
 * JD-Core Version:    0.6.0
 */