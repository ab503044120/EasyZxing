package com.google.zxing.datamatrix.decoder;

final class DataBlock
{
  private final byte[] codewords;
  private final int numDataCodewords;

  private DataBlock(int paramInt, byte[] paramArrayOfByte)
  {
    this.numDataCodewords = paramInt;
    this.codewords = paramArrayOfByte;
  }

  static DataBlock[] getDataBlocks(byte[] paramArrayOfByte, Version paramVersion)
  {
    Version.ECBlocks localECBlocks = paramVersion.getECBlocks();
    int i = 0;
    Version.ECB[] arrayOfECB = localECBlocks.getECBlocks();
    int j = arrayOfECB.length;
    int k = 0;
    DataBlock[] arrayOfDataBlock;
    int m;
    int i1;
    int i6;
    int i8;
    int i9;
    int i13;
    label98: int i14;
    label107: int i15;
    int i16;
    label114: int i19;
    int i20;
    if (k >= j)
    {
      arrayOfDataBlock = new DataBlock[i];
      m = 0;
      int n = arrayOfECB.length;
      i1 = 0;
      if (i1 < n)
        break label182;
      i6 = arrayOfDataBlock[0].codewords.length - localECBlocks.getECCodewords();
      int i7 = i6 - 1;
      i8 = 0;
      i9 = 0;
      if (i9 < i7)
        break label262;
      if (paramVersion.getVersionNumber() != 24)
        break label321;
      i13 = 1;
      if (i13 == 0)
        break label327;
      i14 = 8;
      i15 = 0;
      i16 = i8;
      if (i15 < i14)
        break label334;
      i19 = arrayOfDataBlock[0].codewords.length;
      i20 = i6;
    }
    label182: label321: label327: label334: int i22;
    label262: int i23;
    for (int i21 = i16; ; i21 = i23)
    {
      if (i20 >= i19)
      {
        int i26 = paramArrayOfByte.length;
        if (i21 == i26)
          break label459;
        throw new IllegalArgumentException();
        i += arrayOfECB[k].getCount();
        k++;
        break;
        Version.ECB localECB = arrayOfECB[i1];
        int i2 = 0;
        while (true)
        {
          if (i2 >= localECB.getCount())
          {
            i1++;
            break;
          }
          int i3 = localECB.getDataCodewords();
          int i4 = i3 + localECBlocks.getECCodewords();
          int i5 = m + 1;
          DataBlock localDataBlock = new DataBlock(i3, new byte[i4]);
          arrayOfDataBlock[m] = localDataBlock;
          i2++;
          m = i5;
        }
        int i10 = 0;
        int i12;
        for (int i11 = i8; ; i11 = i12)
        {
          if (i10 >= m)
          {
            i9++;
            i8 = i11;
            break;
          }
          byte[] arrayOfByte1 = arrayOfDataBlock[i10].codewords;
          i12 = i11 + 1;
          arrayOfByte1[i9] = paramArrayOfByte[i11];
          i10++;
        }
        i13 = 0;
        break label98;
        i14 = m;
        break label107;
        byte[] arrayOfByte2 = arrayOfDataBlock[i15].codewords;
        int i17 = i6 - 1;
        int i18 = i16 + 1;
        arrayOfByte2[i17] = paramArrayOfByte[i16];
        i15++;
        i16 = i18;
        break label114;
      }
      i22 = 0;
      i23 = i21;
      if (i22 < m)
        break label399;
      i20++;
    }
    label399: if ((i13 != 0) && (i22 > 7));
    for (int i24 = i20 - 1; ; i24 = i20)
    {
      byte[] arrayOfByte3 = arrayOfDataBlock[i22].codewords;
      int i25 = i23 + 1;
      arrayOfByte3[i24] = paramArrayOfByte[i23];
      i22++;
      i23 = i25;
      break;
    }
    label459: return arrayOfDataBlock;
  }

  byte[] getCodewords()
  {
    return this.codewords;
  }

  int getNumDataCodewords()
  {
    return this.numDataCodewords;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.datamatrix.decoder.DataBlock
 * JD-Core Version:    0.6.0
 */