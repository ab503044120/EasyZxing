package com.google.zxing;

public final class Dimension
{
  private final int height;
  private final int width;

  public Dimension(int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt2 < 0))
      throw new IllegalArgumentException();
    this.width = paramInt1;
    this.height = paramInt2;
  }

  public boolean equals(Object paramObject)
  {
    boolean bool = paramObject instanceof Dimension;
    int i = 0;
    if (bool)
    {
      Dimension localDimension = (Dimension)paramObject;
      int j = this.width;
      int k = localDimension.width;
      i = 0;
      if (j == k)
      {
        int m = this.height;
        int n = localDimension.height;
        i = 0;
        if (m == n)
          i = 1;
      }
    }
    return i;
  }

  public int getHeight()
  {
    return this.height;
  }

  public int getWidth()
  {
    return this.width;
  }

  public int hashCode()
  {
    return 32713 * this.width + this.height;
  }

  public String toString()
  {
    return this.width + "x" + this.height;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.google.zxing.Dimension
 * JD-Core Version:    0.6.0
 */