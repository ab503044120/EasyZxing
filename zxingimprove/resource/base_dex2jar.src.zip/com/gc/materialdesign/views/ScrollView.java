package com.gc.materialdesign.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewGroup;

public class ScrollView extends android.widget.ScrollView
{
  public ScrollView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i = 0;
    while (true)
    {
      if (i >= ((ViewGroup)getChildAt(0)).getChildCount())
        return super.onTouchEvent(paramMotionEvent);
      try
      {
        CustomView localCustomView = (CustomView)((ViewGroup)getChildAt(0)).getChildAt(i);
        if (localCustomView.isLastTouch)
        {
          localCustomView.onTouchEvent(paramMotionEvent);
          return true;
        }
      }
      catch (ClassCastException localClassCastException)
      {
        i++;
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.gc.materialdesign.views.ScrollView
 * JD-Core Version:    0.6.0
 */