package com.gc.materialdesign.widgets;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.gc.materialdesign.R.id;
import com.gc.materialdesign.R.layout;
import com.gc.materialdesign.views.Slider;
import com.gc.materialdesign.views.Slider.OnValueChangedListener;

public class ColorSelector extends Dialog
  implements Slider.OnValueChangedListener, View.OnClickListener
{
  Slider blue;
  int color = -16777216;
  View colorView;
  Slider green;
  OnColorSelectedListener onColorSelectedListener;
  Slider red;
  LinearLayout sliderLayout;

  public ColorSelector(Context paramContext, Integer paramInteger, OnColorSelectedListener paramOnColorSelectedListener)
  {
    super(paramContext, 16973839);
    this.onColorSelectedListener = paramOnColorSelectedListener;
    if (paramInteger != null)
      this.color = paramInteger.intValue();
    setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(DialogInterface paramDialogInterface)
      {
        if (ColorSelector.this.onColorSelectedListener != null)
          ColorSelector.this.onColorSelectedListener.onColorSelected(ColorSelector.this.color);
      }
    });
  }

  public void onClick(View paramView)
  {
    if (paramView.getId() == R.id.viewColor)
    {
      dismiss();
      return;
    }
    paramView.getId();
  }

  protected void onCreate(Bundle paramBundle)
  {
    requestWindowFeature(1);
    super.onCreate(paramBundle);
    setContentView(R.layout.color_selector);
    this.sliderLayout = ((LinearLayout)findViewById(R.id.slider_layout));
    this.sliderLayout.setOnClickListener(this);
    this.colorView = findViewById(R.id.viewColor);
    this.colorView.setOnClickListener(this);
    this.colorView.setBackgroundColor(this.color);
    this.colorView.post(new Runnable()
    {
      public void run()
      {
        LinearLayout.LayoutParams localLayoutParams = (LinearLayout.LayoutParams)ColorSelector.this.colorView.getLayoutParams();
        localLayoutParams.height = ColorSelector.this.colorView.getWidth();
        ColorSelector.this.colorView.setLayoutParams(localLayoutParams);
      }
    });
    this.red = ((Slider)findViewById(R.id.red));
    this.green = ((Slider)findViewById(R.id.green));
    this.blue = ((Slider)findViewById(R.id.blue));
    int i = 0xFF & this.color >> 16;
    int j = 0xFF & this.color >> 8;
    int k = 0xFF & this.color >> 0;
    this.red.setValue(i);
    this.green.setValue(j);
    this.blue.setValue(k);
    this.red.setOnValueChangedListener(this);
    this.green.setOnValueChangedListener(this);
    this.blue.setOnValueChangedListener(this);
  }

  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    dismiss();
    return super.onTouchEvent(paramMotionEvent);
  }

  public void onValueChanged(int paramInt)
  {
    this.color = Color.rgb(this.red.getValue(), this.green.getValue(), this.blue.getValue());
    this.colorView.setBackgroundColor(this.color);
  }

  public static abstract interface OnColorSelectedListener
  {
    public abstract void onColorSelected(int paramInt);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.gc.materialdesign.widgets.ColorSelector
 * JD-Core Version:    0.6.0
 */