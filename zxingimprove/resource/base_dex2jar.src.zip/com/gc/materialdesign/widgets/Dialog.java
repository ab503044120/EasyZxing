package com.gc.materialdesign.widgets;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.gc.materialdesign.R.id;
import com.gc.materialdesign.R.layout;
import com.gc.materialdesign.views.ButtonFlat;

public class Dialog extends android.app.Dialog
{
  ButtonFlat buttonAccept;
  ButtonFlat buttonCancel;
  String message;
  TextView messageTextView;
  View.OnClickListener onAcceptButtonClickListener;
  View.OnClickListener onCancelButtonClickListener;
  String title;
  TextView titleTextView;

  public Dialog(Context paramContext, String paramString1, String paramString2)
  {
    super(paramContext, 16973839);
    this.message = paramString2;
    this.title = paramString1;
  }

  public ButtonFlat getButtonAccept()
  {
    return this.buttonAccept;
  }

  public ButtonFlat getButtonCancel()
  {
    return this.buttonCancel;
  }

  public String getMessage()
  {
    return this.message;
  }

  public TextView getMessageTextView()
  {
    return this.messageTextView;
  }

  public String getTitle()
  {
    return this.title;
  }

  public TextView getTitleTextView()
  {
    return this.titleTextView;
  }

  protected void onCreate(Bundle paramBundle)
  {
    requestWindowFeature(1);
    super.onCreate(paramBundle);
    setContentView(R.layout.dialog);
    this.titleTextView = ((TextView)findViewById(R.id.title));
    setTitle(this.title);
    this.messageTextView = ((TextView)findViewById(R.id.message));
    setMessage(this.message);
    this.buttonAccept = ((ButtonFlat)findViewById(R.id.button_accept));
    this.buttonAccept.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramView)
      {
        Dialog.this.dismiss();
        if (Dialog.this.onAcceptButtonClickListener != null)
          Dialog.this.onAcceptButtonClickListener.onClick(paramView);
      }
    });
    this.buttonCancel = ((ButtonFlat)findViewById(R.id.button_cancel));
    this.buttonCancel.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramView)
      {
        Dialog.this.dismiss();
        if (Dialog.this.onCancelButtonClickListener != null)
          Dialog.this.onCancelButtonClickListener.onClick(paramView);
      }
    });
  }

  public void setButtonAccept(ButtonFlat paramButtonFlat)
  {
    this.buttonAccept = paramButtonFlat;
  }

  public void setButtonCancel(ButtonFlat paramButtonFlat)
  {
    this.buttonCancel = paramButtonFlat;
  }

  public void setMessage(String paramString)
  {
    this.message = paramString;
    this.messageTextView.setText(paramString);
  }

  public void setMessageTextView(TextView paramTextView)
  {
    this.messageTextView = paramTextView;
  }

  public void setOnAcceptButtonClickListener(View.OnClickListener paramOnClickListener)
  {
    this.onAcceptButtonClickListener = paramOnClickListener;
    if (this.buttonAccept != null)
      this.buttonAccept.setOnClickListener(paramOnClickListener);
  }

  public void setOnCancelButtonClickListener(View.OnClickListener paramOnClickListener)
  {
    this.onCancelButtonClickListener = paramOnClickListener;
    if (this.buttonCancel != null)
      this.buttonCancel.setOnClickListener(this.onAcceptButtonClickListener);
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
    if (paramString == null)
    {
      this.titleTextView.setVisibility(8);
      return;
    }
    this.titleTextView.setVisibility(0);
    this.titleTextView.setText(paramString);
  }

  public void setTitleTextView(TextView paramTextView)
  {
    this.titleTextView = paramTextView;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.gc.materialdesign.widgets.Dialog
 * JD-Core Version:    0.6.0
 */