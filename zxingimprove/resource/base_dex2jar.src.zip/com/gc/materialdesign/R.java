package com.gc.materialdesign;

public final class R
{
  public static final class anim
  {
    public static final int progress_indeterminate_animation = 2130968582;
    public static final int snackbar_hide_animation = 2130968583;
    public static final int snackbar_show_animation = 2130968584;
  }

  public static final class attr
  {
    public static final int animate = 2130772026;
    public static final int check = 2130772024;
    public static final int iconFloat = 2130772025;
    public static final int max = 2130772020;
    public static final int min = 2130772021;
    public static final int progress = 2130772023;
    public static final int rippleColor = 2130772028;
    public static final int rippleSpeed = 2130772027;
    public static final int showNumberIndicator = 2130772019;
    public static final int value = 2130772022;
  }

  public static final class color
  {
    public static final int green = 2131165214;
  }

  public static final class drawable
  {
    public static final int background_button = 2130837505;
    public static final int background_button_float = 2130837506;
    public static final int background_button_rectangle = 2130837507;
    public static final int background_checkbox = 2130837508;
    public static final int background_checkbox_check = 2130837509;
    public static final int background_checkbox_uncheck = 2130837510;
    public static final int background_progress = 2130837511;
    public static final int background_switch_ball_uncheck = 2130837512;
    public static final int background_transparent = 2130837513;
    public static final int dialog_background = 2130837526;
    public static final int float_button1_shadowp = 2130837586;
    public static final int float_button_shadow1 = 2130837587;
    public static final int ic_reloj_max = 2130837679;
    public static final int shadow_down = 2130837735;
    public static final int shadow_right = 2130837736;
    public static final int sprite_check = 2130837738;
  }

  public static final class id
  {
    public static final int blue = 2131624024;
    public static final int button_accept = 2131624036;
    public static final int button_cancel = 2131624035;
    public static final int buttonflat = 2131624207;
    public static final int contentDialog = 2131624032;
    public static final int green = 2131624023;
    public static final int message = 2131624034;
    public static final int number_indicator_spinner_content = 2131624202;
    public static final int red = 2131624022;
    public static final int shape_bacground = 2131624213;
    public static final int slider_layout = 2131624021;
    public static final int snackbar = 2131624206;
    public static final int text = 2131624208;
    public static final int title = 2131624033;
    public static final int viewColor = 2131624020;
  }

  public static final class layout
  {
    public static final int color_selector = 2130903053;
    public static final int dialog = 2130903057;
    public static final int number_indicator_spinner = 2130903101;
    public static final int snackbar = 2130903107;
    public static final int text = 2130903108;
  }

  public static final class string
  {
    public static final int app_name = 2131492864;
    public static final int cancel = 2131492869;
    public static final int ok = 2131492871;
  }

  public static final class styleable
  {
    public static final int[] CustomAttributes = { 2130772019, 2130772020, 2130772021, 2130772022, 2130772023, 2130772024, 2130772025, 2130772026, 2130772027, 2130772028 };
    public static final int CustomAttributes_animate = 7;
    public static final int CustomAttributes_check = 5;
    public static final int CustomAttributes_iconFloat = 6;
    public static final int CustomAttributes_max = 1;
    public static final int CustomAttributes_min = 2;
    public static final int CustomAttributes_progress = 4;
    public static final int CustomAttributes_rippleColor = 9;
    public static final int CustomAttributes_rippleSpeed = 8;
    public static final int CustomAttributes_showNumberIndicator = 0;
    public static final int CustomAttributes_value = 3;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     com.gc.materialdesign.R
 * JD-Core Version:    0.6.0
 */