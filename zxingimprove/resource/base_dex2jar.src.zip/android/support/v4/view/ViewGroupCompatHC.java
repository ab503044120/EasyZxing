package android.support.v4.view;

import android.view.ViewGroup;

class ViewGroupCompatHC
{
  public static void setMotionEventSplittingEnabled(ViewGroup paramViewGroup, boolean paramBoolean)
  {
    paramViewGroup.setMotionEventSplittingEnabled(paramBoolean);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     android.support.v4.view.ViewGroupCompatHC
 * JD-Core Version:    0.6.0
 */