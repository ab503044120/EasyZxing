package cn.pedant.SweetAlert;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.Transformation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;

public class SweetAlertDialog extends Dialog
  implements View.OnClickListener
{
  public static final int CUSTOM_IMAGE_TYPE = 4;
  public static final int ERROR_TYPE = 1;
  public static final int NORMAL_TYPE = 0;
  public static final int SUCCESS_TYPE = 2;
  public static final int WARNING_TYPE = 3;
  private int mAlertType;
  private Button mCancelButton;
  private OnSweetClickListener mCancelClickListener;
  private String mCancelText;
  private Button mConfirmButton;
  private OnSweetClickListener mConfirmClickListener;
  private String mConfirmText;
  private String mContentText;
  private TextView mContentTextView;
  private ImageView mCustomImage;
  private Drawable mCustomImgDrawable;
  private View mDialogView;
  private FrameLayout mErrorFrame;
  private Animation mErrorInAnim;
  private ImageView mErrorX;
  private AnimationSet mErrorXInAnim;
  private AnimationSet mModalInAnim;
  private AnimationSet mModalOutAnim;
  private Animation mOverlayOutAnim;
  private boolean mShowCancel;
  private Animation mSuccessBowAnim;
  private FrameLayout mSuccessFrame;
  private AnimationSet mSuccessLayoutAnimSet;
  private View mSuccessLeftMask;
  private View mSuccessRightMask;
  private SuccessTickView mSuccessTick;
  private String mTitleText;
  private TextView mTitleTextView;
  private FrameLayout mWarningFrame;

  public SweetAlertDialog(Context paramContext)
  {
    this(paramContext, 0);
  }

  public SweetAlertDialog(Context paramContext, int paramInt)
  {
    super(paramContext, R.style.alert_dialog);
    setCancelable(true);
    setCanceledOnTouchOutside(false);
    this.mAlertType = paramInt;
    this.mErrorInAnim = OptAnimationLoader.loadAnimation(getContext(), R.anim.error_frame_in);
    this.mErrorXInAnim = ((AnimationSet)OptAnimationLoader.loadAnimation(getContext(), R.anim.error_x_in));
    List localList;
    if (Build.VERSION.SDK_INT <= 10)
      localList = this.mErrorXInAnim.getAnimations();
    for (int i = 0; ; i++)
    {
      if (i >= localList.size());
      do
      {
        if (i < localList.size())
          localList.remove(i);
        this.mSuccessBowAnim = OptAnimationLoader.loadAnimation(getContext(), R.anim.success_bow_roate);
        this.mSuccessLayoutAnimSet = ((AnimationSet)OptAnimationLoader.loadAnimation(getContext(), R.anim.success_mask_layout));
        this.mModalInAnim = ((AnimationSet)OptAnimationLoader.loadAnimation(getContext(), R.anim.modal_in));
        this.mModalOutAnim = ((AnimationSet)OptAnimationLoader.loadAnimation(getContext(), R.anim.modal_out));
        this.mModalOutAnim.setAnimationListener(new Animation.AnimationListener()
        {
          public void onAnimationEnd(Animation paramAnimation)
          {
            SweetAlertDialog.this.mDialogView.setVisibility(8);
            SweetAlertDialog.this.mDialogView.post(new Runnable()
            {
              public void run()
              {
                SweetAlertDialog.this.dismiss();
              }
            });
          }

          public void onAnimationRepeat(Animation paramAnimation)
          {
          }

          public void onAnimationStart(Animation paramAnimation)
          {
          }
        });
        this.mOverlayOutAnim = new Animation()
        {
          protected void applyTransformation(float paramFloat, Transformation paramTransformation)
          {
            WindowManager.LayoutParams localLayoutParams = SweetAlertDialog.this.getWindow().getAttributes();
            localLayoutParams.alpha = (1.0F - paramFloat);
            SweetAlertDialog.this.getWindow().setAttributes(localLayoutParams);
          }
        };
        this.mOverlayOutAnim.setDuration(120L);
        return;
      }
      while ((localList.get(i) instanceof AlphaAnimation));
    }
  }

  private void changeAlertType(int paramInt, boolean paramBoolean)
  {
    this.mAlertType = paramInt;
    if (this.mDialogView != null)
    {
      if (!paramBoolean)
        restore();
      switch (this.mAlertType)
      {
      default:
      case 1:
      case 2:
      case 3:
      case 4:
      }
    }
    while (true)
    {
      if (!paramBoolean)
        playAnimation();
      return;
      this.mErrorFrame.setVisibility(0);
      continue;
      this.mSuccessFrame.setVisibility(0);
      this.mSuccessLeftMask.startAnimation((Animation)this.mSuccessLayoutAnimSet.getAnimations().get(0));
      this.mSuccessRightMask.startAnimation((Animation)this.mSuccessLayoutAnimSet.getAnimations().get(1));
      continue;
      this.mConfirmButton.setBackgroundResource(R.drawable.red_button_background);
      this.mWarningFrame.setVisibility(0);
      continue;
      setCustomImage(this.mCustomImgDrawable);
    }
  }

  private void playAnimation()
  {
    if (this.mAlertType == 1)
    {
      this.mErrorFrame.startAnimation(this.mErrorInAnim);
      this.mErrorX.startAnimation(this.mErrorXInAnim);
    }
    do
      return;
    while (this.mAlertType != 2);
    this.mSuccessTick.startTickAnim();
    this.mSuccessRightMask.startAnimation(this.mSuccessBowAnim);
  }

  private void restore()
  {
    this.mCustomImage.setVisibility(8);
    this.mErrorFrame.setVisibility(8);
    this.mSuccessFrame.setVisibility(8);
    this.mWarningFrame.setVisibility(8);
    this.mConfirmButton.setBackgroundResource(R.drawable.blue_button_background);
    this.mErrorFrame.clearAnimation();
    this.mErrorX.clearAnimation();
    this.mSuccessTick.clearAnimation();
    this.mSuccessLeftMask.clearAnimation();
    this.mSuccessRightMask.clearAnimation();
  }

  public void changeAlertType(int paramInt)
  {
    changeAlertType(paramInt, false);
  }

  public void dismiss()
  {
    this.mConfirmButton.startAnimation(this.mOverlayOutAnim);
    this.mDialogView.startAnimation(this.mModalOutAnim);
  }

  public int getAlerType()
  {
    return this.mAlertType;
  }

  public String getCancelText()
  {
    return this.mCancelText;
  }

  public String getConfirmText()
  {
    return this.mConfirmText;
  }

  public String getContentText()
  {
    return this.mContentText;
  }

  public String getTitleText()
  {
    return this.mTitleText;
  }

  public boolean isShowCancelButton()
  {
    return this.mShowCancel;
  }

  public void onClick(View paramView)
  {
    if (paramView.getId() == R.id.cancel_button)
      if (this.mCancelClickListener != null)
        this.mCancelClickListener.onClick(this);
    do
    {
      return;
      dismiss();
      return;
    }
    while (paramView.getId() != R.id.confirm_button);
    if (this.mConfirmClickListener != null)
    {
      this.mConfirmClickListener.onClick(this);
      return;
    }
    dismiss();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(R.layout.alert_dialog);
    this.mDialogView = getWindow().getDecorView().findViewById(16908290);
    this.mTitleTextView = ((TextView)findViewById(R.id.title_text));
    this.mContentTextView = ((TextView)findViewById(R.id.content_text));
    this.mErrorFrame = ((FrameLayout)findViewById(R.id.error_frame));
    this.mErrorX = ((ImageView)this.mErrorFrame.findViewById(R.id.error_x));
    this.mSuccessFrame = ((FrameLayout)findViewById(R.id.success_frame));
    this.mSuccessTick = ((SuccessTickView)this.mSuccessFrame.findViewById(R.id.success_tick));
    this.mSuccessLeftMask = this.mSuccessFrame.findViewById(R.id.mask_left);
    this.mSuccessRightMask = this.mSuccessFrame.findViewById(R.id.mask_right);
    this.mCustomImage = ((ImageView)findViewById(R.id.custom_image));
    this.mWarningFrame = ((FrameLayout)findViewById(R.id.warning_frame));
    this.mConfirmButton = ((Button)findViewById(R.id.confirm_button));
    this.mCancelButton = ((Button)findViewById(R.id.cancel_button));
    this.mConfirmButton.setOnClickListener(this);
    this.mCancelButton.setOnClickListener(this);
    setTitleText(this.mTitleText);
    setContentText(this.mContentText);
    showCancelButton(this.mShowCancel);
    setCancelText(this.mCancelText);
    setConfirmText(this.mConfirmText);
    changeAlertType(this.mAlertType, true);
  }

  protected void onStart()
  {
    this.mDialogView.startAnimation(this.mModalInAnim);
    playAnimation();
  }

  public SweetAlertDialog setCancelClickListener(OnSweetClickListener paramOnSweetClickListener)
  {
    this.mCancelClickListener = paramOnSweetClickListener;
    return this;
  }

  public SweetAlertDialog setCancelText(String paramString)
  {
    this.mCancelText = paramString;
    if ((this.mCancelButton != null) && (this.mCancelText != null))
      this.mCancelButton.setText(this.mCancelText);
    return this;
  }

  public SweetAlertDialog setConfirmClickListener(OnSweetClickListener paramOnSweetClickListener)
  {
    this.mConfirmClickListener = paramOnSweetClickListener;
    return this;
  }

  public SweetAlertDialog setConfirmText(String paramString)
  {
    this.mConfirmText = paramString;
    if ((this.mConfirmButton != null) && (this.mConfirmText != null))
      this.mConfirmButton.setText(this.mConfirmText);
    return this;
  }

  public SweetAlertDialog setContentText(String paramString)
  {
    this.mContentText = paramString;
    if ((this.mContentTextView != null) && (this.mContentText != null))
    {
      this.mContentTextView.setVisibility(0);
      this.mContentTextView.setText(this.mContentText);
    }
    return this;
  }

  public SweetAlertDialog setCustomImage(int paramInt)
  {
    return setCustomImage(getContext().getResources().getDrawable(paramInt));
  }

  public SweetAlertDialog setCustomImage(Drawable paramDrawable)
  {
    this.mCustomImgDrawable = paramDrawable;
    if ((this.mCustomImage != null) && (this.mCustomImgDrawable != null))
    {
      this.mCustomImage.setVisibility(0);
      this.mCustomImage.setImageDrawable(this.mCustomImgDrawable);
    }
    return this;
  }

  public SweetAlertDialog setTitleText(String paramString)
  {
    this.mTitleText = paramString;
    if ((this.mTitleTextView != null) && (this.mTitleText != null))
      this.mTitleTextView.setText(this.mTitleText);
    return this;
  }

  public SweetAlertDialog showCancelButton(boolean paramBoolean)
  {
    this.mShowCancel = paramBoolean;
    Button localButton;
    if (this.mCancelButton != null)
    {
      localButton = this.mCancelButton;
      if (!this.mShowCancel)
        break label33;
    }
    label33: for (int i = 0; ; i = 8)
    {
      localButton.setVisibility(i);
      return this;
    }
  }

  public static abstract interface OnSweetClickListener
  {
    public abstract void onClick(SweetAlertDialog paramSweetAlertDialog);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     cn.pedant.SweetAlert.SweetAlertDialog
 * JD-Core Version:    0.6.0
 */