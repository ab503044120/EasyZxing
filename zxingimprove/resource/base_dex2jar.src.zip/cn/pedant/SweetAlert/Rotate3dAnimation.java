package cn.pedant.SweetAlert;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Camera;
import android.graphics.Matrix;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.animation.Animation;
import android.view.animation.Transformation;

public class Rotate3dAnimation extends Animation
{
  public static final int ROLL_BY_X = 0;
  public static final int ROLL_BY_Y = 1;
  public static final int ROLL_BY_Z = 2;
  private Camera mCamera;
  private float mFromDegrees;
  private float mPivotX;
  private int mPivotXType = 0;
  private float mPivotXValue = 0.0F;
  private float mPivotY;
  private int mPivotYType = 0;
  private float mPivotYValue = 0.0F;
  private int mRollType;
  private float mToDegrees;

  public Rotate3dAnimation(int paramInt, float paramFloat1, float paramFloat2)
  {
    this.mRollType = paramInt;
    this.mFromDegrees = paramFloat1;
    this.mToDegrees = paramFloat2;
    this.mPivotX = 0.0F;
    this.mPivotY = 0.0F;
  }

  public Rotate3dAnimation(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    this.mRollType = paramInt;
    this.mFromDegrees = paramFloat1;
    this.mToDegrees = paramFloat2;
    this.mPivotXType = 0;
    this.mPivotYType = 0;
    this.mPivotXValue = paramFloat3;
    this.mPivotYValue = paramFloat4;
    initializePivotPoint();
  }

  public Rotate3dAnimation(int paramInt1, float paramFloat1, float paramFloat2, int paramInt2, float paramFloat3, int paramInt3, float paramFloat4)
  {
    this.mRollType = paramInt1;
    this.mFromDegrees = paramFloat1;
    this.mToDegrees = paramFloat2;
    this.mPivotXValue = paramFloat3;
    this.mPivotXType = paramInt2;
    this.mPivotYValue = paramFloat4;
    this.mPivotYType = paramInt3;
    initializePivotPoint();
  }

  public Rotate3dAnimation(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.Rotate3dAnimation);
    this.mFromDegrees = localTypedArray.getFloat(R.styleable.Rotate3dAnimation_fromDeg, 0.0F);
    this.mToDegrees = localTypedArray.getFloat(R.styleable.Rotate3dAnimation_toDeg, 0.0F);
    this.mRollType = localTypedArray.getInt(R.styleable.Rotate3dAnimation_rollType, 0);
    Description localDescription1 = parseValue(localTypedArray.peekValue(R.styleable.Rotate3dAnimation_pivotX));
    this.mPivotXType = localDescription1.type;
    this.mPivotXValue = localDescription1.value;
    Description localDescription2 = parseValue(localTypedArray.peekValue(R.styleable.Rotate3dAnimation_pivotY));
    this.mPivotYType = localDescription2.type;
    this.mPivotYValue = localDescription2.value;
    localTypedArray.recycle();
    initializePivotPoint();
  }

  private void initializePivotPoint()
  {
    if (this.mPivotXType == 0)
      this.mPivotX = this.mPivotXValue;
    if (this.mPivotYType == 0)
      this.mPivotY = this.mPivotYValue;
  }

  protected void applyTransformation(float paramFloat, Transformation paramTransformation)
  {
    float f1 = this.mFromDegrees;
    float f2 = f1 + paramFloat * (this.mToDegrees - f1);
    Matrix localMatrix = paramTransformation.getMatrix();
    this.mCamera.save();
    switch (this.mRollType)
    {
    default:
    case 0:
    case 1:
    case 2:
    }
    while (true)
    {
      this.mCamera.getMatrix(localMatrix);
      this.mCamera.restore();
      localMatrix.preTranslate(-this.mPivotX, -this.mPivotY);
      localMatrix.postTranslate(this.mPivotX, this.mPivotY);
      return;
      this.mCamera.rotateX(f2);
      continue;
      this.mCamera.rotateY(f2);
      continue;
      this.mCamera.rotateZ(f2);
    }
  }

  public void initialize(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.initialize(paramInt1, paramInt2, paramInt3, paramInt4);
    this.mCamera = new Camera();
    this.mPivotX = resolveSize(this.mPivotXType, this.mPivotXValue, paramInt1, paramInt3);
    this.mPivotY = resolveSize(this.mPivotYType, this.mPivotYValue, paramInt2, paramInt4);
  }

  Description parseValue(TypedValue paramTypedValue)
  {
    int i = 1;
    Description localDescription = new Description();
    if (paramTypedValue == null)
    {
      localDescription.type = 0;
      localDescription.value = 0.0F;
    }
    do
    {
      localDescription.type = 0;
      localDescription.value = 0.0F;
      return localDescription;
      if (paramTypedValue.type == 6)
      {
        if ((0xF & paramTypedValue.data) == i)
          i = 2;
        localDescription.type = i;
        localDescription.value = TypedValue.complexToFloat(paramTypedValue.data);
        return localDescription;
      }
      if (paramTypedValue.type != 4)
        continue;
      localDescription.type = 0;
      localDescription.value = paramTypedValue.getFloat();
      return localDescription;
    }
    while ((paramTypedValue.type < 16) || (paramTypedValue.type > 31));
    localDescription.type = 0;
    localDescription.value = paramTypedValue.data;
    return localDescription;
  }

  protected static class Description
  {
    public int type;
    public float value;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     cn.pedant.SweetAlert.Rotate3dAnimation
 * JD-Core Version:    0.6.0
 */