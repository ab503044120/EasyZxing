package cn.pedant.SweetAlert;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Transformation;

public class SuccessTickView extends View
{
  private final float CONST_LEFT_RECT_W = dip2px(15.0F);
  private final float CONST_RADIUS = dip2px(1.2F);
  private final float CONST_RECT_WEIGHT = dip2px(3.0F);
  private final float CONST_RIGHT_RECT_W = dip2px(25.0F);
  private final float MAX_RIGHT_RECT_W = this.CONST_RIGHT_RECT_W + dip2px(6.7F);
  private final float MIN_LEFT_RECT_W = dip2px(3.3F);
  private float mDensity = -1.0F;
  private boolean mLeftRectGrowMode;
  private float mLeftRectWidth;
  private float mMaxLeftRectWidth;
  private Paint mPaint;
  private float mRightRectWidth;

  public SuccessTickView(Context paramContext)
  {
    super(paramContext);
    init();
  }

  public SuccessTickView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    init();
  }

  private void init()
  {
    this.mPaint = new Paint();
    this.mPaint.setColor(getResources().getColor(R.color.success_stroke_color));
    this.mLeftRectWidth = this.CONST_LEFT_RECT_W;
    this.mRightRectWidth = this.CONST_RIGHT_RECT_W;
    this.mLeftRectGrowMode = false;
  }

  public float dip2px(float paramFloat)
  {
    if (this.mDensity == -1.0F)
      this.mDensity = getResources().getDisplayMetrics().density;
    return 0.5F + paramFloat * this.mDensity;
  }

  public void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    int i = getWidth();
    int j = getHeight();
    paramCanvas.rotate(45.0F, i / 2, j / 2);
    int k = (int)(i / 1.2D);
    int m = (int)(j / 1.4D);
    this.mMaxLeftRectWidth = ((k + this.CONST_LEFT_RECT_W) / 2.0F + this.CONST_RECT_WEIGHT - 1.0F);
    RectF localRectF1 = new RectF();
    if (this.mLeftRectGrowMode)
    {
      localRectF1.left = 0.0F;
      localRectF1.right = (localRectF1.left + this.mLeftRectWidth);
      localRectF1.top = ((m + this.CONST_RIGHT_RECT_W) / 2.0F);
    }
    for (localRectF1.bottom = (localRectF1.top + this.CONST_RECT_WEIGHT); ; localRectF1.bottom = (localRectF1.top + this.CONST_RECT_WEIGHT))
    {
      paramCanvas.drawRoundRect(localRectF1, this.CONST_RADIUS, this.CONST_RADIUS, this.mPaint);
      RectF localRectF2 = new RectF();
      localRectF2.bottom = ((m + this.CONST_RIGHT_RECT_W) / 2.0F + this.CONST_RECT_WEIGHT - 1.0F);
      localRectF2.left = ((k + this.CONST_LEFT_RECT_W) / 2.0F);
      localRectF2.right = (localRectF2.left + this.CONST_RECT_WEIGHT);
      localRectF2.top = (localRectF2.bottom - this.mRightRectWidth);
      paramCanvas.drawRoundRect(localRectF2, this.CONST_RADIUS, this.CONST_RADIUS, this.mPaint);
      return;
      localRectF1.right = ((k + this.CONST_LEFT_RECT_W) / 2.0F + this.CONST_RECT_WEIGHT - 1.0F);
      localRectF1.left = (localRectF1.right - this.mLeftRectWidth);
      localRectF1.top = ((m + this.CONST_RIGHT_RECT_W) / 2.0F);
    }
  }

  public void startTickAnim()
  {
    this.mLeftRectWidth = 0.0F;
    this.mRightRectWidth = 0.0F;
    invalidate();
    1 local1 = new Animation()
    {
      protected void applyTransformation(float paramFloat, Transformation paramTransformation)
      {
        super.applyTransformation(paramFloat, paramTransformation);
        if ((0.54D < paramFloat) && (0.7D >= paramFloat))
        {
          SuccessTickView.this.mLeftRectGrowMode = true;
          SuccessTickView.this.mLeftRectWidth = (SuccessTickView.this.mMaxLeftRectWidth * ((paramFloat - 0.54F) / 0.16F));
          if (0.65D < paramFloat)
            SuccessTickView.this.mRightRectWidth = (SuccessTickView.this.MAX_RIGHT_RECT_W * ((paramFloat - 0.65F) / 0.19F));
          SuccessTickView.this.invalidate();
        }
        do
        {
          return;
          if ((0.7D >= paramFloat) || (0.84D < paramFloat))
            continue;
          SuccessTickView.this.mLeftRectGrowMode = false;
          SuccessTickView.this.mLeftRectWidth = (SuccessTickView.this.mMaxLeftRectWidth * (1.0F - (paramFloat - 0.7F) / 0.14F));
          SuccessTickView localSuccessTickView = SuccessTickView.this;
          float f;
          if (SuccessTickView.this.mLeftRectWidth < SuccessTickView.this.MIN_LEFT_RECT_W)
            f = SuccessTickView.this.MIN_LEFT_RECT_W;
          while (true)
          {
            localSuccessTickView.mLeftRectWidth = f;
            SuccessTickView.this.mRightRectWidth = (SuccessTickView.this.MAX_RIGHT_RECT_W * ((paramFloat - 0.65F) / 0.19F));
            SuccessTickView.this.invalidate();
            return;
            f = SuccessTickView.this.mLeftRectWidth;
          }
        }
        while ((0.84D >= paramFloat) || (1.0F < paramFloat));
        SuccessTickView.this.mLeftRectGrowMode = false;
        SuccessTickView.this.mLeftRectWidth = (SuccessTickView.this.MIN_LEFT_RECT_W + (SuccessTickView.this.CONST_LEFT_RECT_W - SuccessTickView.this.MIN_LEFT_RECT_W) * ((paramFloat - 0.84F) / 0.16F));
        SuccessTickView.this.mRightRectWidth = (SuccessTickView.this.CONST_RIGHT_RECT_W + (SuccessTickView.this.MAX_RIGHT_RECT_W - SuccessTickView.this.CONST_RIGHT_RECT_W) * (1.0F - (paramFloat - 0.84F) / 0.16F));
        SuccessTickView.this.invalidate();
      }
    };
    local1.setDuration(750L);
    local1.setStartOffset(100L);
    startAnimation(local1);
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     cn.pedant.SweetAlert.SuccessTickView
 * JD-Core Version:    0.6.0
 */