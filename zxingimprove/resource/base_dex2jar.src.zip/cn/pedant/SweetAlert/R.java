package cn.pedant.SweetAlert;

public final class R
{
  public static final class anim
  {
    public static final int error_frame_in = 2130968576;
    public static final int error_x_in = 2130968577;
    public static final int modal_in = 2130968580;
    public static final int modal_out = 2130968581;
    public static final int success_bow_roate = 2130968585;
    public static final int success_mask_layout = 2130968586;
  }

  public static final class attr
  {
    public static final int fromDeg = 2130772005;
    public static final int pivotX = 2130772007;
    public static final int pivotY = 2130772008;
    public static final int rollType = 2130772004;
    public static final int toDeg = 2130772006;
  }

  public static final class color
  {
    public static final int blue_btn_bg_color = 2131165206;
    public static final int blue_btn_bg_pressed_color = 2131165207;
    public static final int button_text_color = 2131165203;
    public static final int error_stroke_color = 2131165210;
    public static final int float_transparent = 2131165201;
    public static final int gray_btn_bg_color = 2131165204;
    public static final int gray_btn_bg_pressed_color = 2131165205;
    public static final int green = 2131165214;
    public static final int red_btn_bg_color = 2131165208;
    public static final int red_btn_bg_pressed_color = 2131165209;
    public static final int success_stroke_color = 2131165211;
    public static final int sweet_dialog_bg_color = 2131165202;
    public static final int trans_success_stroke_color = 2131165212;
    public static final int warning_stroke_color = 2131165213;
  }

  public static final class dimen
  {
    public static final int alert_width = 2131361805;
    public static final int common_circle_width = 2131361806;
    public static final int progress_circle_radius = 2131361807;
  }

  public static final class drawable
  {
    public static final int blue_button_background = 2130837514;
    public static final int error_center_x = 2130837582;
    public static final int error_circle = 2130837583;
    public static final int gray_button_background = 2130837590;
    public static final int red_button_background = 2130837726;
    public static final int success_bow = 2130837739;
    public static final int success_circle = 2130837740;
    public static final int sweet_dialog_background = 2130837741;
    public static final int warning_circle = 2130837763;
    public static final int warning_sigh = 2130837764;
  }

  public static final class id
  {
    public static final int cancel_button = 2131624018;
    public static final int confirm_button = 2131624019;
    public static final int content_text = 2131624017;
    public static final int custom_image = 2131624008;
    public static final int error_frame = 2131624009;
    public static final int error_x = 2131624010;
    public static final int loading = 2131624007;
    public static final int mask_left = 2131624013;
    public static final int mask_right = 2131624012;
    public static final int success_frame = 2131624011;
    public static final int success_tick = 2131624014;
    public static final int title_text = 2131624016;
    public static final int warning_frame = 2131624015;
    public static final int x = 2131623966;
    public static final int y = 2131623967;
    public static final int z = 2131623968;
  }

  public static final class layout
  {
    public static final int alert_dialog = 2130903052;
  }

  public static final class string
  {
    public static final int LOADING = 2131492868;
    public static final int app_name = 2131492864;
    public static final int cancel = 2131492869;
    public static final int confirm = 2131492870;
    public static final int dialog_cancel = 2131492867;
    public static final int dialog_default_title = 2131492865;
    public static final int dialog_ok = 2131492866;
  }

  public static final class style
  {
    public static final int alert_dialog = 2131427337;
    public static final int dialog_blue_button = 2131427338;
  }

  public static final class styleable
  {
    public static final int[] Rotate3dAnimation = { 2130772004, 2130772005, 2130772006, 2130772007, 2130772008 };
    public static final int Rotate3dAnimation_fromDeg = 1;
    public static final int Rotate3dAnimation_pivotX = 3;
    public static final int Rotate3dAnimation_pivotY = 4;
    public static final int Rotate3dAnimation_rollType = 0;
    public static final int Rotate3dAnimation_toDeg = 2;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     cn.pedant.SweetAlert.R
 * JD-Core Version:    0.6.0
 */