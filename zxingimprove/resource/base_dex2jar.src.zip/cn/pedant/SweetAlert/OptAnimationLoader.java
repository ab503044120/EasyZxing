package cn.pedant.SweetAlert;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Xml;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import java.io.IOException;
import java.lang.reflect.Constructor;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class OptAnimationLoader
{
  private static Animation createAnimationFromXml(Context paramContext, XmlPullParser paramXmlPullParser)
    throws XmlPullParserException, IOException
  {
    return createAnimationFromXml(paramContext, paramXmlPullParser, null, Xml.asAttributeSet(paramXmlPullParser));
  }

  private static Animation createAnimationFromXml(Context paramContext, XmlPullParser paramXmlPullParser, AnimationSet paramAnimationSet, AttributeSet paramAttributeSet)
    throws XmlPullParserException, IOException
  {
    Object localObject = null;
    int i = paramXmlPullParser.getDepth();
    int j;
    do
    {
      j = paramXmlPullParser.next();
      if (((j == 3) && (paramXmlPullParser.getDepth() <= i)) || (j == 1))
        return localObject;
    }
    while (j != 2);
    String str = paramXmlPullParser.getName();
    if (str.equals("set"))
    {
      localObject = new AnimationSet(paramContext, paramAttributeSet);
      createAnimationFromXml(paramContext, paramXmlPullParser, (AnimationSet)localObject, paramAttributeSet);
    }
    while (true)
    {
      if (paramAnimationSet != null)
      {
        paramAnimationSet.addAnimation((Animation)localObject);
        break;
        if (str.equals("alpha"))
        {
          localObject = new AlphaAnimation(paramContext, paramAttributeSet);
          continue;
        }
        if (str.equals("scale"))
        {
          localObject = new ScaleAnimation(paramContext, paramAttributeSet);
          continue;
        }
        if (str.equals("rotate"))
        {
          localObject = new RotateAnimation(paramContext, paramAttributeSet);
          continue;
        }
        if (str.equals("translate"))
        {
          localObject = new TranslateAnimation(paramContext, paramAttributeSet);
          continue;
        }
      }
      else
      {
        break;
      }
      try
      {
        localObject = (Animation)Class.forName(str).getConstructor(new Class[] { Context.class, AttributeSet.class }).newInstance(new Object[] { paramContext, paramAttributeSet });
      }
      catch (Exception localException)
      {
      }
    }
    throw new RuntimeException("Unknown animation name: " + paramXmlPullParser.getName() + " error:" + localException.getMessage());
  }

  // ERROR //
  public static Animation loadAnimation(Context paramContext, int paramInt)
    throws android.content.res.Resources.NotFoundException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: invokevirtual 127	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   6: iload_1
    //   7: invokevirtual 133	android/content/res/Resources:getAnimation	(I)Landroid/content/res/XmlResourceParser;
    //   10: astore_2
    //   11: aload_0
    //   12: aload_2
    //   13: invokestatic 135	cn/pedant/SweetAlert/OptAnimationLoader:createAnimationFromXml	(Landroid/content/Context;Lorg/xmlpull/v1/XmlPullParser;)Landroid/view/animation/Animation;
    //   16: astore 10
    //   18: aload_2
    //   19: ifnull +9 -> 28
    //   22: aload_2
    //   23: invokeinterface 140 1 0
    //   28: aload 10
    //   30: areturn
    //   31: astore 7
    //   33: new 123	android/content/res/Resources$NotFoundException
    //   36: dup
    //   37: new 101	java/lang/StringBuilder
    //   40: dup
    //   41: ldc 142
    //   43: invokespecial 106	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   46: iload_1
    //   47: invokestatic 148	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   50: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: invokevirtual 118	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   56: invokespecial 149	android/content/res/Resources$NotFoundException:<init>	(Ljava/lang/String;)V
    //   59: astore 8
    //   61: aload 8
    //   63: aload 7
    //   65: invokevirtual 153	android/content/res/Resources$NotFoundException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   68: pop
    //   69: aload 8
    //   71: athrow
    //   72: astore 6
    //   74: aload_2
    //   75: ifnull +9 -> 84
    //   78: aload_2
    //   79: invokeinterface 140 1 0
    //   84: aload 6
    //   86: athrow
    //   87: astore_3
    //   88: new 123	android/content/res/Resources$NotFoundException
    //   91: dup
    //   92: new 101	java/lang/StringBuilder
    //   95: dup
    //   96: ldc 142
    //   98: invokespecial 106	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   101: iload_1
    //   102: invokestatic 148	java/lang/Integer:toHexString	(I)Ljava/lang/String;
    //   105: invokevirtual 110	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: invokevirtual 118	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   111: invokespecial 149	android/content/res/Resources$NotFoundException:<init>	(Ljava/lang/String;)V
    //   114: astore 4
    //   116: aload 4
    //   118: aload_3
    //   119: invokevirtual 153	android/content/res/Resources$NotFoundException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   122: pop
    //   123: aload 4
    //   125: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   2	18	31	org/xmlpull/v1/XmlPullParserException
    //   2	18	72	finally
    //   33	72	72	finally
    //   88	126	72	finally
    //   2	18	87	java/io/IOException
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     cn.pedant.SweetAlert.OptAnimationLoader
 * JD-Core Version:    0.6.0
 */