package mobi.thinkchange.android.lib.customtheme;

public final class R
{
  public static final class drawable
  {
    public static final int btn_check_off_enabled = 2130837515;
    public static final int btn_check_on_enabled = 2130837516;
    public static final int list_section_divider_green = 2130837699;
    public static final int my_checkbox = 2130837712;
    public static final int preference_icon_about = 2130837716;
    public static final int preference_icon_clear = 2130837717;
    public static final int preference_icon_feedback = 2130837718;
    public static final int preference_icon_help = 2130837719;
    public static final int preference_icon_ring = 2130837720;
    public static final int preference_icon_share = 2130837721;
    public static final int preference_icon_shortcut = 2130837722;
    public static final int preference_icon_upgrade = 2130837723;
    public static final int preference_icon_vibrate = 2130837724;
    public static final int preference_widget_with_more_indicator = 2130837725;
  }

  public static final class layout
  {
    public static final int preference_widget_with_more = 2130903102;
  }

  public static final class style
  {
    public static final int MyCheckBox = 2131427336;
    public static final int MyListSeparator = 2131427335;
    public static final int MySettingBaseTheme = 2131427333;
    public static final int MySettingTheme = 2131427334;
  }
}

/* Location:           C:\Users\Administrator\Desktop\base_dex2jar.jar
 * Qualified Name:     mobi.thinkchange.android.lib.customtheme.R
 * JD-Core Version:    0.6.0
 */